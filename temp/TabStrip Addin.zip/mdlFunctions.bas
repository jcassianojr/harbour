Attribute VB_Name = "mdlFunctions"
Private Declare Function PeekMessage Lib "user32" Alias "PeekMessageA" _
    (lpMsg As MSG, ByVal hWnd As Long, ByVal wMsgFilterMin As Long, _
     ByVal wMsgFilterMax As Long, ByVal wRemoveMsg As Long) As Long

Private Declare Function TranslateMessage Lib "user32" _
    (lpMsg As MSG) As Long

Private Declare Function DispatchMessage Lib "user32" Alias "DispatchMessageA" _
    (lpMsg As MSG) As Long

Private Type POINTAPI
        x As Long
        y As Long
End Type

Private Type MSG
    hWnd    As Long
    message As Long
    wParam  As Long
    lParam  As Long
    time    As Long
    pt      As POINTAPI
End Type



Private Const PM_REMOVE As Long = &H1

Public Sub APIDoEvents()
    Dim oMsg As MSG
31:     Do While PeekMessage(oMsg, 0&, 0&, 0&, PM_REMOVE)
32:         TranslateMessage oMsg
33:         DispatchMessage oMsg
34:     Loop
End Sub

