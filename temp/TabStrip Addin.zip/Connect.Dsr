VERSION 5.00
Begin {AC0714F6-3D04-11D1-AE7D-00A0C90F26F4} Connect 
   ClientHeight    =   7680
   ClientLeft      =   10950
   ClientTop       =   3690
   ClientWidth     =   14805
   _ExtentX        =   26114
   _ExtentY        =   13547
   _Version        =   393216
   Description     =   $"Connect.dsx":0000
   DisplayName     =   "Tab-Strip and Tools AddIn"
   AppName         =   "Visual Basic"
   AppVer          =   "Visual Basic 6.0"
   LoadName        =   "Startup"
   LoadBehavior    =   1
   RegLocation     =   "HKEY_CURRENT_USER\Software\Microsoft\Visual Basic\6.0"
   CmdLineSupport  =   -1  'True
End
Attribute VB_Name = "Connect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_Description = "Tab-Strip Add-In"
Option Explicit

Private Declare Function ShowWindow Lib "user32" ( _
    ByVal hWnd As Long, _
    ByVal nCmdShow As Long) As Long
Private Const SW_MAXIMIZE As Long = 3

Private GUIvisible              As Boolean

Dim mcbMenuCommandBar         As Office.CommandBarControl
Dim mcbLineNumbersAdd         As Office.CommandBarControl
Dim mcbLineNumbersRemove      As Office.CommandBarControl
Private WithEvents MenuHandler         As CommandBarEvents
Attribute MenuHandler.VB_VarHelpID = -1
Private WithEvents LineNumAddHandler   As CommandBarEvents
Attribute LineNumAddHandler.VB_VarHelpID = -1
Private WithEvents LineNumRemoveHandler As CommandBarEvents
Attribute LineNumRemoveHandler.VB_VarHelpID = -1

' CORRE��O: Vari�veis de eventos globais declaradas corretamente
Private WithEvents VBProjEvents As VBIDE.VBProjectsEvents
Attribute VBProjEvents.VB_VarHelpID = -1
Private WithEvents VBCompEvents As VBIDE.VBComponentsEvents
Attribute VBCompEvents.VB_VarHelpID = -1

Private Sub Hide()
22:    On Error Resume Next
23:    GUIvisible = False
End Sub

Private Sub Show()
27:    On Error GoTo Show_Error

29:    If GUIvisible Then Exit Sub
   
31:    If gOptionsForm Is Nothing Then Set gOptionsForm = New frmTabStripOptions
32:    Load gOptionsForm
33:    If gLogging Then Log "Addin-In Started with the IDE?: " & gLaunchedAtIDEStartup
   
35:    CreateToolbar
36:    InitGlobalIDEVariables
   
38:    If gGuiForm Is Nothing Then Set gGuiForm = New frmTabStrip
39:    Load gGuiForm
40:    gGuiForm.Init
   
42:    GUIvisible = True
   
44:    If gLogging Then Log "UI is now visible - " & IIf(gIsSDI, "SDI", "MDI") & " mode"

46:    Exit Sub

Show_Error:
49:    MsgBox "Error " & Err.Number & " (" & Err.Description & ") in Show of Connect"
End Sub

Private Sub AddinInstance_OnConnection(ByVal Application As Object, ByVal ConnectMode As AddInDesignerObjects.ext_ConnectMode, ByVal AddInInst As Object, custom() As Variant)
53:    On Error GoTo error_handler

   ' Instanciar a vari�vel de controlo global do IDE
56:    Set gVBInstance = Application
   
   ' Ativar os eventos globais est�veis de Projetos
59:    Set VBProjEvents = gVBInstance.Events.VBProjectsEvents
   
   ' Chamar a rotina de mapeamento seguro do projeto ativo
62:    HookComponentEvents
   
64:    gIsSDI = (gVBInstance.DisplayModel = vbext_dm_SDI)
   
66:    If ConnectMode = ext_cm_External Then
67:       Show
68:    Else
69:       Set mcbMenuCommandBar = AddToAddInCommandBar("Tab-Strip Options...")
70:       Set mcbLineNumbersAdd = AddToAddInCommandBar("Add Line Numbers")
71:       Set mcbLineNumbersRemove = AddToAddInCommandBar("Remove Line Numbers")
72:       Set MenuHandler = gVBInstance.Events.CommandBarEvents(mcbMenuCommandBar)
73:       Set LineNumAddHandler = gVBInstance.Events.CommandBarEvents(mcbLineNumbersAdd)
74:       Set LineNumRemoveHandler = gVBInstance.Events.CommandBarEvents(mcbLineNumbersRemove)
75:    End If
  
77:    If ConnectMode = ext_cm_AfterStartup Then
78:       Show
79:    Else
80:       gLaunchedAtIDEStartup = True
81:    End If
  
83:    Exit Sub
    
error_handler:
86:    MsgBox "AddinInstance_OnConnection: " & Err.Description
End Sub

Private Sub AddinInstance_OnStartupComplete(custom() As Variant)
90:    Show
   ' Re-ligar eventos din�micos ap�s conclus�o de carregamento do IDE
92:    HookComponentEvents
End Sub

' ====================================================================
' ROTINA AUXILIAR PARA RECONECTAR OS EVENTOS DOS COMPONENTES
' ====================================================================
Private Sub HookComponentEvents()
99:     On Error Resume Next
100:     Set VBCompEvents = Nothing
101:     If Not gVBInstance Is Nothing Then
102:         If Not gVBInstance.ActiveVBProject Is Nothing Then
103:             Set VBCompEvents = gVBInstance.Events.VBComponentsEvents(gVBInstance.ActiveVBProject)
104:         End If
105:     End If
End Sub

Private Sub VBProjEvents_ItemActivated(ByVal VBProject As VBIDE.VBProject)
109:     HookComponentEvents
End Sub

Private Sub VBProjEvents_ItemAdded(ByVal VBProject As VBIDE.VBProject)
113:     HookComponentEvents
End Sub

' ====================================================================
' clean\delete the setted objects
' ====================================================================
Private Sub AddinInstance_OnDisconnection(ByVal RemoveMode As AddInDesignerObjects.ext_DisconnectMode, custom() As Variant)
120:    On Error GoTo AddinInstance_OnDisconnection_Error

122:    If GUIvisible Then
123:        SaveSetting App.Title, "Settings", "DisplayOnConnect", "1"
124:        GUIvisible = False
125:    Else
126:        SaveSetting App.Title, "Settings", "DisplayOnConnect", "1"
127:    End If
    
   ' 1. Destruir refer�ncias de Eventos com o IDE
130:    Set VBCompEvents = Nothing
131:    Set VBProjEvents = Nothing
132:    Set MenuHandler = Nothing
133:    Set LineNumAddHandler = Nothing
134:    Set LineNumRemoveHandler = Nothing
   
   ' 2. Remover controlos f�sicos criados na barra do menu Add-Ins
137:    mcbMenuCommandBar.Delete
138:    mcbLineNumbersAdd.Delete
139:    mcbLineNumbersRemove.Delete
   
   ' 3. Aniquilar os objetos dos bot�es em si
142:    Set mcbMenuCommandBar = Nothing
143:    Set mcbLineNumbersAdd = Nothing
144:    Set mcbLineNumbersRemove = Nothing
    
   ' 4. CORRE��O CR�TICA: Descarregar e aniquilar INST�NCIAS DE FORMS criados com Set
147:    Unload gGuiForm
148:    Set gGuiForm = Nothing
   
150:    Unload gOptionsForm
151:    Set gOptionsForm = Nothing
   
   ' 5. Eliminar a barra de ferramentas personalizada
154:    DeleteToolBar
   
   ' 6. Libertar o ponteiro raiz do VB6 IDE
157:    Set gVBInstance = Nothing

159:    Exit Sub

AddinInstance_OnDisconnection_Error:
162:    MsgBox "Error " & Err.Number & " (" & Err.Description & ") in AddinInstance_OnDisconnection"
End Sub

Private Sub MenuHandler_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
166:    If GUIvisible Then gOptionsForm.Show
End Sub

' with a new form we change the AutoRedraw to true and ScaleMode to Pixels:
Private Sub VBCompEvents_ItemAdded(ByVal VBComponent As VBIDE.VBComponent)
171:    On Error Resume Next
        
173:    If VBComponent.Type = vbext_ct_VBForm Then
       Dim oDesigner As Object
175:        Set oDesigner = VBComponent.Designer
       
       Dim oProp As VBIDE.Property
       
179:        Set oProp = VBComponent.Properties("AutoRedraw")
180:        If Not oProp Is Nothing Then oProp.Value = True
       
182:        Set oProp = VBComponent.Properties("ScaleMode")
183:        If Not oProp Is Nothing Then oProp.Value = CInt(3) ' 3 = vbPixels
184:    End If
End Sub

'Adding Tabs with a toolbar and maximize the Window:
Private Function AddToAddInCommandBar(sCaption As String) As Office.CommandBarControl
Dim cbMenuCommandBar As Office.CommandBarControl
Dim cbMenu As Office.CommandBar
  
192:    On Error GoTo ErrHandler
   
194:    Set cbMenu = gVBInstance.CommandBars("Add-Ins")
195:    If cbMenu Is Nothing Then Exit Function
   
197:    Set cbMenuCommandBar = cbMenu.Controls.Add(1)
198:    cbMenuCommandBar.Caption = sCaption
   
200:    Set AddToAddInCommandBar = cbMenuCommandBar
   
202:    Exit Function
    
ErrHandler:
End Function

Private Sub CreateToolbar()
Dim i As Long

210:    On Error GoTo CreateToolbar_Error

212:    DeleteToolBar
213:    gVBInstance.CommandBars.Add TOOLBARNAME, msoBarTop, , True

215:    For i = 0 To Screen.Width / Screen.TwipsPerPixelX / 550
216:       AddButton
217:    Next i

219:    With gVBInstance.CommandBars(TOOLBARNAME)
220:       .Visible = True
221:       .Protection = msoBarNoMove
222:       .Height = TOOLBAR_HEIGHT
223:    End With

225:    On Error GoTo 0
226:    Exit Sub

CreateToolbar_Error:
229:    If Err.Number = -2147467259 And InStr(Err.Description, "'~'") > 0 Then
230:       Resume Next
231:    Else
232:       MsgBox "Error " & Err.Number & " (" & Err.Description & ") in procedure CreateToolbar of Designer Connect"
233:    End If
End Sub

Private Sub AddButton()
237:    On Error GoTo ErrHandler
238:    With gVBInstance.CommandBars(TOOLBARNAME).Controls.Add
239:       .Height = TOOLBAR_HEIGHT - 2
240:       .Style = msoButtonCaption
241:       .Width = 550
242:       .Enabled = False
243:    End With
244:    MaximizeCodeAndDesignWindows
   
246:    If Not gVBInstance.ActiveCodePane Is Nothing Then
247:        NumberCodePane gVBInstance.ActiveCodePane.CodeModule
248:    End If

ErrHandler:
End Sub

Private Sub DeleteToolBar()
254:    On Error Resume Next
255:    gVBInstance.CommandBars(TOOLBARNAME).Delete
End Sub

Private Sub MaximizeCodeAndDesignWindows()
259:    On Error Resume Next

   Dim CP As VBIDE.CodePane
262:    For Each CP In gVBInstance.CodePanes
263:        If Not CP Is Nothing Then
264:            If CP.Window.Visible Then
265:                CP.Window.WindowState = vbext_ws_Maximize
266:            End If
           
268:            If Not CP.CodeModule Is Nothing Then
269:                NumberCodePane CP.CodeModule
270:            End If
271:        End If
272:    Next CP

   Dim VBComp As VBIDE.VBComponent
275:    For Each VBComp In gVBInstance.ActiveVBProject.VBComponents
276:        If VBComp.Type = vbext_ct_VBForm Then
277:            If VBComp.HasOpenDesigner Then
278:                VBComp.DesignerWindow.WindowState = vbext_ws_Maximize
279:            End If
280:        End If
281:    Next VBComp
End Sub

' ================================================
' Adding Lines Numbers on VB6 IDE
' ================================================

Private Sub LineNumAddHandler_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
289:    AddLineNumbers
End Sub

Private Sub LineNumRemoveHandler_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
293:    RemoveLineNumbers
End Sub

Private Sub NumberCodePane(oModule As VBIDE.CodeModule)
   Dim i          As Long
   Dim sLine      As String
   Dim sTrim      As String
   Dim bContinues As Boolean
   Dim bInBlock   As Boolean
   Dim bInProc    As Boolean
   Dim bIsLabel   As Boolean
   Dim bIsCase    As Boolean

306:    On Error Resume Next
307:    If oModule Is Nothing Then Exit Sub

309:    bContinues = False
310:    bInBlock = False
311:    bInProc = False

313:    For i = 1 To oModule.CountOfLines
314:        sLine = oModule.Lines(i, 1)
       
316:        If LineHasNumber(sLine) Then
           Dim posCol As Integer
318:            posCol = InStr(sLine, ":")
319:            sTrim = Trim$(Mid$(sLine, posCol + 1))
320:        Else
321:            sTrim = Trim$(sLine)
322:        End If

324:        bIsCase = (Left$(UCase$(sTrim), 5) = "CASE ")

       If Right$(sTrim, 1) = ":" _
          And Not bIsCase _
          And InStr(Replace(sTrim, " ", ""), ":") = Len(Replace(sTrim, " ", "")) Then
329:            bIsLabel = True
330:        Else
331:            bIsLabel = False
332:        End If

       If Left$(sTrim, 5) = "Type " Or Left$(sTrim, 13) = "Private Type " Or _
          Left$(sTrim, 12) = "Public Type " Or Left$(sTrim, 5) = "Enum " Or _
          Left$(sTrim, 13) = "Private Enum " Or Left$(sTrim, 12) = "Public Enum " Then
337:            bInBlock = True
338:        End If

       If (InStr(sTrim, "Sub ") > 0 Or InStr(sTrim, "Function ") > 0 Or InStr(sTrim, "Property ") > 0) _
          And InStr(sTrim, "Declare ") = 0 _
          And Left$(sTrim, 1) <> "'" And Left$(UCase$(sTrim), 4) <> "REM " Then
343:            bInProc = True
344:        End If

346:        If bInProc And Not bInBlock And Not bContinues And Not bIsLabel And Not bIsCase Then
347:            If Not IsDeclarationLine(sTrim) Then
348:                If Not LineHasNumber(sLine) Then
349:                    oModule.ReplaceLine i, CStr(i) & ": " & sLine
350:                End If
351:            End If
352:        End If

354:        bContinues = (Right$(sTrim, 1) = "_")

356:        If sTrim = "End Type" Or sTrim = "End Enum" Then bInBlock = False
357:        If sTrim = "End Sub" Or sTrim = "End Function" Or sTrim = "End Property" Then bInProc = False
358:    Next i
End Sub

Private Sub AddLineNumbers()
   Dim oPane   As VBIDE.CodePane
   Dim oModule As VBIDE.CodeModule

365:    On Error GoTo ErrHandler

367:    Set oPane = gVBInstance.ActiveCodePane
368:    If oPane Is Nothing Then
369:        MsgBox "Abre um Code Window primeiro!", vbInformation
370:        Exit Sub
371:    End If

373:    Set oModule = oPane.CodeModule
374:    NumberCodePane oModule

376:    Exit Sub

ErrHandler:
379:    MsgBox "Erro: " & Err.Description
End Sub

Private Sub RemoveLineNumbers()
   Dim oPane   As VBIDE.CodePane
   Dim oModule As VBIDE.CodeModule
   Dim i       As Long
   Dim sLine   As String
   Dim Pos     As Integer

389:    On Error GoTo ErrHandler

391:    Set oPane = gVBInstance.ActiveCodePane
392:    If oPane Is Nothing Then Exit Sub

394:    Set oModule = oPane.CodeModule

396:    For i = 1 To oModule.CountOfLines
397:        sLine = oModule.Lines(i, 1)
398:        If LineHasNumber(sLine) Then
399:            Pos = InStr(sLine, ":")
400:            oModule.ReplaceLine i, Mid$(sLine, Pos + 2)
401:        End If
402:    Next i

404:    Exit Sub

ErrHandler:
407:    MsgBox "Erro: " & Err.Description
End Sub

Private Function IsDeclarationLine(sLine As String) As Boolean
   Dim s As String
412:    s = Trim$(sLine)

414:    If Len(s) = 0 Then IsDeclarationLine = True: Exit Function
415:    If Right$(s, 1) = "_" Then IsDeclarationLine = True: Exit Function
416:    If Left$(s, 1) = "," Then IsDeclarationLine = True: Exit Function
417:    If Left$(s, 1) = ")" Then IsDeclarationLine = True: Exit Function
418:    If Left$(s, 1) = "(" Then IsDeclarationLine = True: Exit Function
419:    If Left$(s, 1) = "'" Then IsDeclarationLine = True: Exit Function
420:    If Left$(UCase$(s), 4) = "REM " Then IsDeclarationLine = True: Exit Function

   Dim keywords() As String
   keywords = Split( _
       "Sub ,Function ,Property ,End Sub,End Function,End Property," & _
       "Private Sub,Public Sub,Friend Sub," & _
       "Private Function,Public Function,Friend Function," & _
       "Private Property,Public Property,Friend Property," & _
       "Dim ,Private ,Public ,Friend ,Static ," & _
       "Option ,Const ,Type ,End Type," & _
       "Implements ,Event ,Event ,Enum ,End Enum," & _
       "Attribute ,#If,#Else,#ElseIf,#End,#Const," & _
       "Declare ,ReDim ", ",")

   Dim i As Integer
435:    For i = 0 To UBound(keywords)
436:        If Left$(s, Len(keywords(i))) = keywords(i) Then
437:            IsDeclarationLine = True
438:            Exit Function
439:        End If
440:    Next i
End Function

Private Function LineHasNumber(sLine As String) As Boolean
   Dim s   As String
   Dim Pos As Integer
446:    s = Trim$(sLine)
447:    Pos = InStr(s, ":")
448:    If Pos > 1 Then
449:        LineHasNumber = IsNumeric(Left$(s, Pos - 1))
450:    End If
End Function

