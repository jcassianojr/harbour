FindZeroFiles 1.2.3

Content plugin to find files contain only zeros (x00).


*** Installation ***

Just enter to archive with plugin and TC ask you about plugin installing. 
Create new columns set (Configuration - Options - Custom columns - New).
Add new column with 'findzerofiles' field.


*** License agreement ***

This software provided "AS-IS" without warranty of any kind for non-commercial use.


*** Changes history ***

Ver 1.2.2:
 * internal changes.

Ver 1.2.3:
 * ASLR High Entropy ready.


---
Suggestions, Wishes and bug reports are welcome!
ProgMan13, (ProgMan13@mail.ru)