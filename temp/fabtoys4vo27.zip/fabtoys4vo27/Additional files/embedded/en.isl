﻿[LangOptions]
LanguageName=湅汧獩
LanguageID=$0409
LanguageCodePage=0
DialogFontName=MS Shell Dlg
TitleFontName=Arial
WelcomeFontName=Verdana
CopyrightFontName=Arial
DialogFontSize=8
TitleFontSize=29
WelcomeFontSize=12
CopyrightFontSize=8
