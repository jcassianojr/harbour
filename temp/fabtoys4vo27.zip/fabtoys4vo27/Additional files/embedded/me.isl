﻿[LangOptions]
LanguageName=牆湥档
LanguageID=$0040
LanguageCodePage=0
DialogFontName=MS Shell Dlg
TitleFontName=Arial
WelcomeFontName=Verdana
CopyrightFontName=Arial
DialogFontSize=8
TitleFontSize=29
WelcomeFontSize=12
CopyrightFontSize=8
