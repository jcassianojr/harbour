﻿; Created by "innounp" version 2.67.9
; Setup file: fabtoys4vo27.exe
; Inno Setup Version: 4.0.10

[Setup]
AppName=FabToys 4 VO 2.7
AppVerName=FabToys 4 VO 2.7
AppId=FabToys 4 VO 2.7
AppPublisher=Fabrice Foray
AppPublisherURL=http://www.fabtoys.net
AppCopyright=FabToys 4 VO 2.7,Copyright Fabrice Foray
AppSupportURL=http://www.fabtoys.net
AppUpdatesURL=http://www.fabtoys.net
AppMutex=FabToys4VO2.7FabSetupMutex
DefaultDirName=C:\CAVO27\FabToys
DefaultGroupName=Fab Toys
OutputBaseFilename=setup
Compression=zip
PrivilegesRequired=none
DisableProgramGroupPage=yes
ChangesAssociations=no
ShowLanguageDialog=yes
AllowNoIcons=yes
InfoBeforeFile=embedded\InfoBefore.txt
InfoAfterFile=embedded\InfoAfter.txt
WizardImageFile=embedded\WizardImage0.bmp
WizardSmallImageFile=embedded\WizardSmallImage0.bmp

[Files]
Source: "{app}\cmax20.dll"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab4Twain.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab AutoDoc 4.0_12.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab AutoDoc IDE.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab AutoDoc Lib.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Ctrl.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Dir Watch Test.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Dir Watch.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Ed.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab ImgView.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Inno Setup Lib.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Inno Setup.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab IPC.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab OutlookBar Lib.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab PaintLib 2_0.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab PaintLib Control 2_0.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab PaintLib Enh Test.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab SplitShell Lib.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab SplitShell Test3.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab SplitShell Test.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab SplitTest2.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Stream.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Thread.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Tools.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Twain Test.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab Twain.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab VO Entities.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\Fab VO Repository.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\FabPaint.dll"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\msvcp71.dll"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\SDKDef27.aef"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\VO-CodeMax DLL.AEF"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\ReadMe.txt"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\PaintLib.txt"; DestDir: "{app}"; Flags: ignoreversion 
Source: "{app}\FabToys4VO27.iss"; DestDir: "{app}"; Flags: ignoreversion 

[INI]
FileName: "{app}\FabToys 4 VO 2.7.url"; Section: "InternetShortcut"; Key: "URL"; String: "http://www.fabtoys.net"; 

[Icons]
Name: "{group}\FabToys 4 VO 2.7"; Filename: "{app}\"; 
Name: "{group}\FabToys 4 VO 2.7 WWW"; Filename: "{app}\FabToys 4 VO 2.7.url"; 
Name: "{group}\Uninstall FabToys 4 VO 2.7"; Filename: "{uninstallexe}"; 

[UninstallDelete]
Type: files; Name: "{app}\FabToys 4 VO 2.7.url"; 

[Languages]
; These files are stubs
; To achieve better results after recompilation, use the real language files
Name: "en"; MessagesFile: "embedded\en.isl"; 
Name: "me"; MessagesFile: "embedded\me.isl"; 
