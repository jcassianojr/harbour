Hi,
you will find some of my free tools for VO2.7
All comes with full source and free of use.
( Refer to each AEF for more specific info. )

You can re-read these steps in "ReadMe.txt"
This Setup has been made using FabInnoSetup, and modified by hands for specific feature. The source script "FabToys4VO27.iss" is available as a sample in your FabToys folder.

To use these tools, the easiest is to first import various lib and tools
Create a project then import and build in the following order

Fab Tools
Fab Ctrl
Fab Thread
Fab Stream
Fab IPC
VO-CodeMax DLL
Fab PaintLib 2.0
Fab PaintLib Control 2.0
Fab SplitShell Lib
Fab OutlookBar Lib
Fab Twain
Fab Dir Watch
SDKDef27 ( from the SDK )
Fab VO Entities
Fab VO Repository

                    
then

Fab SplitShell Test, to test the SplitShell alone
Fab SplitTest 2, to test SplitShell and OutlookBar
Fab SplitTest 3, ""         ""             ""

Fab Twain Test, to Test Fab TWain and FabPaintLib Ctrl
Fab4Twain,          "    "    "

Fab Dir Watch Test, to test Fab Dir Watch and Fab Thread

Fab Ed, to test CodeMax control
( To use FaEd, you need to copy "cmax20.dll" into your CAVO27\Bin folder )

Fab AutoDoc Lib
Fab AutoDoc 4.0, to Test Fab VO Entitites and Repository

Fab Inno Setup Lib
Fab Inno Setup, to test Fab VO Entitites and Repository
( you need to download and install the latest InnoSetup package at www.innosetup.com to test this one )


Fab ImgView, to test Fab PaintLib
Fab PaintLib Enh Test, to test Fab PaintLib and FabPaintLib Ctrl and new EXIF Tag extraction
( To Use Fab PaintLib, you need to copy "FabPaint.DLL" and "msvcp71.dll" into your CAVO27\Bin folder )
( Look at PaintLib.txt for more info about supported file format )

Hope all these will feed your needs ! ;-)

Happy VOing

Fabrice Foray
fabrice@fabtoys.net
www.fabtoys.net