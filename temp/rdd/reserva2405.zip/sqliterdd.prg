// +--------------------------------------------------------------------
// +    Programa  : sqliterdd.prg
// +    Linguagem : Harbour / xHarbour 
// +    Objetivo  : RDD SQLite3 - Estrutura Espelhada nas Refer�ncias Ativas
// +--------------------------------------------------------------------

#include "rddsys.ch"
#include "fileio.ch"
#include "error.ch"
#include "dbstruct.ch"
#include "common.ch"

#define HB_RNET_OK       0
#define HB_RNET_ERROR    -1

// �ndices da �rea de Trabalho da WorkArea (Buffer)
#define WA_DB_HANDLE    1   
#define WA_STMT_HANDLE  2   
#define WA_TABLE_NAME   3   
#define WA_EOF          4   
#define WA_BOF          5   
#define WA_RECNO        6   
#define WA_FIELDS_NAME  7   
#define WA_FIELDS_TYPE  8   
#define WA_BUFFER       9   
#define WA_LEN          9

ANNOUNCE SL3RDD

// 1. INICIALIZA��O PARALELA AO ADORDD
INIT PROCEDURE SL3_InitRDD()
   rddRegister( "SL3RDD", SL3RDD_GETFUNCTABLE() )
RETURN

// +--------------------------------------------------------------------
// +    M�TODOS OPERACIONAIS REAIS DA RDD
// +--------------------------------------------------------------------

FUNCTION SL3_INIT( nWA ) ; RETURN HB_RNET_OK

FUNCTION SL3_NEW( nWA )
   USRRDD_AREADATA( nWA, Array( WA_LEN ) )
RETURN HB_RNET_OK

FUNCTION SL3_CREATE( nWA, aOpenInfo )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   LOCAL cDatabase := aOpenInfo[ 1 ]
   LOCAL aStruct := aOpenInfo[ 2 ]
   LOCAL cTable := hb_FNameName( cDatabase )
   LOCAL cSql, i, db
   
   db := SQLITE3_OPEN( cDatabase + ".db" )
   IF Empty( db )
      RETURN HB_RNET_ERROR
   ENDIF
   
   cSql := "CREATE TABLE IF NOT EXISTS " + cTable + " ( "
   cSql += "ROWID INTEGER PRIMARY KEY AUTOINCREMENT, "
   
   FOR i := 1 TO Len( aStruct )
      cSql += aStruct[i][ DBS_NAME ] + " "
      DO CASE
         CASE aStruct[i][ DBS_TYPE ] == "C" ; cSql += "TEXT"
         CASE aStruct[i][ DBS_TYPE ] == "N" ; cSql += "NUMERIC"
         CASE aStruct[i][ DBS_TYPE ] == "D" ; cSql += "TEXT"
         CASE aStruct[i][ DBS_TYPE ] == "L" ; cSql += "INTEGER"
         OTHERWISE                          ; cSql += "TEXT"
      ENDCASE
      IF i < Len( aStruct )
         cSql += ", "
      ENDIF
   NEXT
   cSql += " );"
   
   SQLITE3_EXEC( db, cSql )
   SQLITE3_CLOSE( db )
   
RETURN SL3_OPEN( nWA, aOpenInfo )

FUNCTION SL3_OPEN( nWA, aOpenInfo )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   LOCAL cDatabase := aOpenInfo[ 1 ]
   LOCAL cTable := hb_FNameName( cDatabase )
   LOCAL stmt, i, nCols
   
   pWA[ WA_DB_HANDLE ] := SQLITE3_OPEN( cDatabase + ".db" )
   IF Empty( pWA[ WA_DB_HANDLE ] )
      RETURN HB_RNET_ERROR
   ENDIF
   
   pWA[ WA_TABLE_NAME ] := cTable
   pWA[ WA_RECNO ]      := 1
   pWA[ WA_BOF ]        := .F.
   pWA[ WA_EOF ]        := .F.
   
   stmt := SQLITE3_PREPARE_V2( pWA[ WA_DB_HANDLE ], "SELECT * FROM " + cTable + " LIMIT 1" )
   IF !Empty( stmt )
      nCols := SQLITE3_COLUMN_COUNT( stmt )
      pWA[ WA_FIELDS_NAME ] := Array( nCols )
      pWA[ WA_FIELDS_TYPE ] := Array( nCols )
      pWA[ WA_BUFFER ]      := Array( nCols )
      
      FOR i := 1 TO nCols
         pWA[ WA_FIELDS_NAME ][i] := SQLITE3_COLUMN_NAME( stmt, i - 1 )
         pWA[ WA_FIELDS_TYPE ][i] := "C"
      NEXT
      SQLITE3_FINALIZE( stmt )
   ENDIF
   
   UR_SUPER_OPEN( nWA, aOpenInfo )
RETURN HB_RNET_OK

FUNCTION SL3_CLOSE( nWA )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   IF !Empty( pWA[ WA_DB_HANDLE ] )
      SQLITE3_CLOSE( pWA[ WA_DB_HANDLE ] )
   ENDIF
RETURN UR_SUPER_CLOSE( nWA )

FUNCTION SL3_GETVALUE( nWA, nField, xVal )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   LOCAL stmt, cSql
   
   IF pWA[ WA_BUFFER ][ nField ] != NIL
      xVal := pWA[ WA_BUFFER ][ nField ]
      RETURN HB_RNET_OK
   ENDIF
   
   cSql := "SELECT " + pWA[ WA_FIELDS_NAME ][ nField ] + " FROM " + pWA[ WA_TABLE_NAME ] + " WHERE ROWID = " + LTrim(Str(pWA[ WA_RECNO ]))
   stmt := SQLITE3_PREPARE_V2( pWA[ WA_DB_HANDLE ], cSql )
   
   IF !Empty( stmt )
      IF SQLITE3_STEP( stmt ) == 100 
         xVal := SQLITE3_COLUMN_VALUE( stmt, 0 )
      ENDIF
      SQLITE3_FINALIZE( stmt )
   ENDIF
RETURN HB_RNET_OK

FUNCTION SL3_PUTVALUE( nWA, nField, xVal )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   pWA[ WA_BUFFER ][ nField ] := xVal
RETURN HB_RNET_OK

FUNCTION SL3_FLUSH( nWA )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   LOCAL cSql, i, xVal
   
   cSql := "UPDATE " + pWA[ WA_TABLE_NAME ] + " SET "
   FOR i := 1 TO Len( pWA[ WA_BUFFER ] )
      IF pWA[ WA_BUFFER ][i] != NIL
         xVal := pWA[ WA_BUFFER ][i]
         cSql += pWA[ WA_FIELDS_NAME ][i] + " = "
         IF ValType( xVal ) == "C"
            cSql += "'" + xVal + "'"
         ELSEIF ValType( xVal ) == "N"
            cSql += LTrim(Str(xVal))
         ENDIF
         cSql += ", "
      ENDIF
   NEXT
   
   IF Right( cSql, 2 ) == ", "
      cSql := SubStr( cSql, 1, Len( cSql ) - 2 )
      cSql += " WHERE ROWID = " + LTrim(Str(pWA[ WA_RECNO ]))
      SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], cSql )
      AFill( pWA[ WA_BUFFER ], NIL )
   ENDIF
RETURN HB_RNET_OK

FUNCTION SL3_GOTOP( nWA )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   pWA[ WA_RECNO ] := 1 ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F.
RETURN HB_RNET_OK

FUNCTION SL3_GOBOTTOM( nWA )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   pWA[ WA_RECNO ] := 10 ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F.
RETURN HB_RNET_OK

FUNCTION SL3_GOTO( nWA, nRec )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   IF ValType( nRec ) == "N" .AND. nRec > 0
      pWA[ WA_RECNO ] := nRec ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F.
   ENDIF
RETURN HB_RNET_OK

FUNCTION SL3_GOTOID( nWA, nRec ) ; RETURN SL3_GOTO( nWA, nRec )

FUNCTION SL3_SKIP( nWA, nRecs )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   IF nRecs == 0 ; RETURN HB_RNET_OK ; ENDIF
   pWA[ WA_RECNO ] += nRecs
RETURN HB_RNET_OK

FUNCTION SL3_APPEND( nWA, lUnLock )
   LOCAL pWA := USRRDD_AREADATA( nWA )
   SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], "INSERT INTO " + pWA[ WA_TABLE_NAME ] + " DEFAULT VALUES" )
   pWA[ WA_RECNO ] += 1 
RETURN HB_RNET_OK

FUNCTION SL3_DELETE( nWA ) ; RETURN HB_RNET_OK
FUNCTION SL3_DELETED( nWA, lDeleted ) ; lDeleted := .F. ; RETURN HB_RNET_OK
FUNCTION SL3_RECID( nWA, nRecNo ) ; nRecNo := USRRDD_AREADATA( nWA )[ WA_RECNO ] ; RETURN HB_RNET_OK
FUNCTION SL3_RECCOUNT( nWA, nRecords ) ; nRecords := 10 ; RETURN HB_RNET_OK
FUNCTION SL3_BOF( nWA, lBof ) ; lBof := USRRDD_AREADATA( nWA )[ WA_BOF ] ; RETURN HB_RNET_OK
FUNCTION SL3_EOF( nWA, lEof ) ; lEof := USRRDD_AREADATA( nWA )[ WA_EOF ] ; RETURN HB_RNET_OK

// +--------------------------------------------------------------------
// +  2. MAPEAMENTO PARALELO DE PAR�METROS - ID�NTICO AO SEU ADORDD
// +--------------------------------------------------------------------
FUNCTION SL3RDD_GETFUNCTABLE( pFuncCount, pFuncTable, pSuperTable, nRddID )
   LOCAL cSuperRDD := "DBFNTX" 
   LOCAL aMyFunc := Array( 100 )

   aMyFunc[  1 ] := ( @SL3_INIT() )
   aMyFunc[  2 ] := ( @SL3_NEW() )
   aMyFunc[  3 ] := ( @SL3_OPEN() )
   aMyFunc[  4 ] := ( @SL3_CLOSE() )
   aMyFunc[  7 ] := ( @SL3_CREATE() )
   aMyFunc[ 10 ] := ( @SL3_GOTOP() )
   aMyFunc[ 11 ] := ( @SL3_GOBOTTOM() )
   aMyFunc[ 12 ] := ( @SL3_GOTO() )
   aMyFunc[ 13 ] := ( @SL3_GOTOID() )
   aMyFunc[ 14 ] := ( @SL3_SKIP() )
   aMyFunc[ 18 ] := ( @SL3_GETVALUE() )
   aMyFunc[ 19 ] := ( @SL3_PUTVALUE() )
   aMyFunc[ 22 ] := ( @SL3_APPEND() )
   aMyFunc[ 23 ] := ( @SL3_DELETE() )
   aMyFunc[ 26 ] := ( @SL3_RECID() )
   aMyFunc[ 27 ] := ( @SL3_RECCOUNT() )
   aMyFunc[ 32 ] := ( @SL3_BOF() )
   aMyFunc[ 33 ] := ( @SL3_EOF() )
   aMyFunc[ 34 ] := ( @SL3_DELETED() )
   aMyFunc[ 40 ] := ( @SL3_FLUSH() )

   // Retorno estruturado exigido pela engine USRRDD
   RETURN USRRDD_GETFUNCTABLE( pFuncCount, pFuncTable, pSuperTable, nRddID, aMyFunc, cSuperRDD )


#pragma BEGINDUMP
#include "hbapi.h"
#include "sqlite3.h"

HB_FUNC( SQLITE3_OPEN ) {
   sqlite3 * db = NULL;
   if( sqlite3_open( hb_parc( 1 ), &db ) == SQLITE_OK ) hb_retptr( ( void * ) db );
   else hb_ret();
}
HB_FUNC( SQLITE3_CLOSE ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   hb_retni( db ? sqlite3_close( db ) : -1 );
}
HB_FUNC( SQLITE3_EXEC ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   const char * sql = hb_parc( 2 );
   hb_retni( ( db && sql ) ? sqlite3_exec( db, sql, NULL, NULL, NULL ) : -1 );
}
HB_FUNC( SQLITE3_PREPARE_V2 ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   const char * sql = hb_parc( 2 );
   sqlite3_stmt * stmt = NULL;
   if( db && sql && sqlite3_prepare_v2( db, sql, -1, &stmt, NULL ) == SQLITE_OK ) hb_retptr( ( void * ) stmt );
   else hb_ret();
}
HB_FUNC( SQLITE3_STEP ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_step( stmt ) : -1 );
}
HB_FUNC( SQLITE3_FINALIZE ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_finalize( stmt ) : -1 );
}
HB_FUNC( SQLITE3_COLUMN_COUNT ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_column_count( stmt ) : 0 );
}
HB_FUNC( SQLITE3_COLUMN_NAME ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retc( stmt ? sqlite3_column_name( stmt, hb_parni( 2 ) ) : "" );
}
HB_FUNC( SQLITE3_COLUMN_VALUE ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   int iCol = hb_parni( 2 );
   if( stmt ) {
      int iType = sqlite3_column_type( stmt, iCol );
      if( iType == SQLITE_INTEGER ) hb_retnd( ( double ) sqlite3_column_int64( stmt, iCol ) );
      else if( iType == SQLITE_FLOAT ) hb_retnd( sqlite3_column_double( stmt, iCol ) );
      else hb_retc( ( const char * ) sqlite3_column_text( stmt, iCol ) );
   } else hb_ret();
}
#pragma ENDDUMP