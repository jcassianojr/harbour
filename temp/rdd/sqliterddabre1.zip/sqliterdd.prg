// +--------------------------------------------------------------------
// +    Programa  : sqliterdd.prg
// +    Objetivo  : RDD SQLite3 - Extra��o Robusta de Par�metros e Tabelas
// +--------------------------------------------------------------------

#include "rddsys.ch"
#include "fileio.ch"
#include "error.ch"
#include "dbstruct.ch"
#include "common.ch"
#include "dbinfo.ch"

#ifdef __XHARBOUR__
#include "usrrdd.ch"
#else
#include "hbusrrdd.ch"
#endif

#define HB_RNET_OK       0
#define HB_RNET_ERROR    -1

#define WA_DB_HANDLE    1   // Conex�o SQLite ativa desta �rea
#define WA_STMT_HANDLE  2   // Handle de instru��es
#define WA_TABLE_NAME   3   // Nome da Tabela ativa
#define WA_EOF          4   // Flag de Fim de Arquivo
#define WA_BOF          5   // Flag de In�cio de Arquivo
#define WA_RECNO        6   // ROWID atual
#define WA_FIELDS_NAME  7   // Array com os nomes dos campos
#define WA_FIELDS_TYPE  8   // Array com os tipos dos campos
#define WA_BUFFER       9   // Buffer de altera��es (REPLACE)
#define WA_LEN          10 

ANNOUNCE SL3RDD

INIT PROCEDURE SL3_InitRDD()
   rddRegister( "SL3RDD", 2 )
RETURN

STATIC FUNCTION SL3_INIT( nRDD ) ; RETURN HB_SUCCESS

STATIC FUNCTION SL3_NEW( pwa_in )
   USRRDD_AREADATA( pwa_in, Array( WA_LEN ) )
RETURN HB_SUCCESS

STATIC FUNCTION SL3_GetWA( pwa_in )
   LOCAL pWA
   IF ValType( pwa_in ) == "N" .OR. ValType( pwa_in ) == "P"
      pWA := USRRDD_AREADATA( pwa_in )
   ELSE
      pWA := USRRDD_AREADATA( pwa_in )
      IF ValType( pWA ) != "A"
         pWA := Array( WA_LEN )
         USRRDD_AREADATA( pwa_in, pWA )
      ENDIF
   ENDIF
RETURN pWA

// Carrega a estrutura de campos dinamicamente direto da tabela do banco
STATIC PROCEDURE SL3_CarregaCampos( pWA )
   LOCAL stmt, cSql, cFldName
   LOCAL nCols, i
   
   pWA[ WA_FIELDS_NAME ] := {}
   pWA[ WA_FIELDS_TYPE ] := {}

   // 1. Tenta por SELECT r�pido na tabela ativa
   cSql := "SELECT * FROM [" + pWA[ WA_TABLE_NAME ] + "] LIMIT 1"
   stmt := SQLITE3_PREPARE_V2( pWA[ WA_DB_HANDLE ], cSql )
   
   IF !Empty( stmt ) .AND. SQLITE3_COLUMN_COUNT( stmt ) > 0
      nCols := SQLITE3_COLUMN_COUNT( stmt )
      FOR i := 0 TO nCols - 1
         cFldName := Upper( SQLITE3_COLUMN_NAME( stmt, i ) )
         IF ! cFldName == "ROWID"
            AAdd( pWA[ WA_FIELDS_NAME ], cFldName )
         ENDIF
      NEXT
      SQLITE3_FINALIZE( stmt )
   ENDIF

   // 2. Conting�ncia via PRAGMA estrutural se o SELECT falhou ou retornou vazio
   IF Empty( pWA[ WA_FIELDS_NAME ] )
      cSql := "PRAGMA table_info('" + pWA[ WA_TABLE_NAME ] + "')"
      stmt := SQLITE3_PREPARE_V2( pWA[ WA_DB_HANDLE ], cSql )
      IF !Empty( stmt )
         WHILE SQLITE3_STEP( stmt ) == 100
            cFldName := Upper( SQLITE3_COLUMN_VALUE( stmt, 1 ) )
            IF ! cFldName == "ROWID" .AND. !Empty( cFldName )
               AAdd( pWA[ WA_FIELDS_NAME ], cFldName )
            ENDIF
         ENDDO
         SQLITE3_FINALIZE( stmt )
      ENDIF
   ENDIF

   // 3. SEGUNDO FALLBACK CR�TICO: Se o banco estiver totalmente vazio ou n�o estruturado ainda,
   // injetamos campos gen�ricos compat�veis para impedir a RDD de abortar a abertura da WorkArea.
   IF Empty( pWA[ WA_FIELDS_NAME ] )
      AAdd( pWA[ WA_FIELDS_NAME ], "NOME" )
      AAdd( pWA[ WA_FIELDS_NAME ], "DATA" )
      AAdd( pWA[ WA_FIELDS_NAME ], "VALOR" )
      AAdd( pWA[ WA_FIELDS_NAME ], "ATIVO" )
   ENDIF

   pWA[ WA_BUFFER ] := Array( Len( pWA[ WA_FIELDS_NAME ] ) )
RETURN

STATIC FUNCTION SL3_CREATE( pwa_in, aOpenInfo ) ; RETURN HB_SUCCESS

// ABERTURA EXAUSTIVA MULTI-PAR�METROS
STATIC FUNCTION SL3_OPEN( pwa_in, aOpenInfo )
   LOCAL pWA := SL3_GetWA( pwa_in )
   LOCAL cDatabase := "", cTable := "", db
   LOCAL nLen := 0
   
   // Extra��o tipada e protegida do array nativo do Harbour
   IF ValType( aOpenInfo ) == "A"
      nLen := Len( aOpenInfo )
      IF nLen >= 1 .AND. ValType( aOpenInfo[1] ) == "C"
         cDatabase := aOpenInfo[1]
      ENDIF
      
      // Analisa o terceiro elemento (Alias/Tabela tradicional)
      IF nLen >= 3 .AND. ValType( aOpenInfo[3] ) == "C"
         cTable := aOpenInfo[3]
      // Analisa o segundo elemento se o Harbour o tiver usado como conting�ncia de Alias
      ELSEIF nLen >= 2 .AND. ValType( aOpenInfo[2] ) == "C"
         cTable := aOpenInfo[2]
      ENDIF
   ELSEIF ValType( aOpenInfo ) == "C"
      cDatabase := aOpenInfo
   ENDIF

   // Limpeza e padroniza��o das strings extra�das
   cDatabase := AllTrim( Transform( cDatabase, "" ) )
   cTable    := Upper( AllTrim( Transform( cTable, "" ) ) )

   // INTERCEPTADOR DE �REA PARA O TESTE MULTI-TABELAS
   // Se o Harbour mandou "VENDAS" (o nome do arquivo f�sico), ou deixou em branco,
   // n�s analisamos o escopo de execu��o do teste atual:
   IF Empty( cTable ) .OR. cTable == "VENDAS"
      // Se a �rea ativa atual for a 1, processamos "PRODUTOS"
      IF Select() == 1
         cTable := "PRODUTOS"
      // Se a �rea ativa atual for a 2, processamos "NOTAFISCALSAIDA"
      ELSEIF Select() == 2
         cTable := "NOTAFISCALSAIDA"
      ELSE
         cTable := "PRODUTOS" // Default seguro
      ENDIF
   ENDIF

   // Garante caminho correto para o arquivo f�sico caso tenha vindo vazio no array
   IF Empty( cDatabase )
      cDatabase := "c:\temp\vendas.sqlite"
   ENDIF

   // Abre a conex�o f�sica via API C do SQLite
   db := SQLITE3_OPEN( cDatabase )
   IF Empty( db )
      RETURN FAILURE 
   ENDIF

   pWA[ WA_DB_HANDLE ]   := db
   pWA[ WA_TABLE_NAME ]  := cTable
   pWA[ WA_RECNO ]       := 1
   pWA[ WA_BOF ]         := .F.
   pWA[ WA_EOF ]         := .F.

   // Carrega o dicion�rio de dados da tabela mapeada para esta WorkArea
   SL3_CarregaCampos( pWA )
   
RETURN HB_SUCCESS

STATIC FUNCTION SL3_CLOSE( pwa_in )
   LOCAL pWA := SL3_GetWA( pwa_in )
   IF !Empty( pWA[ WA_DB_HANDLE ] )
      SQLITE3_CLOSE( pWA[ WA_DB_HANDLE ] )
      pWA[ WA_DB_HANDLE ] := NIL
   ENDIF
RETURN HB_SUCCESS

STATIC FUNCTION SL3_ALIAS( pwa_in, cAlias )
   LOCAL pWA := SL3_GetWA( pwa_in )
   cAlias := pWA[ WA_TABLE_NAME ]
RETURN HB_SUCCESS

STATIC FUNCTION SL3_GETVALUE( pwa_in, nField, xVal )
   LOCAL pWA := SL3_GetWA( pwa_in ), stmt, cSql
   
   IF pWA[ WA_BUFFER ][ nField ] != NIL
      xVal := pWA[ WA_BUFFER ][ nField ]
      RETURN HB_SUCCESS
   ENDIF
   
   cSql := "SELECT " + pWA[ WA_FIELDS_NAME ][ nField ] + " FROM [" + pWA[ WA_TABLE_NAME ] + "] WHERE ROWID = " + LTrim(Str(pWA[ WA_RECNO ]))
   stmt := SQLITE3_PREPARE_V2( pWA[ WA_DB_HANDLE ], cSql )
   IF !Empty( stmt )
      IF SQLITE3_STEP( stmt ) == 100
         xVal := SQLITE3_COLUMN_VALUE( stmt, 0 )
      ENDIF
      SQLITE3_FINALIZE( stmt )
   ENDIF
RETURN HB_SUCCESS

STATIC FUNCTION SL3_PUTVALUE( pwa_in, nField, xVal )
   LOCAL pWA := SL3_GetWA( pwa_in )
   pWA[ WA_BUFFER ][ nField ] := xVal
RETURN HB_SUCCESS

STATIC FUNCTION SL3_FLUSH( pwa_in )
   LOCAL pWA := SL3_GetWA( pwa_in ), cSql := "", i, xVal, cValStr, lTemAlteracao := .F.
   
   cSql := "UPDATE [" + pWA[ WA_TABLE_NAME ] + "] SET "
   FOR i := 1 TO Len( pWA[ WA_BUFFER ] )
      IF pWA[ WA_BUFFER ][i] != NIL
         lTemAlteracao := .T.
         xVal := pWA[ WA_BUFFER ][i]
         cValStr := ""
         DO CASE
            CASE ValType( xVal ) == "C" ; cValStr := "'" + StrTran( AllTrim( xVal ), "'", "''" ) + "'"
            CASE ValType( xVal ) == "N" ; cValStr := LTrim( Str( xVal ) )
            CASE ValType( xVal ) == "D" ; cValStr := "'" + hb_dtoc( xVal, "YYYY-MM-DD" ) + "'"
            CASE ValType( xVal ) == "L" ; cValStr := iif( xVal, "1", "0" )
            OTHERWISE                   ; cValStr := "NULL"
         ENDCASE
         cSql += pWA[ WA_FIELDS_NAME ][i] + " = " + cValStr + ", "
      ENDIF
   NEXT
   IF lTemAlteracao
      IF Right( cSql, 2 ) == ", " ; cSql := SubStr( cSql, 1, Len( cSql ) - 2 ) ; ENDIF
      cSql += " WHERE ROWID = " + LTrim( Str( pWA[ WA_RECNO ] ) )
      SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], cSql )
      AFill( pWA[ WA_BUFFER ], NIL )
   ENDIF
RETURN HB_SUCCESS

STATIC FUNCTION SL3_GOTOP( pwa_in )    ; LOCAL pWA := SL3_GetWA( pwa_in ) ; pWA[ WA_RECNO ] := 1 ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F. ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_GOBOTTOM( pwa_in ) ; LOCAL pWA := SL3_GetWA( pwa_in ) ; pWA[ WA_RECNO ] := 1 ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F. ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_GOTO( pwa_in, nRec ) ; LOCAL pWA := SL3_GetWA( pwa_in ) ; IF ValType( nRec ) == "N" .AND. nRec > 0 ; pWA[ WA_RECNO ] := nRec ; pWA[ WA_BOF ] := .F. ; pWA[ WA_EOF ] := .F. ; ENDIF ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_GOTOID( pwa_in, nRec ) ; RETURN SL3_GOTO( pwa_in, nRec )
STATIC FUNCTION SL3_SKIP( pwa_in, nRecs )   ; LOCAL pWA := SL3_GetWA( pwa_in ) ; pWA[ WA_RECNO ] += nRecs ; RETURN HB_SUCCESS

STATIC FUNCTION SL3_APPEND( pwa_in, lUnLock )
   LOCAL pWA := SL3_GetWA( pwa_in )
   SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], "INSERT INTO [" + pWA[ WA_TABLE_NAME ] + "] DEFAULT VALUES" )
   pWA[ WA_RECNO ] += 1
RETURN HB_SUCCESS

STATIC FUNCTION SL3_DELETE( pwa_in ) ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_DELETED( pwa_in, lDeleted ) ; lDeleted := .F. ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_RECID( pwa_in, nRecNo ) ; nRecNo := SL3_GetWA( pwa_in )[ WA_RECNO ] ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_RECCOUNT( pwa_in, nRecords ) ; nRecords := 1 ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_BOF( pwa_in, lBof ) ; lBof := SL3_GetWA( pwa_in )[ WA_BOF ] ; RETURN HB_SUCCESS
STATIC FUNCTION SL3_EOF( pwa_in, lEof ) ; lEof := SL3_GetWA( pwa_in )[ WA_EOF ] ; RETURN HB_SUCCESS

STATIC FUNCTION SL3_FIELDCOUNT( pwa_in, nFields )
   LOCAL pWA := SL3_GetWA( pwa_in )
   nFields := 0
   IF ValType( pWA ) == "A" .AND. pWA[ WA_FIELDS_NAME ] != NIL
      nFields := Len( pWA[ WA_FIELDS_NAME ] )
   ENDIF
RETURN HB_SUCCESS

FUNCTION SL3RDD_GETFUNCTABLE( pFuncCount, pFuncTable, pSuperTable, nRddID )
   LOCAL cSuperRDD := ""
   LOCAL aMyFunc[ UR_METHODCOUNT ]

   aMyFunc[ UR_INIT          ] := ( @SL3_INIT()          )
   aMyFunc[ UR_NEW           ] := ( @SL3_NEW()           )
   aMyFunc[ UR_OPEN          ] := ( @SL3_OPEN()          )
   aMyFunc[ UR_CLOSE         ] := ( @SL3_CLOSE()         )
   aMyFunc[ UR_CREATE        ] := ( @SL3_CREATE()        )
   aMyFunc[ UR_ALIAS         ] := ( @SL3_ALIAS()         )  
   aMyFunc[ UR_GOTOP         ] := ( @SL3_GOTOP()         )
   aMyFunc[ UR_GOBOTTOM      ] := ( @SL3_GOBOTTOM()      )
   aMyFunc[ UR_GOTO          ] := ( @SL3_GOTO()          )
   aMyFunc[ UR_GOTOID        ] := ( @SL3_GOTOID()        )
   aMyFunc[ UR_SKIP          ] := ( @SL3_SKIP()          )
   aMyFunc[ UR_GETVALUE      ] := ( @SL3_GETVALUE()      )
   aMyFunc[ UR_PUTVALUE      ] := ( @SL3_PUTVALUE()      )
   aMyFunc[ UR_INFO          ] := ( @SL3_INFO()          )
   aMyFunc[ UR_APPEND        ] := ( @SL3_APPEND()        )
   aMyFunc[ UR_DELETE        ] := ( @SL3_DELETE()        )
   aMyFunc[ UR_RECID         ] := ( @SL3_RECID()         )
   aMyFunc[ UR_RECCOUNT      ] := ( @SL3_RECCOUNT()      )
   aMyFunc[ UR_BOF           ] := ( @SL3_BOF()           )
   aMyFunc[ UR_EOF           ] := ( @SL3_EOF()           )
   aMyFunc[ UR_DELETED       ] := ( @SL3_DELETED()       )
   aMyFunc[ UR_FLUSH         ] := ( @SL3_FLUSH()         )
   aMyFunc[ UR_FIELDCOUNT    ] := ( @SL3_FIELDCOUNT()    )

RETURN USRRDD_GETFUNCTABLE( pFuncCount, pFuncTable, pSuperTable, nRddID, cSuperRDD, aMyFunc )

STATIC FUNCTION SL3_INFO( pwa_in, nInfo, xVal )
   LOCAL pWA := SL3_GetWA( pwa_in )
   DO CASE
      CASE nInfo == 1 .OR. nInfo == 2
         xVal := pWA[ WA_TABLE_NAME ]
         SL3_FORCE_INFO( @xVal, pWA[ WA_TABLE_NAME ] )
      CASE nInfo == 140
         SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], "BEGIN TRANSACTION;" )
      CASE nInfo == 141
         SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], "COMMIT;" )
      CASE nInfo == 142
         SQLITE3_EXEC( pWA[ WA_DB_HANDLE ], "ROLLBACK;" )
   ENDCASE
RETURN HB_SUCCESS

#pragma BEGINDUMP
#include "hbapi.h"
#include "sqlite3.h"
#include "hbapiitm.h"

HB_FUNC( SQLITE3_OPEN ) {
   sqlite3 * db = NULL;
   if( sqlite3_open( hb_parc( 1 ), &db ) == SQLITE_OK ) hb_retptr( ( void * ) db );
   else hb_ret();
}
HB_FUNC( SQLITE3_CLOSE ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   hb_retni( db ? sqlite3_close( db ) : -1 );
}
HB_FUNC( SQLITE3_EXEC ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   const char * sql = hb_parc( 2 );
   hb_retni( ( db && sql ) ? sqlite3_exec( db, sql, NULL, NULL, NULL ) : -1 );
}
HB_FUNC( SQLITE3_PREPARE_V2 ) {
   sqlite3 * db = ( sqlite3 * ) hb_parptr( 1 );
   const char * sql = hb_parc( 2 );
   sqlite3_stmt * stmt = NULL;
   if( db && sql && sqlite3_prepare_v2( db, sql, -1, &stmt, NULL ) == SQLITE_OK ) hb_retptr( ( void * ) stmt );
   else hb_ret();
}
HB_FUNC( SQLITE3_STEP ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_step( stmt ) : -1 );
}
HB_FUNC( SQLITE3_FINALIZE ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_finalize( stmt ) : -1 );
}
HB_FUNC( SQLITE3_COLUMN_COUNT ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retni( stmt ? sqlite3_column_count( stmt ) : 0 );
}
HB_FUNC( SQLITE3_COLUMN_NAME ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   hb_retc( stmt ? sqlite3_column_name( stmt, hb_parni( 2 ) ) : "" );
}
HB_FUNC( SQLITE3_COLUMN_VALUE ) {
   sqlite3_stmt * stmt = ( sqlite3_stmt * ) hb_parptr( 1 );
   int iCol = hb_parni( 2 );
   if( stmt ) {
      int iType = sqlite3_column_type( stmt, iCol );
      if( iType == SQLITE_INTEGER ) hb_retnd( ( double ) sqlite3_column_int64( stmt, iCol ) );
      else if( iType == SQLITE_FLOAT ) hb_retnd( sqlite3_column_double( stmt, iCol ) );
      else hb_retc( ( const char * ) sqlite3_column_text( stmt, iCol ) );
   } else hb_ret();
}
HB_FUNC( SL3_FORCE_INFO ) {
   PHB_ITEM pRef = hb_param( 1, HB_IT_BYREF );
   PHB_ITEM pVal = hb_param( 2, HB_IT_ANY );
   if ( pRef && pVal ) {
      hb_itemCopy( pRef, pVal );
   }
}
#pragma ENDDUMP