call d:\DEVPRG\hb32mgw12\hb32mgw12
hbmk2.exe rddado.hbp
rem -compr 
