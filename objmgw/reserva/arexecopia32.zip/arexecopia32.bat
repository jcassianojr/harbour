cd d:\devprg\hb32mgw12\comp\mingw\bin\
copy ar.exe i686-w64-mingw32-gcc-ar.exe
