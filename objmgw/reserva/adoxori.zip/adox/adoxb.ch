**************************************************************************************
*
* Cursor Location
*
* adUseServer           2 Atua no lado servidor
* adUseClient           3 Atua no lado cliente
*
* Cursor Type
*
* adOpenForwardOnly     0 O cursor so navega para frente. Bom para listar dados
* adOpenKeyset          1 Nao permite ver os registro adicionados e eliminados
* adOpenDynamic         2 Aceita todas operacoes do utilizador e dos outros
* adOpenStatic          3 Serve apenas para procurar dados ou gerar relatorios
*
* Lock Type Enum - Contantes de Seguranca
*
* adLockReadOnly        1 Apenas pode ler os registros
* adLockPessimistic     2 O fornecedor dos dados fecha o registro apos edicao
* adLockOptimistic      3 O fornecedor dos dados fecha o registro apos chamar o update
* adLockBatchOptimistic 4 O mesmo que Optmistic mas para sequencia de comandos
*
* AllowNumsEnum
*
* adIndexNullsAllow     0 
* adIndexNullsDisallow  1 
* adIndexNullsIgnore    2 
* adIndexNullsIgnoreAny 4
*
**************************************************************************************

#command ADO CONNECT <StrDriver> [<disconected:DISCONECTED>] => ADOCONNECT( <StrDriver>, [<.disconected.>] )
#command ADO DISCONNECT             => ADODISCONNECT()
#command ADO APPEND BLANK           => ADOAPPEND()
#command ADO EDIT                   => ADOEDIT()
#command ADO COMMIT [<save:SAVE>]   => ADOCOMMIT( [<.save.>] )
#command ADO SKIP                   => ADOSKIP( 1 ) 
#command ADO SKIP <num>             => ADOSKIP( <num> ) 
#command ADO DELETE                 => ADODELETE()
#command ADO REPLACE <f1> WITH <v1> => ADOREPLACE( <(f1)>, <v1> )
#command ADO GOTOP                  => ADOGOTOP()
#command ADO GOBOTTOM               => ADOGOBOTTOM()
#command ADO SET FILTER TO          => ADOSETFILTER()
#command ADO SET FILTER TO <xpr>    => ADOSETFILTER( <xpr> )
#command ADO SAVE <(CfILE)>         => ADOSAVE( <(CfILE)> )
#command ADO EXECUTE <*Sql*>        => ADOEXECUTE( <(Sql)> )
#command ADO LOCATE <xpr>           => ADOLOCATE( <xpr> )
#command ADO REGLOCK                => ADOREGLOCK()
#command ADO CLOSE                  => ADOCLOSE()
#command ADO CLOSE ALL              => ADOCLOSEALL()
#command ADO USE                    => ADOUSE()
#command ADO USE <(StrDatabase)> [<shared:SHARED>] => ADOUSE( <(StrDatabase)>, [<.shared.>] )
#command ADO SORT ON [<(cF)>][<(x)>]=> ADOSORT( [<(cF)>][, <(x)>] )
#command ADO SELECT <(cRecordSet)>  => ADOSELECT( <(cRecordSet)> )

#xcommand ADO SQL DELETE <*cSQL*>   => ADOEXECUTE( 'DELETE '+ <(cSQL)> )
#xcommand ADO SQL INSERT <*cSQL*>   => ADOEXECUTE( 'INSERT '+ <(cSQL)> )
#xcommand ADO SQL UPDATE <*cSQL*>   => ADOEXECUTE( 'UPDATE '+ <(cSQL)> )
#xcommand ADO SQL ALTER  <*cSQL*>   => ADOEXECUTE( 'ALTER ' + <(cSQL)> )
#xcommand ADO SQL CREATE <*cSQL*>   => ADOEXECUTE( 'CREATE '+ <(cSQL)> )
#xcommand ADO SQL DROP   <*cSQL*>   => ADOEXECUTE( 'DROP '  + <(cSQL)> )
#xcommand ADO SQL RENAME <*cSQL*>   => ADOEXECUTE( 'RENAME '+ <(cSQL)> )
#xcommand ADO SQL UPDATE <*cSQL*>   => ADOEXECUTE( 'UPDATE '+ <(cSQL)> )
#xcommand ADO SQL GRANT  <*cSQL*>   => ADOEXECUTE( 'GRANT ' + <(cSQL)> )
#xcommand ADO SQL REVOKE <*cSQL*>   => ADOEXECUTE( 'REVOKE '+ <(cSQL)> )

#xcommand DROP TABLE <*cSQL*>       => ADOEXECUTE( 'DROP TABLE '+ <(cSQL)> )
#xcommand INSERT INTO <*cSQL*>      => ADOEXECUTE( 'INSERT INTO '+ <(cSQL)> )
#xcommand CREATE TABLE <*cSQL*>     => ADOEXECUTE( 'CREATE TABLE '+ <(cSQL)> )

/*---- Lock Type Enum ----*/
#define adLockReadOnly        1
#define adLockPessimistic     2
#define adLockOptimistic      3
#define adLockBatchOptimistic 4

/*---- AllowNumsEnum ----*/
#define adIndexNullsAllow     0 
#define adIndexNullsDisallow  1 
#define adIndexNullsIgnore    2 
#define adIndexNullsIgnoreAny 4

/*---- CursorTypeEnum Values ----*/
#define adOpenForwardOnly 0
#define adOpenKeyset 1
#define adOpenDynamic 2
#define adOpenStatic 3

/*---- LockTypeEnum Values ----*/
#define adLockReadOnly 1
#define adLockPessimistic 2
#define adLockOptimistic 3
#define adLockBatchOptimistic 4

/*---- CursorLocationEnum Values ----*/
#define adUseServer 2
#define adUseClient 3

/*---- DataTypeEnum Values ----*/
#define adEmpty 0
#define adTinyInt 16
#define adSmallInt 2
#define adInteger 3
#define adBigInt 20
#define adUnsignedTinyInt 17
#define adUnsignedSmallInt 18
#define adUnsignedInt 19
#define adUnsignedBigInt 21
#define adSingle 4
#define adDouble 5
#define adCurrency 6
#define adDecimal 14
#define adNumeric 131
#define adBoolean 11
#define adError 10
#define adUserDefined 132
#define adVariant 12
#define adIDispatch 9
#define adIUnknown 13
#define adGUID 72
#define adDate 7
#define adDBDate 133
#define adDBTime 134
#define adDBTimeStamp 135
#define adBSTR 8
#define adChar 129
#define adVarChar 200
#define adLongVarChar 201
#define adWChar 130
#define adVarWChar 202
#define adLongVarWChar 203
#define adBinary 128
#define adVarBinary 204
#define adLongVarBinary 205
#define adChapter 136
#define adFileTime 64
#define adPropVariant 138
#define adVarNumeric 139
#define adArray &H2000

/*---- GetRowsOptionEnum Values ----*/
#define adGetRowsRest -1

/*---- PositionEnum Values ----*/
#define adPosUnknown -1
#define adPosBOF -2
#define adPosEOF -3

/*---- BookmarkEnum Values ----*/
#define adBookmarkCurrent 0
#define adBookmarkFirst 1
#define adBookmarkLast 2

/*---- MarshalOptionsEnum Values ----*/
#define adMarshalAll 0
#define adMarshalModifiedOnly 1

/*---- AffectEnum Values ----*/
#define adAffectCurrent 1
#define adAffectGroup 2
#define adAffectAllChapters 4

/*---- ResyncEnum Values ----*/
#define adResyncUnderlyingValues 1
#define adResyncAllValues 2

/*---- CompareEnum Values ----*/
#define adCompareLessThan 0
#define adCompareEqual 1
#define adCompareGreaterThan 2
#define adCompareNotEqual 3
#define adCompareNotComparable 4

/*---- FilterGroupEnum Values ----*/
#define adFilterNone 0
#define adFilterPendingRecords 1
#define adFilterAffectedRecords 2
#define adFilterFetchedRecords 3
#define adFilterConflictingRecords 5

/*---- SearchDirectionEnum Values ----*/
#define adSearchForward 1
#define adSearchBackward -1

/*---- PersistFormatEnum Values ----*/
#define adPersistADTG 0
#define adPersistXML 1

/*---- StringFormatEnum Values ----*/
#define adClipString 2

/*---- ConnectPromptEnum Values ----*/
#define adPromptAlways 1
#define adPromptComplete 2
#define adPromptCompleteRequired 3
#define adPromptNever 4

/*---- ConnectModeEnum Values ----*/
#define adModeUnknown 0
#define adModeRead 1
#define adModeWrite 2
#define adModeReadWrite 3
#define adModeShareDenyRead 4
#define adModeShareDenyWrite 8
#define adModeShareExclusive 12
#define adModeShareDenyNone 16

/*---- EventReasonEnum Values ----*/
#define adRsnAddNew 1
#define adRsnDelete 2
#define adRsnUpdate 3
#define adRsnUndoUpdate 4
#define adRsnUndoAddNew 5
#define adRsnUndoDelete 6
#define adRsnRequery 7
#define adRsnResynch 8
#define adRsnClose 9
#define adRsnMove 10
#define adRsnFirstChange 11
#define adRsnMoveFirst 12
#define adRsnMoveNext 13
#define adRsnMovePrevious 14
#define adRsnMoveLast 15

/*---- SchemaEnum Values ----*/
#define adSchemaProviderSpecific -1
#define adSchemaAsserts 0
#define adSchemaCatalogs 1
#define adSchemaCharacterSets 2
#define adSchemaCollations 3
#define adSchemaColumns 4
#define adSchemaCheckConstraints 5
#define adSchemaConstraintColumnUsage 6
#define adSchemaConstraintTableUsage 7
#define adSchemaKeyColumnUsage 8
#define adSchemaReferentialConstraints 9
#define adSchemaTableConstraints 10
#define adSchemaColumnsDomainUsage 11
#define adSchemaIndexes 12
#define adSchemaColumnPrivileges 13
#define adSchemaTablePrivileges 14
#define adSchemaUsagePrivileges 15
#define adSchemaProcedures 16
#define adSchemaSchemata 17
#define adSchemaSQLLanguages 18
#define adSchemaStatistics 19
#define adSchemaTables 20
#define adSchemaTranslations 21
#define adSchemaProviderTypes 22
#define adSchemaViews 23
#define adSchemaViewColumnUsage 24
#define adSchemaViewTableUsage 25
#define adSchemaProcedureParameters 26
#define adSchemaForeignKeys 27
#define adSchemaPrimaryKeys 28
#define adSchemaProcedureColumns 29
#define adSchemaDBInfoKeywords 30
#define adSchemaDBInfoLiterals 31
#define adSchemaCubes 32
#define adSchemaDimensions 33
#define adSchemaHierarchies 34
#define adSchemaLevels 35
#define adSchemaMeasures 36
#define adSchemaProperties 37
#define adSchemaMembers 38
#define adSchemaTrustees 39

/*---- FieldStatusEnum Values ----*/
#define adFieldOK 0
#define adFieldCantConvertValue 2
#define adFieldIsNull 3
#define adFieldTruncated 4
#define adFieldSignMismatch 5
#define adFieldDataOverflow 6
#define adFieldCantCreate 7
#define adFieldUnavailable 8
#define adFieldPermissionDenied 9
#define adFieldIntegrityViolation 10
#define adFieldSchemaViolation 11
#define adFieldBadStatus 12
#define adFieldDefault 13
#define adFieldIgnore 15
#define adFieldDoesNotExist 16
#define adFieldInvalidURL 17
#define adFieldResourceLocked 18
#define adFieldResourceExists 19
#define adFieldCannotComplete 20
#define adFieldVolumeNotFound 21
#define adFieldOutOfSpace 22
#define adFieldCannotDeleteSource 23
#define adFieldReadOnly 24
#define adFieldResourceOutOfScope 25
#define adFieldAlreadyExists 26
#define adFieldPendingInsert &H10000
#define adFieldPendingDelete &H20000
#define adFieldPendingChange &H40000
#define adFieldPendingUnknown &H80000
#define adFieldPendingUnknownDelete &H100000

/*---- SeekEnum Values ----*/
#define adSeekFirstEQ &H1
#define adSeekLastEQ &H2
#define adSeekAfterEQ &H4
#define adSeekAfter &H8
#define adSeekBeforeEQ &H10
#define adSeekBefore &H20

/*---- ADCPROP_UPDATECRITERIA_ENUM Values ----*/
#define adCriteriaKey 0
#define adCriteriaAllCols 1
#define adCriteriaUpdCols 2
#define adCriteriaTimeStamp 3

/*---- ADCPROP_ASYNCTHREADPRIORITY_ENUM Values ----*/
#define adPriorityLowest 1
#define adPriorityBelowNormal 2
#define adPriorityNormal 3
#define adPriorityAboveNormal 4
#define adPriorityHighest 5

/*---- ADCPROP_AUTORECALC_ENUM Values ----*/
#define adRecalcUpFront 0
#define adRecalcAlways 1

/*---- ADCPROP_UPDATERESYNC_ENUM Values ----*/

/*---- ADCPROP_UPDATERESYNC_ENUM Values ----*/

/*---- MoveRecordOptionsEnum Values ----*/
#define adMoveUnspecified -1
#define adMoveOverWrite 1
#define adMoveDontUpdateLinks 2
#define adMoveAllowEmulation 4

/*---- CopyRecordOptionsEnum Values ----*/
#define adCopyUnspecified -1
#define adCopyOverWrite 1
#define adCopyAllowEmulation 4
#define adCopyNonRecursive 2

/*---- StreamTypeEnum Values ----*/
#define adTypeBinary 1
#define adTypeText 2

/*---- LineSeparatorEnum Values ----*/
#define adLF 10
#define adCR 13
#define adCRLF -1

/*---- StreamOpenOptionsEnum Values ----*/
#define adOpenStreamUnspecified -1
#define adOpenStreamAsync 1
#define adOpenStreamFromRecord 4

/*---- StreamWriteEnum Values ----*/
#define adWriteChar 0
#define adWriteLine 1

/*---- SaveOptionsEnum Values ----*/
#define adSaveCreateNotExist 1
#define adSaveCreateOverWrite 2

/*---- FieldEnum Values ----*/
#define adDefaultStream -1
#define adRecordURL -2

/*---- StreamReadEnum Values ----*/
#define adReadAll -1
#define adReadLine -2

/*---- RecordTypeEnum Values ----*/
#define adSimpleRecord 0
#define adCollectionRecord 1
#define adStructDoc 2

