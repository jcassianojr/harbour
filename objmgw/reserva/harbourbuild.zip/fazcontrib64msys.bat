@echo off
rem *mingw64\*.a
SET HB_INSTALL_PREFIX=d:\hbcomp\hb64\

REM rem set HB_INSTALL_LIB=d:\harbour\lib\
SET HB_WITH_ADS=d:\harbour\hb3rd\acesdk-x64\
SET HB_WITH_ALLEGRO=d:\harbour\hb3rd\allegro-X64\include\
SET HB_WITH_BLAT=d:\harbour\hb3rd\blat-X64\
set HB_WITH_CAIRO=d:\harbour\hb3rd\cairo-x64\include\cairo\
SET HB_WITH_CURL=d:\harbour\hb3rd\curl-x64\include\
set HB_WITH_FIREBIRD=d:\harbour\hb3rd\firebird-x64\include\
SET HB_WITH_FREEIMAGE=d:\harbour\hb3rd\FreeImage-x64\include\
set HB_WITH_GS_BIN=d:\harbour\hb3rd\gscript-x64\bin\
set HB_WITH_GS=d:\harbour\hb3rd\gscript-x64\include\ghostscript\
SET HB_WITH_LIBHARU=d:\harbour\hb3rd\libharu-x64\include\
set HB_WITH_LIBMAGIC=d:\harbour\hb3rd\magic-x64\include\
set HB_WITH_MYSQL=d:\harbour\hb3rd\mysql-x64\include\
SET HB_WITH_OPENSSL=d:\harbour\hb3rd\openssl-x64\include
set HB_WITH_PGSQL=d:\harbour\hb3rd\pgsql-x64\include\
SET HB_WITH_RABBITMQ=d:\harbour\hb3rd\RABBITMQ-x64\include\
SET HB_WITH_SSH2=d:\harbour\hb3rd\ssh2-x64\include
set HB_WITH_OCIlib=d:\harbour\hb3rd\oci-x64\include\
SET HB_WITH_GD=d:\harbour\hb3rd\gd-X64\include\

rem vszakats
SET HB_WITH_ICU=d:\harbour\hb3rd\icu-x64\include\
SET HB_WITH_amqp=d:\harbour\hb3rd\amqp-x64\include\
SET HB_WITH_crypto=d:\harbour\hb3rd\crypto-x64\include\
SET HB_WITH_yaml=d:\harbour\hb3rd\yaml-x64\include\


SET HB_STATIC_CURL=yes
SET HB_STATIC_OPENSSL=yes
set HB_BUILD_CONTRIB_DYN=no
set HB_BUILD_DYN=no
set HB_BUILD_SHARED=no
SET HB_BUILD_STRIP=all

call hb64mysis.bat
cd contrib
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  gtalleg\gtalleg @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  gtqtc\gtqtc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  gtwvg\gtwvg @hbpost
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  gtwvw\gtwvw @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbamf\hbamf @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbblat\hbblat @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbblink\hbblink @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbbz2\hbbz2 @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbbz2io\hbbz2io @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbcairo\hbcairo @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbcomio\hbcomio @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbct\hbct @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbcurl\hbcurl @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbdoc\hbdoc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbexpat\hbexpat @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbfbird\hbfbird @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbfimage\hbfimage @hbpost
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbformat\hbformat @hbpost
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbformat/utils/hbformat @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbfoxpro\hbfoxpro @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbfship\hbfship @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbgd\hbgd  @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbgs\hbgs @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbgt\hbgt @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbgzio\hbgzio @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbhpdf\hbhpdf @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbhttpd\hbhttpd @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmagic\hbmagic @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmemio\hbmemio @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmisc\hbmisc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmlzo\hbmlzo @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmxml\hbmxml @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmysql\hbmysql @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbmzip\hbmzip @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbnetio\hbnetio @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbnf\hbnf @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbodbc\hbodbc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hboslib\hboslib @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbpgsql\hbpgsql @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbpipeio\hbpipeio @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbssl\hbssl @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbtinymt\hbtinymt @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbtip\hbtip @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbwin\hbwin @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbxpp\hbxpp @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbyaml\hbyaml @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbzebra\hbzebra @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbziparc\hbziparc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  rddads\rddads @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  rddbm\rddbm @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  rddmisc\rddmisc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  rddsql\rddsql @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddfb\sddfb @hbpost
rem hbmk2  -inc  sddfb\sddfb
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddmy\sddmy @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddoci\sddoci @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddodbc\sddodbc @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddpg\sddpg @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sddsqlt3\sddsqlt3 @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  xhb\xhb @hbpost

rem extras
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  rddado\rddado @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbxlsxml\hbxlsxml @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbvpdf\hbvpdf @hbpost

rem vszakats
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbamqp\hbamqp @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbcrypto\hbcrypto @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbicu\hbicu  @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbyaml\hbyaml @hbpost

rem minigui
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbcab\hbcab @hbpost
rem hbmk2 -inc  hbcab\hbcab 
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sevenzip\sevenzip @hbpost
rem hbmk2 -inc  sevenzip\sevenzip
rem hbmk2 -quiet -width=0 -autohbm- @hbpre -inc  hblibxlsxwriter\hblibxlsxwriter @hbpost
hbmk2 -inc  hbxml\hbxml

rem xharbour
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbbtree\hbbtree

rem outros
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sefazclass\sefazclass @hbpost
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  hbsvg\hbsvg @hbpost
rem hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  sqlrddpp\sqlrddpp @hbpost
hbmk2 -inc sqlrddpp\sqlrddpp
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  superlib\superlib
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  gas4harbour\gas4harbour 
hbmk2 -quiet  -width=0 -autohbm- @hbpre -inc  wvwclip\wvwclip
hbmk2 -inc hbxlsxwriter\hbxlsxwriter
