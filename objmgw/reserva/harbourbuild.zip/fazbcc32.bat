
SET HB_INSTALL_PREFIX=d:\hbcomp\bcc\

SET HB_WITH_ADS=d:\harbour\hb3rd\acesdk\
set HB_WITH_MYSQL=d:\harbour\hb3rd\mysql\include\
set HB_WITH_PGSQL=d:\harbour\hb3rd\pgsql\include\
set HB_WITH_OCIlib=d:\harbour\hb3rd\oci\include\
SET HB_WITH_CURL=d:\harbour\hb3rd\curl\include\
set HB_WITH_OPENSSL=d:\harbour\hb3rd\openssl\include\

SET HB_USER_LDFLAGS=-ap

SET HB_STATIC_CURL=yes
SET HB_STATIC_OPENSSL=yes
set HB_BUILD_CONTRIB_DYN=no
set HB_BUILD_DYN=no
set HB_BUILD_SHARED=no
SET HB_BUILD_STRIP=all

call bcc32
rem win-make install -k
rem win-make clean HB_USER_CFLAGS="-w- -w!-"
win-make install -k HB_USER_CFLAGS="-w- -w!-"

rem @ ECHO OFF
rem SET PATH=c:\bcc7\bin
rem SET HB_USER_LDFLAGS=-ap
rem SET HB_WITH_CURL=c:\curl32\include
rem SET HB_STATIC_CURL=yes
rem SET HB_WITH_OPENSSL=c:\OpenSSL-Win32\include
rem SET HB_BUILD_DYN=no
rem SET HB_BUILD_CONTRIB_DYN=no
rem IF EXIST lib\3rd\win\bcc REN lib\3rd\win\bcc bccx
rem win-make clean HB_USER_CFLAGS="-w- -w!-"
rem ren IF EXIST lib\3rd\win\bccx REN lib\3rd\win\bcc bcc
