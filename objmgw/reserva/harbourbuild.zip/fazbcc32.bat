
SET HB_INSTALL_PREFIX=d:\hbcomp\bcc\

SET HB_WITH_ADS=d:\harbour\hb3rd\acesdk\
set HB_WITH_MYSQL=d:\harbour\hb3rd\mysql\include\
set HB_WITH_PGSQL=d:\harbour\hb3rd\pgsql\include\

SET HB_STATIC_CURL=yes
SET HB_STATIC_OPENSSL=yes
set HB_BUILD_CONTRIB_DYN=no
set HB_BUILD_DYN=no
set HB_BUILD_SHARED=no
SET HB_BUILD_STRIP=all

call bcc32
win-make install

