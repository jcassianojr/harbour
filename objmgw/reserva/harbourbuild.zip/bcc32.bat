rem SET HB_ARCHITECTURE=win
rem set HB_COMPILER=BCC
rem set HB_PATH=d:\harbour\
rem set hb_bcc=d:\devprg\bcc\
rem SET PATH=%PATH%;d:\devprg\bcc\BIN;d:\harbour;d:\harbour\bin
rem SET INCLUDE=%INCLUDE%;d:\devprg\bcc\include;%HB_PATH%\include
rem SET LIB=%LIB%;d:\devprg\bcc\lib;%HB_bcc%\lib\
rem SET OBJ=%OBJ%


SET PATH=%PATH%;d:\devprg\bcc\;d:\harbour\bcc\;d:\harbour\bin\win\bcc\
SET INCLUDE=%INCLUDE%;d:\devprg\bcc\include
SET LIB=%LIB%;d:\devprg\bcc\lib
SET OBJ=%OBJ%;d:\devprg\bcc\obj
SET HB_INSTALL_PREFIX=d:\Hbcomp\bcc

SET HB_COMPILER=bcc
