rem SET HB_ARCHITECTURE=win
rem set HB_COMPILER=BCC
rem set HB_PATH=d:\harbour\
rem set hb_BCC=d:\devprg\bcc\
rem SET PATH=%PATH%;d:\devprg\bcc\BIN;d:\harbour;d:\harbour\bin
rem SET INCLUDE=%INCLUDE%;d:\devprg\bcc\include;%HB_PATH%\include
rem SET LIB=%LIB%;d:\devprg\bcc\lib;%HB_BCC%\lib\
rem SET OBJ=%OBJ%


rem SET PATH=d:\devprg\bcc\bin;d:\harbour\bin\win\bcc\;%PATH%;
rem ;d:\harbour\bcc\;d:\harbour\bin\win\bcc\
rem SET INCLUDE=%INCLUDE%;d:\devprg\bcc\include
rem SET LIB=%LIB%;d:\devprg\bcc\lib
rem SET OBJ=%OBJ%;d:\devprg\bcc\obj
rem SET HB_INSTALL_PREFIX=d:\Hbcomp\bcc

rem os includes ficam nos .cfg do bin
SET HB_COMPILER=bcc
SET PATH=d:\devprg\bcc\bin;d:\devprg\hb\bin\bcc\
