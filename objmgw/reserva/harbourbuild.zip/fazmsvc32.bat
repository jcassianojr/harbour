rem baixar bulidtools
rem componente dev c++ clang
@ ECHO OFF

CALL "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x86
SET HB_INSTALL_PREFIX=d:\hbcomp\msvc\

SET HB_USER_CFLAGS=-MD -MP -DHAVE_SEARCH_H

SET HB_WITH_CURL=d:\harbour\hb3rd\curl\include\
SET HB_STATIC_CURL=yes

SET HB_WITH_OPENSSL=d:\harbour\hb3rd\openssl\include\

SET HB_BUILD_DYN=no
SET HB_BUILD_CONTRIB_DYN=no

win-make  install -k
