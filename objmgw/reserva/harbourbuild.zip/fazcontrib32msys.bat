@echo off
rem busca tc *mingw\*.a
SET HB_INSTALL_PREFIX=d:\hbcomp\hb32\
REM rem set HB_INSTALL_LIB=d:\harbour\lib\ 

SET HB_WITH_ADS=d:\harbour\hb3rd\acesdk\
SET HB_WITH_ALLEGRO=d:\harbour\hb3rd\allegro\include\
SET HB_WITH_BLAT=d:\harbour\hb3rd\blat\
set HB_WITH_CAIRO=d:\harbour\hb3rd\cairo\include\cairo\
SET HB_WITH_CURL=d:\harbour\hb3rd\curl\include\
set HB_WITH_FIREBIRD=d:\harbour\hb3rd\firebird\include\
SET HB_WITH_FREEIMAGE=d:\harbour\hb3rd\FreeImage\include\
set HB_WITH_GS_BIN=d:\harbour\hb3rd\gscript\\bin\
set HB_WITH_GS=d:\harbour\hb3rd\gscript\include\ghostscript\
SET HB_WITH_LIBHARU=d:\harbour\hb3rd\libharu\include\
set HB_WITH_MYSQL=d:\harbour\hb3rd\mysql\include\
set HB_WITH_OCIlib=d:\harbour\hb3rd\oci\include\
set HB_WITH_OPENSSL=d:\harbour\hb3rd\openssl\include\
set HB_WITH_PGSQL=d:\harbour\hb3rd\pgsql\include\
SET HB_WITH_RABBITMQ=d:\harbour\hb3rd\RABBITMQ\include\
SET HB_WITH_SSH2=d:\harbour\hb3rd\ssh2\include\
rem vszakats
SET HB_WITH_ICU=d:\harbour\hb3rd\icu\include\
SET HB_WITH_amqp=d:\harbour\hb3rd\amqp\include\
SET HB_WITH_crypto=d:\harbour\hb3rd\crypto\include\
SET HB_WITH_yaml=d:\harbour\hb3rd\yaml\include\


SET HB_STATIC_CURL=yes
SET HB_STATIC_OPENSSL=yes
set HB_BUILD_CONTRIB_DYN=no
set HB_BUILD_DYN=no
set HB_BUILD_SHARED=no
SET HB_BUILD_STRIP=all

call hb32mysis.bat
cd contrib
hbmk2 gtalleg\gtalleg
hbmk2 gtqtc\gtqtc
hbmk2 gtwvg\gtwvg
rem hbmk2 gtwvw\gtwvw
hbmk2 hbamf\hbamf
hbmk2 hbblat\hbblat
hbmk2 hbblink\hbblink
hbmk2 hbbz2\hbbz2
hbmk2 hbbz2io\hbbz2io
hbmk2 hbcairo\hbcairo
hbmk2 hbcomio\hbcomio
hbmk2 hbct\hbct
hbmk2 hbcurl\hbcurl
hbmk2 hbdoc\hbdoc
hbmk2 hbexpat\hbexpat
hbmk2 hbfbird\hbfbird
hbmk2 hbfimage\hbfimage
hbmk2 hbformat\hbformat
hbmk2 hbformat/utils/hbformat
hbmk2 hbfoxpro\hbfoxpro
hbmk2 hbfship\hbfship
hbmk2 hbgd\hbgd 
hbmk2 hbgs\hbgs
hbmk2 hbgt\hbgt
hbmk2 hbgzio\hbgzio
hbmk2 hbhpdf\hbhpdf
hbmk2 hbhttpd\hbhttpd
hbmk2 hbmagic\hbmagic
hbmk2 hbmemio\hbmemio
hbmk2 hbmisc\hbmisc
hbmk2 hbmlzo\hbmlzo
hbmk2 hbmxml\hbmxml
hbmk2 hbmysql\hbmysql
hbmk2 hbmzip\hbmzip
hbmk2 hbnetio\hbnetio
hbmk2 hbnf\hbnf
hbmk2 hbodbc\hbodbc
hbmk2 hboslib\hboslib
hbmk2 hbpgsql\hbpgsql
hbmk2 hbssl\hbssl
hbmk2 hbpipeio\hbpipeio
hbmk2 hbtinymt\hbtinymt
hbmk2 hbtip\hbtip
hbmk2 hbwin\hbwin
hbmk2 hbxpp\hbxpp
hbmk2 hbyaml\hbyaml
hbmk2 hbzebra\hbzebra
hbmk2 hbziparc\hbziparc
hbmk2 rddads\rddads
hbmk2 rddbm\rddbm
hbmk2 rddmisc\rddmisc
hbmk2 rddsql\rddsql
hbmk2 sddfb\sddfb
hbmk2 sddmy\sddmy
hbmk2 sddoci\sddoci
hbmk2 sddodbc\sddodbc
hbmk2 sddpg\sddpg
hbmk2 sddsqlt3\sddsqlt3
hbmk2 xhb\hbmk2 

rem extras
hbmk2 rddado\rddado
hbmk2 hbxlsxml\hbxlsxml
hbmk2 hbvpdf\hbvpdf

rem zslask
hbmk2 hbamqp\hbamqp 
hbmk2 hbcrypto\hbcrypto
hbmk2 hbicu\hbicu
hbmk2 hbyaml\hbyaml

rem minigui
hbmk2 hbcab\hbcab
hbmk2 sevenzip\sevenzip
hbmk2 libxlw\libxlw
hbmk2 hbxml\hbxml

rem xharbour
rem hbmk2 hbbtree\hbbtree

rem outros
hbmk2 hbsvg\hbsvg
hbmk2 sqlrddpp\sqlrddpp
hbmk2 superlib\superlib
hbmk2 gas4harbour\gas4harbour
hbmk2 sefazclass\sefazclass

