@echo off
SET HB_ARCHITECTURE=win
set HB_COMPILER=bcc
set HB_PATH=d:\devprg\hb\
SET HB_bcc=d:\devprg\bcc\
SET INCLUDE_DIR=%HB_PATH%\include;%HB_bcc%\include\
SET LIB_DIR=%HB_PATH%\lib\win\bcc\;%HB_bcc%\lib\
set PATH=%HB_PATH%\bin\bcc\;%HB_bcc%\bin\
