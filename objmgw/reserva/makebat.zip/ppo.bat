call d:\devprg\hb\hb32msys.bat
hbpp %1.prg -ustd.ch
