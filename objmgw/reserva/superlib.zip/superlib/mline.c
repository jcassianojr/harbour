
#include "hbapi.h"


static unsigned int s_offset     = 0;

HB_FUNC( S_MLSETPOS )
{
    s_offset+=hb_parni(1);
    hb_ret();
}

/*----------clear s_offset ----------*/
HB_FUNC( S_MCLEAR )
{
  s_offset       = 0;
}

#define CH_141 141
#define CH_13  13
#define CH_10  10
#define CH_SP  32

/*----------get next line, return nil if none------------*/
HB_FUNC( S_GETLINE )
{
  char *outstr ;
  const char *string = hb_parc(1);
  unsigned int strlen   = hb_parclen(1);
  int linelen  = hb_parni(2);
  int gotten   = 0;
  int findsp   = 0;
  int findgot  = 0;
  int endchar = CH_13;
  unsigned int i;

  outstr = ( char * ) hb_xgrab( linelen );
  if (s_offset+1 < strlen)
     {
     for ( i=s_offset; (i < strlen) && (gotten<linelen) && (string[i]!=CH_141) && (string[i]!=CH_13) ;)
        {
        outstr[gotten]    = string[i];
        gotten++;
        i++;
        }


     if ( (string[i]==CH_141) || (string[i]==CH_13))
        {
        endchar = string[i];
        i+=2;
        }
     else if (string[i]!=CH_SP)
        {
         endchar = CH_13;
         findsp  = i;
         findgot = gotten;
         while ((string[findsp]!=CH_SP) && (findsp > s_offset) )
             {
             findsp--;
             findgot--;
             }
         if (findsp > s_offset)
            {
            findsp++;
            findgot++;
            i = findsp;
            gotten = findgot;
            endchar = CH_141;
            }


        }

     s_offset = i;

     hb_storni(endchar,3);

     hb_retclen(outstr,(gotten) );
     }

  hb_xfree(outstr);
}
