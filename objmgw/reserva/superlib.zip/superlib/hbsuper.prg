/*
 * $Id: hbsuper.prg 14676 2010-06-03 16:23:36Z vszakats $
 */

/*
 * Harbour Project source code:
 * SuperLib rewritten parts
 *
 * Copyright 2009 Viktor Szakats (harbour.01 syenar.hu)
 * www - http://harbour-project.org
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA (or visit the web site http://www.gnu.org/).
 *
 * As a special exception, the Harbour Project gives permission for
 * additional uses of the text contained in its release of Harbour.
 *
 * The exception is that, if you link the Harbour libraries with other
 * files to produce an executable, this does not by itself cause the
 * resulting executable to be covered by the GNU General Public License.
 * Your use of that executable is in no way restricted on account of
 * linking the Harbour library code into it.
 *
 * This exception does not however invalidate any other reasons why
 * the executable file might be covered by the GNU General Public License.
 *
 * This exception applies only to the code released by the Harbour
 * Project under the name Harbour.  If you copy code from other
 * Harbour Project or Free Software Foundation releases into a copy of
 * Harbour, as the General Public License permits, the exception does
 * not apply to the code that you add in this way.  To avoid misleading
 * anyone as to the status of such modified files, you must delete
 * this exception notice from them.
 *
 * If you write modifications of your own for Harbour, it is your choice
 * whether to permit this exception to apply to your modifications.
 * If you do not wish that, delete this exception notice.
 *
 */

#include "fileio.ch"

FUNCTION CDIR( p )
   RETURN DirChange( p ) != F_ERROR

FUNCTION ISPRN( p )
   RETURN hb_IsPrinter( p )

PROCEDURE RAT_ON()
   MShow()
   RETURN

PROCEDURE RAT_OFF()
   MHide()
   RETURN

FUNCTION RAT_ROW()
   RETURN MRow()

FUNCTION RAT_COL()
   RETURN MCol()

PROCEDURE RAT_POSIT( nRow, nCol )
   MSetPos( nRow, nCol )
   RETURN

FUNCTION RAT_EXIST()
   RETURN MPresent()

PROCEDURE RAT_AREA( nTop, nLeft, nBottom, nRight )
   MSetBounds( nTop, nLeft, nBottom, nRight )
   RETURN

FUNCTION RAT_LBHD
   RETURN MLeftDown()

FUNCTION RAT_RBHD
   RETURN MRightDown()

/* Dummy calls in Harbour */

PROCEDURE RAT_RESET()
   RETURN

PROCEDURE RAT_NOMOUS()
   RETURN

PROCEDURE RAT_FORCE()
   RETURN

/* TOFIX: Just an approximation of the original functionality for functions below */

FUNCTION RAT_ROWL()
   RETURN MRow()

FUNCTION RAT_ROWR()
   RETURN MRow()

FUNCTION RAT_COLL()
   RETURN MCol()

FUNCTION RAT_COLR()
   RETURN MCol()

FUNCTION RAT_LEFTB()
   RETURN MLeftDown()

FUNCTION RAT_RIGHTB()
   RETURN MRightDown()

/* TOFIX: This is just a dummy stub */

FUNCTION SHIFTY( f )
   HB_SYMBOL_UNUSED( f )
   RETURN .F.
