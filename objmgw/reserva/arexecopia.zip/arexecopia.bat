cd d:\devprg\hb64mgw12\comp\mingw64\bin\
copy ar.exe x86_64-w64-mingw32-ar.exe
copy windres.exe x86_64-w64-mingw32-windres.exe
cd d:\devprg\hb64mgw12\comp\mingw64\x86_64-w64-mingw32\bin\
copy ar.exe x86_64-w64-mingw32-ar.exe
