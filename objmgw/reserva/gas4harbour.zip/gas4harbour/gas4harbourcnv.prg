********************************************************
* GAS4Harbour.prg
* 
* PCToledo - 14/09/2012
********************************************************

REQUEST HB_LANG_PT
REQUEST HB_CODEPAGE_PT850

Func Main( cProj, ... )
Local cCmd, cExt, cArq_CH, cArq_P_CH, cArqPrincipal, cArqHBP, cNome, cBuf, i, nLin
Local cTxt, cLinha, nEnd, nArqHandle, cCH, cArqFim
Local cArquivo, lAdaptou := .F., nArqCvt:=0, cParams, tmp, lSemPausa:=.F., lOpenRel:=.F.
Private aArquivos[ Adir( "*.PRG" ) ]
Adir( "*.PRG",  aArquivos )

HB_LANGSELECT( 'PT' )
HB_SETCODEPAGE( 'PT850' )
SET(40,159)

Clear Screen
@ row(),0 say "GAS4Harbour - Conversor GASPRO para Harbour"
@ row()+1,0 say "Copyright (c) 2012, PCToledo"
@ row()+1,0 say "http://www.pctoledo.com.br/forum"

cParams := ""
FOR EACH tmp IN hb_AParams()
 if tmp!=cProj
  DO CASE
  CASE lower(tmp) == "-sp"
   lSemPausa:=.T.
  CASE lower(tmp) == "-openrel"
   lOpenRel:=.T.
  OTHERWISE
   cParams += " "+tmp
  ENDCASE
 endif
NEXT

if cProj=Nil
 Tone( 1000, 1 )
 @ row()+2,0 say "Erro: Informe o nome do arquivo LNK do Projeto GASPRO."
 @ row()+2,0 say "Sintaxe:"
 @ row()+2,0 say "  GAS4Harbour <NomedoArquivoLNK> [opcoes]"
 @ row()+2,0 say "Opcoes:"
 @ row()+1,0 say "  -sp        sem pausa para compilacao"
 @ row()+1,0 say "  -openrel   gera visualizador de relatorio grafico"
 @ row()+1,0 say ""
else
 hb_fNameSplit( cProj, , @cNome , @cExt )
 if Empt( cExt )
  cProj+=".lnk"
 endif
 cArq_CH := cNome+".ch"
 cArq_P_CH := alltrim( left( cNome, 3 ) )+"_publ.ch"
 cArqPrincipal := cNome+".prg"
 cArqHBP := cNome+".hbp"
 if file( cArqHBP )
  fErase( cArqHBP )
 endif
 if !file( cProj )
  Tone( 1000, 1 )
  @ row()+2,0 say "Erro: Arquivo "+upper(cProj)+" nao foi encontrado!"
  @ row()+1,0 say ""
  retu Nil
 endif
 if !file( cArq_CH )
  Tone( 1000, 1 )
  @ row()+2,0 say "Erro: Arquivo "+upper(cArq_CH)+" nao foi encontrado!"
  @ row()+1,0 say ""
  retu Nil
 endif
 if !file( cArq_P_CH )
  Tone( 1000, 1 )
  @ row()+2,0 say "Erro: Arquivo "+upper(cArq_P_CH)+" nao foi encontrado!"
  @ row()+1,0 say ""
  retu Nil
 endif
 if !file( cArqPrincipal )
  Tone( 1000, 1 )
  @ row()+2,0 say "Erro: Arquivo "+upper(cArqPrincipal)+" nao foi encontrado!"
  @ row()+1,0 say ""
  retu Nil
 endif
 if !file( "GETSYS.PRG" )
  Tone( 1000, 1 )
  @ row()+2,0 say "Erro: Arquivo GETSYS.PRG nao foi encontrado!"
  @ row()+1,0 say ""
  retu Nil
 endif


 @ row()+2,0 say "Criando arquivo '"+upper(cArqHBP)+"' ..."
 cBuf := memoread( cProj )
 nLin := MLCount( cBuf, 150, 0, .T. )
 cTxt := "-o"+cNome+".exe" + hb_eol() +;
         "-inc" + hb_eol() +;
         "-prgflag=/l" + hb_eol() +;
         "-compr=def" + hb_eol() +;
         "-rebuild" + hb_eol() +;
         "-quiet" + hb_eol() +;
         "-lxhb" + hb_eol() +;
         "-lhbwin" + hb_eol() +;
         "-lhbct" + hb_eol() +;
         "-lhbziparc" + hb_eol() +;
         "-lhbmzip" + hb_eol() +;
         "-lminizip" + hb_eol() +;
         "-lhbnf" + hb_eol() +;
         "GASP40HB.PRG" + hb_eol() +;
         "GETSYS.PRG" + hb_eol()
 For i=1 to nLin
  cLinha := MemoLine( cBuf, 150, i, 0, .T. )
  if left(cLinha, 3) == "FI "
   cTxt+=alltrim(subs(cLinha,4))+".PRG" + hb_eol()
  endif
 Next
 hb_memowrit( cArqHBP, cTxt )
 cBuf := memoread( cArq_CH )
 if AT( "IMP_BRW", cBuf ) == 0
  nArqCvt+=1
  @ row()+1,0 say "Ajustando arquivo '"+upper(cArq_CH)+"' ..."
  nEnd := AT( "* \\ Final", cBuf )
  cCH := "#define opcoes_rel(l_m,c_m,op_rel,sos_cod,fil_ini) OPCOES_RHB(l_m,c_m,op_rel,sos_cod,fil_ini)" + hb_eol() +;
         "#command IMP_BRW( ) => IMP_BRWHB( )" + hb_eol() +;
         "#command GBAK( ) => GBAKHB( )" + hb_eol() +;
         "#command RBAK( ) => RBAKHB( )" + hb_eol() +;
         "#command MONTA_LIN(<qtlin_>,<qttab_>) => MONTA_LINHB(<qtlin_>,<qttab_>)" + hb_eol() +;
         "#command SET PRINTER TO <(file)> [<add: ADDITIVE>]    => ;" + hb_eol() +;
         "               Set_Printer( <(file)>, <.add.> )" + hb_eol() + hb_eol() +;
         "* \\ Final de " + cArq_CH + hb_eol()
  nArqHandle := FOPEN( cArq_CH, 2 )
  FSEEK(nArqHandle,nEnd-1,0)
  FWRITE(nArqHandle,cCH)
  FCLOSE(nArqHandle)
  // Compatibiliza drvautohel
  cBuf := MemoRead( cArq_CH )
  if AT( "drvautohelp", cBuf ) != 0
   cBuf := StrTran( cBuf, "drvautohelp", "drvautohel" )
   hb_memoWrit( cArq_CH, cBuf )
  endif
 endif

 cBuf := memoread( cArq_P_CH )
 if AT( "Mou_Lin_S", cBuf ) == 0
  nArqCvt+=1
  @ row()+1,0 say "Ajustando arquivo '"+upper(cArq_P_CH)+"' ..."
  nEnd := AT( "* \\ Final", cBuf )
  cCH := 'arq_:=""' + hb_eol() +;
         "Mou_Lin_S:= Mou_Col_S := Mou_Lin_I := Mou_Col_I := 0" + hb_eol() + hb_eol() +;
         "* \\ Final de " + cArq_P_CH + hb_eol()
  nArqHandle := FOPEN( cArq_P_CH, 2 )
  FSEEK(nArqHandle,nEnd-1,0)
  FWRITE(nArqHandle,cCH)
  FCLOSE(nArqHandle)
  // Compatibiliza drvautohel
  cBuf := MemoRead( cArq_P_CH )
  if AT( "drvautohelp", cBuf ) != 0
   cBuf := StrTran( cBuf, "drvautohelp", "drvautohel" )
   hb_memoWrit( cArq_P_CH, cBuf )
  endif
 endif

 cBuf := memoread( cArqPrincipal )
 if AT( "hbgtinfo.ch", cBuf ) == 0
  nArqCvt+=1
  @ row()+1,0 say "Ajustando arquivo '"+upper(cArqPrincipal)+"' ..."
  lAdaptou := .T.  // primeira vez ou gerou os fontes
  nEnd := AT( "// inicializa constantes manifestas", cBuf )
  cCH := '#include "hbgtinfo.ch"' + hb_eol() +;
         "" + hb_eol() +;
         "REQUEST HB_LANG_PT" + hb_eol() +;
         "REQUEST HB_CODEPAGE_PT850" + hb_eol() +;
         "REQUEST HB_GT_WVT_DEFAULT" + hb_eol() +;
         "" + hb_eol() +;
         "Function Main()" + hb_eol() +;
         "" + hb_eol() +;
         "HB_SETCODEPAGE('PT850')" + hb_eol() +;
         "HB_LANGSELECT('PT')" + hb_eol() +;
         "" + hb_eol() +;
         "HB_GtInfo( HB_GTI_ISFULLSCREEN, .T. )" + hb_eol() +;
         "SetMode(25,80)" + hb_eol()

  cArqFim := subs(cBuf, nEnd+37)

  nArqHandle := FOPEN( cArqPrincipal, 2 )
  FSEEK(nArqHandle,nEnd+36,0)
  FWRITE(nArqHandle,cCH+cArqFim)
  FCLOSE(nArqHandle)
  // Compatibiliza drvautohel
  cBuf := MemoRead( cArqPrincipal )
  if AT( "drvautohelp", cBuf ) != 0
   cBuf := StrTran( cBuf, "drvautohelp", "drvautohel" )
   hb_memoWrit( cArqPrincipal, cBuf )
  endif
 endif

 If lAdaptou

  For i = 1 To Len( aArquivos )

   cArquivo := aArquivos[ i ]

   If Upper( cArquivo ) = "GAS4HARBOUR.PRG"
    Loop
   Endi

   cBuf := MemoRead( cArquivo )

   If "_FUNC.PRG" $ Uppe( cArquivo )
    nArqCvt+=1
    @ row()+1,0 say "Ajustando arquivo '"+upper(cArquivo)+"' ..."

    // Ajusta Funcao MOSTRA_RELA para consultas relacionais
    cBuf := StrTran( cBuf, "!br_outro:stable", "br_outro:stable" )

    // Ajusta Funcao BRWFUNC para leitura de consultas gravadas
    cBuf := StrTran( cBuf, "db_&pas.ind_ord", "db_&pas.ind_or" )

    // Compatibiliza drvautohel
    cBuf := StrTran( cBuf, "drvautohelp", "drvautohel" )

    hb_memoWrit( cArquivo, cBuf )

   else
    if AT( "drvautohelp", cBuf ) != 0
     @ row()+1,0 say "Ajustando arquivo '"+upper(cArquivo)+"' ..."
     nArqCvt+=1
     cBuf := StrTran( cBuf, "drvautohelp", "drvautohel" )
     hb_memoWrit( cArquivo, cBuf )
    endif
   Endi

  Next
  @ row()+1,0 say ""
 Endi

 if !lSemPausa
  if nArqCvt>10
   @ row()+2,0 say "GAS4Harbour - Conversor GASPRO para Harbour"
   @ row()+1,0 say "Copyright (c) 2012, PCToledo"
   @ row()+1,0 say "http://www.pctoledo.com.br/forum"
  endif
  if nArqCvt>0
   @ row()+2,5 say alltrim(str(nArqCvt,5,0))+" arquivos foram convertidos ..."
  else
   @ row()+2,5 say "Todos arquivos ja estavam convertidos ..."
  endif
  @ row()+2,5 say "Pressione qualquer tecla para iniciar a compilacao ..."
  Inkey(0)
 endif

 cCmd:="hbmk2 "+cArqHBP+cParams
 hb_Run( cCmd )
endif
retu Nil