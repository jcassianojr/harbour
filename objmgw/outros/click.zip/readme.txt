To install Click, copy the 'click' executable file into an executable Linux
path (i.e.,/user/local/bin, /home/'username'/bin, /user/bin).  Verify 
owner and permissions are correctly set.

It is easiest to run click by opening a terminal window in the directory that 
contains your source, '*.prg', files.  Intitiating the click command without
any options defaults to processing all '*.prg' files in the startup directory

The first time 'click' is run it creates default 'click.ini' and 'click.hdr'
files in the application directory.  These text files will need to be edited
to fine tune the click output.  By default all the output *.prg files are
placed in ./clickout directory.  Your source code should not be impacted, but
as always, backup first!


ADDITIONS TO CLICK Version2.03

1-When FUNCTION_SREF_INTO_SOURCE=YES "Calls to" function information (new) is
  added after the "Calls from" information in the source header.

2-A New FIELD_XREF_FILE option writes a field variable list for the "*.dbf"
  files in startup directory.


Note:There are options like CLEAN_UP_INCLUDES=YES that still use uppercase 
filenames and break Linux code.  They have not been disabled.  A future release
might look at removing old and OS dependent options.

