*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/cmd_list.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function init_list()
*+               Static Function no_ast()
*+               Static Function xno_ast()
*+               Function cmd_list()
*+               Function fnc_list()
*+               Function op_list()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+


static cmd_list
static cmd_count

static fnc_list
static fnc_count

static op_list
static op_count



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function init_list()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( cmd_list.prg )   1 - static function no_ast()
*+                ( qsort.prg    )   3 - function quicksort()
*+                ( readlist.prg )   3 - function readlist()
*+                ( click.prg    )   5 - procedure show_in()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function init_list(cFullPath)



// this function initializes the static arrays from the CLICK.INI file,
// and creates several forms of the COMMAND array.

local retval1
local retval2
local ast_list
local non_upper
local nPointer
//local cFullPath := if( file( 'CLICK.INI' ), 'CLICK', rootname( ft_origin() ) ) + '.INI'

/*
Read in the command list, sort it (ignoring *) and develop three arrays.
1 is the command list, forced to upper case.
2 is the command list without case changes.
3 is the logic array for the * marks.
*/
show_in('Reading COMMAND list')
cmd_list  := readlist(cFullPath,'CMD_LIST')
cmd_count := len(cmd_list)
for nPointer := 1 to cmd_count
   cmd_list[ nPointer ] := alltrim(cmd_list[nPointer])
next
show_in('Sorting COMMAND List')
// cmd_list  := asort( cmd_list,,, { | x, y | no_ast( x ) < no_ast( y ) } )
cmd_list  := quicksort(cmd_list,{| x | no_ast(x)})
non_upper := aclone(cmd_list)
ast_list  := array(len(cmd_list))
for nPointer := 1 to cmd_count
   if left(cmd_list[nPointer],1) == '*'
      cmd_list[ nPointer ]  := upper(substr(cmd_list[nPointer],2))
      non_upper[ nPointer ] := substr(non_upper[nPointer],2)
      ast_list[ nPointer ]  := .t.
   else
      cmd_list[ nPointer ] := upper(cmd_list[nPointer])
      ast_list[ nPointer ] := .f.
   endif
next

retval1 := non_upper
show_in('Reading FUNCTION List')
fnc_list  := readlist(cFullPath,'FUNC_LIST')
fnc_count := len(fnc_list)
for nPointer := 1 to fnc_count
   if len(fnc_list[nPointer]) < 4
      fnc_list[ nPointer ] := pad(fnc_list[nPointer],4)
   endif
next
show_in('Sorting FUNCTION List')
// fnc_list  := asort( fnc_list,,, { | x, y | upper( x ) < upper( y ) } )
fnc_list  := quicksort(fnc_list,{| x | upper(x)})
non_upper := aclone(fnc_list)
for nPointer := 1 to fnc_count
   fnc_list[ nPointer ] := upper(fnc_list[nPointer])
next

retval2 := non_upper

show_in('Reading OPERATOR List')
op_list  := readlist(cFullPath,'OP_LIST')
op_count := len(op_list)
// op_list  := asort( op_list )
op_list := quicksort(op_list)

return {retval1,retval2,ast_list}

// function re-instated 13Dec'98 (DJW)
// because version in no_ast.c converts the contents
// of the actual variable passed to upper case
// (no wonder it's faster!)
//



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function no_ast()
*+
*+    Called from ( cmd_list.prg )   1 - function init_list()
*+                                   1 - static function xno_ast()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function no_ast(cWord)



// This function is for the above function only, and allows the sort
// to ignore the '*' if it exists as the first letter of a command.

return upper(if(left(cWord,1) == '*',substr(cWord,2),cWord))



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function xno_ast()
*+
*+       Calls    ( cmd_list.prg )   1 - static function no_ast()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function xno_ast(cWord)



return no_ast(cWord)



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function cmd_list()
*+
*+    Called from ( click.prg    )   2 - function lineparse()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function cmd_list(cWord,nPointer)



// This seeks the word in the list and returns the pointer by reference.
// The function returns whether or not the seek was successful.

// This is a binary seek into a sorted array.

local retval   := .f.
local nWordLen := len(cWord)
local nLo      := 0
local nHi      := cmd_count+1
local lTwoWord := ' ' $ cWord
local lShort   := nWordLen < 4

cWord := upper(alltrim(cWord))
if lShort
   cWord += ' '
endif

if nWordLen > 1

   nPointer := int(cmd_count / 2)

   do while nHi > nLo+1

      if lShort
         do case
         case cWord == cmd_list[nPointer]+' '
            retval := .t.
            exit
         case cWord < cmd_list[nPointer]+' '
            nHi := nPointer
         case cWord > cmd_list[nPointer]+' '
            nLo := nPointer
         endcase
      else
         do case
         case cWord == pad(cmd_list[nPointer],nWordLen)
            retval := .t.
            exit
         case cWord < pad(cmd_list[nPointer],nWordLen)
            nHi := nPointer
         case cWord > pad(cmd_list[nPointer],nWordLen)
            nLo := nPointer
         endcase
      endif

      nPointer := int(nLo+((nHi - nLo) / 2))

   enddo

endif

if retval .and. !lTwoWord .and. ' ' $ trim(cmd_list[nPointer])
   retval := .f.
endif
return retval   //cmd_list()
// ****************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Function fnc_list()
*+
*+    Called from ( click.prg    )   2 - function lineparse()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function fnc_list(cWord,nPointer)



// This seeks the word in the list and returns the pointer by reference.
// The function returns whether or not the seek was successful.

// This is a binary seek into a sorted array.

local retval   := .f.
local nWordLen := len(cWord)
local nLo      := 0
local nHi      := fnc_count+1

if nWordLen > 1

   cWord := upper(cWord)
   if nWordLen < 4
      cWord    := pad(cWord,4)
      nWordLen := 4
   endif

   nPointer := int(fnc_count / 2)

   do while nHi > nLo+1

      do case
      case cWord == pad(fnc_list[nPointer],nWordLen)
         retval := .t.
         exit
      case cWord < pad(fnc_list[nPointer],nWordLen)
         nHi := nPointer
      case cWord > pad(fnc_list[nPointer],nWordLen)
         nLo := nPointer
      endcase

      nPointer := int(nLo+((nHi - nLo) / 2))

   enddo

endif
return retval   //fnc_list()
// ***********************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Function op_list()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - function lineparse()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function op_list(cWord,nPointer)



// This seeks the word in the list and returns the pointer by reference.
// The function returns whether or not the seek was successful.

// This is a binary seek into a sorted array.

local retval   := .f.
local nWordLen := len(cWord)
local nLo      := 0
local nHi      := op_count+1

nPointer := int(op_count / 2)

if nWordLen > 0

   do while nHi > nLo+1

      do case
      case cWord == op_list[nPointer]
         retval := .t.
         exit
      case cWord < op_list[nPointer]
         nHi := nPointer
      case cWord > op_list[nPointer]
         nLo := nPointer
      endcase

      nPointer := int(nLo+((nHi - nLo) / 2))

   enddo

endif
return retval   //op_list()
// **************************************************************************


*+ EOF: cmd_list.prg
*+
