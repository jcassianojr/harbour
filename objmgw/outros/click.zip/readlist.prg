*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/readlist.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function readlist()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "common.ch"



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function readlist()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                ( cmd_list.prg )   3 - function init_list()
*+                ( libread.prg  )   1 - procedure libread()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function readlist(inifile,category)



// This reads in a list from disk from an .INI file section and returns
// it as an array. If you pass in a @ as the category, it reads the
// entire file into an array. This is buffered for speed and assumes
// that the .INI text file is less than 32k

local retarry   := {}
local cThisLine
local ini_data  := memoread(inifile)
local nPointer
local CRLF
local lCatFound

do case   //allow Linux or DOS possibilities for end of line character(s)
case chr(13)+chr(10) $ ini_data
   CRLF := chr(13)+chr(10)
case chr(13) $ ini_data
   CRLF := chr(13)
case chr(10) $ ini_data
   CRLF := chr(10)
endcase

begin sequence

   category := '['+upper(alltrim(category))+']'

   lCatFound := category == '[@]'

   if !lCatFound
      nPointer := at(category,ini_data)
      if nPointer > 0
         ini_data  := substr(ini_data,nPointer)
         nPointer  := at(CRLF,ini_data)
         cThisLine := left(ini_data,nPointer - 1)
         ini_data  := substr(ini_data,nPointer+len(crlf))   //2/09 from fixed +2
      else
         break
      endif
   endif
   do while len(ini_data) > 0

      nPointer := at(CRLF,ini_data)

      if nPointer > 0
         cThisLine := left(ini_data,nPointer - 1)
         //         ini_data  := substr(ini_data,nPointer+2) changed 2/09
         ini_data := substr(ini_data,nPointer+len(crlf))  //2/09 from fixed +2  to len(crlf)
      else
         cThisLine := ini_data
         ini_data  := ''
      endif

      if empty(cThisLine) .or. left(ltrim(cThisLine),2) == '//'
         loop
      endif

      if left(cThisLine,1) == '['
         exit
      else
         aadd(retarry,cThisLine)
      endif

   enddo

end sequence
return retarry



*+ EOF: readlist.prg
*+
