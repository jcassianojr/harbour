*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/obufwrit.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function bo_init()
*+               Function bo_open()
*+               Procedure bo_write()
*+               Procedure bo_writeNoDupe()
*+               Procedure bo_close()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include 'fileio.ch'
#include 'common.ch'

#define cFileName oObjData[ 1 ]
#define nAccMode oObjData[ 2 ]
#define cOutBuffer oObjData[ 3 ]
#define cOutBufLen oObjData[ 4 ]
#define nHandle oObjData[ 5 ]
#define lLastWasEmpty oObjData[ 6 ]
#define lRemoveDups oObjData[ 7 ]
//lIsOpen=8 not used
//nFileBytes=9 not used
//nFileLines=10 not used
#define cDelimiter oObjData[11]
#define BUFFLEN 2560


// This is a buffered write (output) routine that keeps the disk from
// thrashing on a bunch of little writes. This speeds up output
// dramatically.



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function bo_init()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   5 - procedure func_text()
*+
*+       Calls    ( profile.prg  )   1 - function profilestring()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function bo_init(xFileName,xAccMode,ceoline,cClickini)



//local cFullPath := if( file( 'CLICK.INI' ), 'CLICK', RootName( ft_origin() ) ) + '.ini'

default ceoline to HB_OSNewLine()
default xAccMode to FO_WRITE

return {xFileName,;
 xAccMode,;
 '',;
 0,;
 - 1,;
 .f.,;
 ProfileString(cClickini,'CLICK','REMOVE_DUPLICATE_EMPTY_LINES','YES') == 'YES',;
 .t.,0,0,ceoline ;
 }



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function bo_open()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   5 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function bo_open(oObjData)



begin sequence
   if ! file(cFileName)
      nHandle := fcreate(cFileName,FC_NORMAL)
      if nHandle == - 1
         break
      endif
      fclose(nHandle)
   endif

   nHandle := fopen(cFileName,nAccMode)

   fseek(nHandle,0,FS_END)

end sequence

return nHandle # - 1



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure bo_write()
*+
*+    Called from ( click.prg    )  22 - procedure click()
*+                                   2 - static function breadpart()
*+                ( declbust.prg )  16 - procedure declbust()
*+                ( functrak.prg )  57 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure bo_write(oObjData,cSomeText)



cOutBufLen += len(cSomeText)

cOutBuffer += cSomeText

if cOutBufLen > BUFFLEN
   fwrite(nHandle,cOutBuffer)
   cOutBuffer := ''
   cOutBufLen := 0
endif

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure bo_writeNoDupe()
*+
*+    Called from ( click.prg    )  17 - static procedure thealigner()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure bo_writeNoDupe(oObjData,cSomeText)



if !lRemoveDups .or. cSomeText <> oObjData[11] .or. (cSomeText == oObjData[11] .and. !lLastWasEmpty)

   cOutBufLen += len(cSomeText)

   cOutBuffer += cSomeText

   if cOutBufLen > BUFFLEN
      fwrite(nHandle,cOutBuffer)
      cOutBuffer := ''
      cOutBufLen := 0
   endif

endif

lLastWasEmpty := (cSomeText == oObjData[11])

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure bo_close()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   5 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure bo_close(oObjData)



fwrite(nHandle,cOutBuffer)

fclose(nHandle)

return



*+ EOF: obufwrit.prg
*+
