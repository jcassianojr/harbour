*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/token.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function numtoken()
*+               Function token()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "common.ch"

/*
*+��������������������������������������������������������������������
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+    Function test()
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+��������������������������������������������������������������������
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
*+
function test()

local x
local nHowMany       := numtoken( '  This    is   a  test,   eh?  ', ' ' )

? nHowMany

for x := 1 to nHowMany
   ? '<' + token( '  This    is   a  test,   eh?  ', ' ', x ) + '>'
next

? numtoken( '             ', ' ' )

? numtoken( '', ' ' )

return nil
*/



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function numtoken()
*+
*+    Called from ( click.prg    )   1 - function lineparse()
*+                ( filnpath.prg )   1 - function fileinpath()
*+                ( functrak.prg )   2 - procedure init_func_text()
*+                ( libread.prg  )   1 - procedure libread()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function numtoken(cString,cDelimiter)



// This is used to get a count of how many tokens are in a string based
// on the supplied delimiter. This defaults to the same delimiters as
// used in the like named function in Clipper Tools III, so it should
// work identically.

local x
local nStrLen    := len(cString)
local nHowMany   := 0
local lFoundWord := .f.
local retval     := 0

default cDelimiter to ' ,.;:!?/\<>()^#&%+-*'+chr(0)+chr(9)+;
 chr(10)+chr(13)+;
 chr(26)+chr(138)+;
 chr(141)

for x := 1 to nStrLen
   if substr(cString,x,1) $ cDelimiter
      if lFoundWord
         nHowMany ++
      endif
      do while x < nStrLen .and. substr(cString,x+1,1) $ cDelimiter
         x ++
      enddo
   else
      lFoundWord := .t.
   endif
next

if nStrLen > 0
   retval := iif(right(cString,1) $ cDelimiter,nHowmany,nHowMany+1)
endif

return retval



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function token()
*+
*+    Called from ( click.prg    )   1 - function lineparse()
*+                ( filnpath.prg )   1 - function fileinpath()
*+                ( functrak.prg )   2 - procedure init_func_text()
*+                ( libread.prg  )   1 - procedure libread()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function token(cString,cDelimiter,nPointer)



// This is used to extract each token from the string based on the
// delimiter and the numeric pointer which tells us which token to
// return.

// This defaults to the same delimiters as used in the like named
// function in Clipper Tools III, so it should work identically.

local x
local nStrLen      := len(cString)
local nHowMany     := 0
local nLastPointer := 0
local cPart
local lFoundWord   := .f.

default cDelimiter to ' ,.;:!?/\<>()^#&%+-*'+chr(0)+chr(9)+;
 chr(10)+chr(13)+;
 chr(26)+chr(138)+;
 chr(141)

for x := 1 to nStrLen
   if substr(cString,x,1) $ cDelimiter
      if lFoundWord
         nHowMany ++
      endif
      if nHowMany == nPointer
         exit
      endif
      do while x < nStrLen .and. substr(cString,x+1,1) $ cDelimiter
         x ++
      enddo
      nLastPointer := x
   else
      lFoundWord := .t.
   endif
next

// went all the way without nHowmany == nPointer
if x == nStrLen+1
   // take the last word
   cPart := substr(cString,nLastPointer+1)
else
   cPart := substr(cString,nLastPointer+1,(x - nLastPointer) - 1)
endif

return cPart



*+ EOF: token.prg
*+
