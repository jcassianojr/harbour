*+--------------------------------------------------------------------
*+
*+    Source Module => /home/paul/click/filnpath.prg
*+
*+
*+    Functions: Function fileinpath()
*+               Function createini()
*+               Function createhdr()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include 'common.ch'



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function fileinpath()
*+
*+    Called from ( functrak.prg )   1 - procedure func_text()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+       Calls    ( token.prg    )   1 - function numtoken()
*+                ( token.prg    )   1 - function numtoken()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function fileinpath(filename,cEnviron)



local cDir
local foundit := .f.
local cPath
local x       := 1  // Initialise x
local y

// Modifications by Peter Townsend, 12/13/1998

// This will return the full path of a file name if it is in the environment
// you may specify the environment variable to other than the default
// of PATH, so you can get LIB, OBJ, or any other pathlist.

default cEnviron to 'PATH'

//cPath := getenv( upper( cEnviron ) )
cPath := getenv((cEnviron))
y     := numtoken(cPath,';')

// Change FOR to DO WHILE
do while (!foundit) .and. (x <= y)
   cDir := alltrim(token(cPath,';',x))
   //   cDir    += iif( right( cDir, 1 ) <> '\', '\', '' )
   cDir    += iif(right(cDir,1) <> '/','/','')
   foundit := file(cDir+filename)
   x ++   // Increment x
enddo   // Change NEXT to ENDDO

return if(foundit,cDir+filename,filename)



// Function added 5/05 to make the click executable a stand alone file that
// can automatically generate configuration files in the application directory.
// The default click.ini eol is set to Operating System default.  Click, however,
// retains the eol of the source code files.  The [x]Harbour compiler
// is flexible in dealing with eol characters.  Some default .ini values
// were changed and retaining the time/date stamp of original files is
// not supported.  The default function list is close to Clipper 5.X



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function createini()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( prb_pop.prg  )   1 - procedure attention()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function createini(cfullpath)


local cclick := '',ccmd_list := '',cfunc_list := '',cop_list := '',cr
local nfopen,lfclose,cferror
cr     := HB_OSNewLine()  //CHR(13)+CHR(10) 2/09
cclick := cclick+'[CLICK]'+cr+'INDENT_IF=3'+cr+'INDENT_FOR=3'+cr
cclick := cclick+'INDENT_CASE=3'+cr+'INDENT_FUNC=3'+cr+'INDENT_BEGIN=3'+cr
cclick := cclick+'INDENT_WHILE=3'+cr+'INDENT_CLASS=3'+cr
cclick := cclick+'INDENT_CONTINUE_LINE=1'+cr+cr+'DEFAULT_INDENT=8'+cr
cclick := cclick+'COMMENTTAB=2'+cr+cr+'HEAD_DIV=-'+cr+'FUNC_DIV=-'+cr+cr
cclick := cclick+'// the options are: NOCHANGE, UPPER, LOWER, PROPER, LIKEINFILE'+cr
cclick := cclick+'CASE_OF_COMMANDS=NOCHANGE'+cr+'CASE_OF_FUNCTIONS=NOCHANGE'+cr+cr
cclick := cclick+'// the options are: NOCHANGE, UPPER, LOWER'+cr
cclick := cclick+'CASE_OF_BOOLEAN=NOCHANGE'+cr+cr+'// options are S87, 5.X'+cr
cclick := cclick+'// selecting S87:'+cr+'//   Stops the = to := conversion'+cr
cclick := cclick+'//   Turns off the Declaration Buster'+cr
cclick := cclick+'//   Stops the STORE to := converter'+cr
cclick := cclick+'//   The Aligner uses = != instead of := += -= *= /= ^= !='+cr+cr
cclick := cclick+'RUNMODE=5.X'+cr+'//RUNMODE=S87'+cr
cclick := cclick+'// Convert && to // when && is starting a comment'+cr
cclick := cclick+'CONVERT_&&_TO_//=YES'+cr+cr
cclick := cclick+'// Convert * to // when && is starting a line'+cr
cclick := cclick+'CONVERT_*_TO_//=YES'+cr+cr
cclick := cclick+'// Convert ][ to ,'+cr
cclick := cclick+'// when set to yes, x[ 1 ][ 2 ] becomes x[ 1, 2 ]'+cr
cclick := cclick+'CONVERT_][_TO_,=YES'+cr+cr
cclick := cclick+'// Make #includes uniform (lower case #include, upper case "FILENAME"'+cr
cclick := cclick+'CLEAN_UP_INCLUDES=NO'+cr+cr
cclick := cclick+'// options are ENVIRONMENT, (specified path), DRIVES'+cr
cclick := cclick+'MAKE_CLICK_DBF_FROM=ENVIRONMENT'+cr
cclick := cclick+'//MAKE_CLICK_DBF_FROM=G:\EXPAND52;F:\JAMES\GANG\FUNK49'+cr
cclick := cclick+'//MAKE_CLICK_DBF_FROM=DRIVES'+cr+cr
cclick := cclick+'// This is only used if you select DRIVES above.'+cr
cclick := cclick+'// It limits the directory depth that recursion will traverse.'+cr
cclick := cclick+'RECURSION_LIMIT=7'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'INDENT_FUNCTIONS=NO'+cr
cclick := cclick+'INDENT_DO_CASE=NO'+cr+cr
cclick := cclick+'// This has an effect only if INDENT_FUNCTIONS=YES'+cr
cclick := cclick+'// It left justifies any line starting with LOCA PRIV MEMV STAT PUBL FIEL'+cr
cclick := cclick+'// options are YES, NO'+cr+'INDENT_LOCALS=NO'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'VERBOSE=YES'+cr+cr
cclick := cclick+'OUTPUT_EXTENSION=.prg'+cr
cclick := cclick+'//Realtive to current directory'+cr+'OUTPUT_DIRECTORY=clickout'+cr
cclick := cclick+'CLICK_LOG=click.log'+cr+'CLICK_LOG_ERASE=NO'+cr
cclick := cclick+'NOTIFY_OF_ERROR_ON_SCREEN=YES'+cr+cr
cclick := cclick+'// The options are: ALWAYS, ASK, NEVER'+cr+'OUTPUT_OVERWRITE=ALWAYS'+cr
cclick := cclick+'SOURCE_XREF_FILE=Src_cros.txt'+cr+'FUNCTION_XREF_FILE=Fnc_cros.txt'+cr
cclick := cclick+'TABLE_XREF_FILE=Tbl_cros.txt'+cr+'FIELD_XREF_FILE=Fld_cros.txt'+cr+cr
cclick := cclick+'// options are YES, NO'+cr
cclick := cclick+'// please note that you must set ADD_CLICK_HEADER=YES'+cr
cclick := cclick+'FUNCTION_REF_INTO_SOURCE=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr
cclick := cclick+'// please note that you must set ADD_FUNCTION_HEADERS=YES'+cr
cclick := cclick+'FUNCTION_XREF_INTO_SOURCE=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr
cclick := cclick+'// please note that you must set ADD_CLICK_HEADERS=YES'+cr
cclick := cclick+'TABLE_XREF_INTO_SOURCE=YES'+cr+cr
cclick := cclick+'// Use this if you have a dictionary function that opens files'+cr
cclick := cclick+'// This will allow Click! to track file openings via this function'+cr
cclick := cclick+'// You can define multiple functions here by using | as a delimiter'+cr
cclick := cclick+'MY_TABLE_FUNCTION=D_OPEN|D_CLOSE|D_ZAP'+cr
cclick := cclick+'MY_INDEX_FUNCTION=D_INDEX|D_ORDER'+cr+cr
cclick := cclick+'// options are YES, NO'+cr
cclick := cclick+'// please note that you must set ADD_CLICK_HEADERS=YES'+cr
cclick := cclick+'INDEX_XREF_INTO_SOURCE=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr
cclick := cclick+'//Time stamp option not implemented in (x)Harbour'+cr
cclick := cclick+'RETAIN_ORIGINAL_TIME_DATE_ON_OUTPUT_FILES=NO'+cr
cclick := cclick+'SKIP_FILES_WITH_NO_CHANGES=NO'+cr
cclick := cclick+'REMOVE_DUPLICATE_EMPTY_LINES=NO'+cr
cclick := cclick+'CONVERT_OLD_STYLE_FUNCTIONS=NO'+cr+'CONVERT_TO_INCREMENTOR=NO'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'RESTORE_SCREEN_ON_EXIT=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'PREPROCESS_WITH_DECLARATION_BUSTER=NO'+cr
cclick := cclick+'POSTPROCESS_WITH_THE_ALIGNER=YES'+cr+'ALIGN_DBCREATE_IN_THE_ALIGNER=YES'+cr
cclick := cclick+'ALIGN_CLASS_IN_THE_ALIGNER=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'CHANGE_REPLACE_WITH_TO_ASSIGNMENT=NO'+cr
cclick := cclick+'CHANGE_STORE_TO_ASSIGNMENT=YES'+cr+cr
cclick := cclick+'@_SAY_GET_ALIGNMENT_METHOD=2'+cr
cclick := cclick+'// options are 0, no alignment'+cr
cclick := cclick+'//             1, each element type in its own aligned column'+cr
cclick := cclick+'//             2, Columns aligned, but not by type'+cr
cclick := cclick+'//             3, Each element in its own row.'+cr
cclick := cclick+'// If you use option 3, there is no reverse process.'+cr
cclick := cclick+'// Review the output before you commit to method 3.'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'REMOVE_SNAP_HEADERS=NO'+cr
cclick := cclick+'REMOVE_MULTIEDIT_HEADERS=NO'+cr+'REMOVE_CLICK_HEADERS=YES'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'ADD_CLICK_HEADER=YES'+cr
cclick := cclick+'ADD_FUNCTION_HEADERS=YES'+cr+'ADD_EOF_MARKER=YES'+cr+cr
cclick := cclick+'SMART_ALIGN_MAX_ELEMENTS=11'+cr+cr
cclick := cclick+'// options are YES, NO'+cr+'// deflate mode removes spaces'+cr
cclick := cclick+'// following ({[ and preceding ]})'+cr+'// following ,'+cr
cclick := cclick+'// both sides of +'+cr+'DEFLATE_(=YES'+cr+'DEFLATE_{=YES'+cr
cclick := cclick+'DEFLATE_[=YES'+cr+'DEFLATE_,=YES'+cr+'DEFLATE_+=YES'+cr+cr

ccmd_list := ccmd_list+'[CMD_LIST]'+cr+cr
ccmd_list := ccmd_list+'// Commands beginning with * never make sense when used as a function, so'+cr
ccmd_list := ccmd_list+'// when they are followed by a (, they are NOT considered to be functions.'+cr
ccmd_list := ccmd_list+'// THIS ALLOWS YOU TO DEFINE WHICH COMMANDS WILL NOT BE CONSIDERED TO BE'+cr
ccmd_list := ccmd_list+'// FUNCTIONS. If you prefer for Click! to treat all commands as if they'+cr
ccmd_list := ccmd_list+'// cannot be functions, then place a * before each command.'+cr
ccmd_list := ccmd_list+'// Good programming practices never allow key words to be used as'+cr
ccmd_list := ccmd_list+'// functions or functions and commands to be used as variables.'+cr+cr
ccmd_list := ccmd_list+'ACCEPT'+cr+'ADDITIVE'+cr+'*ALL'+cr+'*APPEND BLANK'+cr
ccmd_list := ccmd_list+'*APPEND FROM'+cr+'AVERAGE'+cr+'*BEGIN SEQUENCE'+cr
ccmd_list := ccmd_list+'BOTTOM'+cr+'*BOX'+cr+'BREAK'+cr+'CALL'+cr+'CANCEL'+cr
ccmd_list := ccmd_list+'*CASE'+cr+'*CLASS'+cr+'*CLASS METHOD'+cr+'CLEAR'+cr
ccmd_list := ccmd_list+'*CLEAR ALL'+cr+'*CLEAR GETS'+cr+'*CLEAR MEMORY'+cr
ccmd_list := ccmd_list+'*CLEAR SCREEN'+cr+'*CLEAR TYPEAHEAD'+cr+'CLOSE'+cr
ccmd_list := ccmd_list+'CLS'+cr+'COLOR'+cr+'COMMIT'+cr+'CONTINUE'+cr+'*COPY FILE'+cr
ccmd_list := ccmd_list+'*COPY STRUCTURE EXTENDED'+cr+'*COPY STRUCTURE'+cr
ccmd_list := ccmd_list+'*COPY TO'+cr+'COUNT'+cr+'*CREATE'+cr+'*CREATE FROM'+cr
ccmd_list := ccmd_list+'DEFAULT'+cr+'DELETE'+cr+'*DELETE FILE'+cr
ccmd_list := ccmd_list+'*DELETE TAG'+cr+'DIR'+cr+cr+'DO'+cr+'*DO CASE'+cr
ccmd_list := ccmd_list+'*DO WHILE'+cr+'EJECT'+cr+'*ELSE'+cr+'*ELSEIF'+cr+'*END'+cr
ccmd_list := ccmd_list+'*END CASE'+cr+'*ENDCASE'+cr+'*END CLASS'+cr+'*ENDCLASS'+cr
ccmd_list := ccmd_list+'*END DO'+cr+'*ENDDO'+cr+'*END IF'+cr+'*ENDIF'+cr
ccmd_list := ccmd_list+'*END SEQUENCE'+cr+'*ENDSEQUENCE'+cr+'*END WHILE'+cr
ccmd_list := ccmd_list+'*ENDWHILE'+cr+'*ENDFOR'+cr+'ERASE'+cr+'EXCEPT'+cr
ccmd_list := ccmd_list+'EXCLUSIVE'+cr+'*EXPORTED:'+cr+'EXIT'+cr+'FIELD'+cr
ccmd_list := ccmd_list+'FIND'+cr+'*FOR'+cr+'*FROM'+cr+'*FUNCTION'+cr+'*GET'+cr
ccmd_list := ccmd_list+'GO'+cr+'GOTO'+cr+'*IF'+cr+'INDEX'+cr+'INIT'+cr+'INPUT'+cr
ccmd_list := ccmd_list+'JOIN'+cr+'*KEYBOARD'+cr+'LABEL'+cr+'*LABEL FORM'+cr
ccmd_list := ccmd_list+'*LIKE'+cr+'LIST'+cr+'LOCAL'+cr+'LOCATE'+cr+'LOOP'+cr
ccmd_list := ccmd_list+'MEMVAR'+cr+'*METHOD'+cr+'*MENU TO'+cr+'*NEXT'+cr+'NOTE'+cr
ccmd_list := ccmd_list+'*ON'+cr+'OTHERWISE'+cr+'PACK'+cr+'PARAMETERS'+cr
ccmd_list := ccmd_list+'PICTURE'+cr+'PRINT'+cr+'PRIVATE'+cr+'*PROCEDURE'+cr
ccmd_list := ccmd_list+'PROMPT'+cr+'*PROTECTED:'+cr+'PUBLIC'+cr+'QUIT'+cr+'RANGE'+cr
ccmd_list := ccmd_list+'READ'+cr+'READONLY'+cr+'RECALL'+cr+'RECORD'+cr
ccmd_list := ccmd_list+'RECOVER'+cr+'REINDEX'+cr+'RELEASE'+cr+'RENAME'+cr
ccmd_list := ccmd_list+'REPLACE'+cr+'*REPORT FORM'+cr+'REST'+cr+'RESTORE'+cr
ccmd_list := ccmd_list+'*RESTORE SCREEN'+cr+'*RETURN'+cr+'*RUN'+cr+'SAVE'+cr
ccmd_list := ccmd_list+'*SAVE SCREEN'+cr+'*SAY'+cr+'SCREEN'+cr+'SEEK'+cr
ccmd_list := ccmd_list+'*SELECT'+cr+'SEND'+cr+'*SET ALTERNATE'+cr+'*SET BELL'+cr
ccmd_list := ccmd_list+'*SET CENTURY'+cr+'*SET COLOR'+cr+'*SET CONFIRM'+cr
ccmd_list := ccmd_list+'*SET CONSOLE'+cr+'*SET CURSOR'+cr+'*SET DATE'+cr
ccmd_list := ccmd_list+'*SET DECIMALS'+cr+'*SET DEFAULT'+cr+'*SET DELETED'+cr
ccmd_list := ccmd_list+'*SET DELIMITERS'+cr+'*SET DEVICE'+cr+'*SET EPOCH'+cr
ccmd_list := ccmd_list+'*SET ESCAPE'+cr+'*SET EVENTMASK'+cr+'*SET EXACT'+cr+'*SET EXCLUSIVE'+cr
ccmd_list := ccmd_list+'*SET FILTER'+cr+'*SET FIXED'+cr+'*SET FORMAT'+cr
ccmd_list := ccmd_list+'*SET FUNCTION'+cr+'*SET INDEX'+cr+'*SET INTENSITY'+cr
ccmd_list := ccmd_list+'*SET KEY'+cr+'*SET MARGIN'+cr+'*SET MESSAGE'+cr
ccmd_list := ccmd_list+'*SET ORDER'+cr+'*SET PATH'+cr+'*SET PRINT'+cr
ccmd_list := ccmd_list+'*SET PRINTER'+cr+'*SET PROCEDURE'+cr+'*SET RELATION'+cr
ccmd_list := ccmd_list+'*SET SCOREBOARD'+cr+'*SET SOFTSEEK'+cr+'*SET TYPEAHEAD'+cr
ccmd_list := ccmd_list+'*SET UNIQUE'+cr+'*SET WRAP'+cr+'SKIP'+cr+'SORT'+cr
ccmd_list := ccmd_list+'STATIC'+cr+'STORE'+cr+'SUM'+cr+'TAG'+cr+'TEXT'+cr
ccmd_list := ccmd_list+'THEN'+cr+'*TO'+cr+'TOP'+cr+'TOTAL'+cr+'UNLOCK'+cr
ccmd_list := ccmd_list+'UPDATE'+cr+'*USE'+cr+'*VAR'+cr+'*VALID'+cr+'WAIT'+cr
ccmd_list := ccmd_list+'*WHEN'+cr+'*WHILE'+cr+'*WITH'+cr+'ZAP'+cr+cr

cfunc_list := cfunc_list+'[FUNC_LIST]'+cr+cr
cfunc_list := cfunc_list+'// Thanks to Jo W. French for the 5.3 Function listing!'+cr+cr
cfunc_list := cfunc_list+'AADD'+cr+'ABS'+cr+'ACHOICE'+cr+'ACLONE'+cr+'ACOPY'+cr
cfunc_list := cfunc_list+'ADEL'+cr+'ADIR'+cr+'ADDITEM'+cr+'AEVAL'+cr+'AFIELDS'+cr+'AFILL'+cr
cfunc_list := cfunc_list+'AINS'+cr+'ALERT'+cr+'ALIAS'+cr+'ALLTRIM'+cr+'ALTD'+cr
cfunc_list := cfunc_list+'AMPM'+cr+'APPLYDEFAULT'+cr+'ARRAY'+cr+'ASC'+cr+'ASCAN'+cr
cfunc_list := cfunc_list+'ASIZE'+cr+'ASORT'+cr+'AT'+cr+'ATAIL'+cr+'BIN2I'+cr+'BIN2L'+cr
cfunc_list := cfunc_list+'BIN2W'+cr+'BOF'+cr+'BREAK'+cr+'BROWSE'+cr+'BUTTONDEFCOLOR'+cr
cfunc_list := cfunc_list+'CDOW'+cr+'CHECKBOX'+cr+'CHECKDEFCOLOR'+cr+'CHR'+cr+'*CLOSE'+cr+'CLOSEMEMO'+cr
cfunc_list := cfunc_list+'CMONTH'+cr+'COL'+cr+'COLORSELECT'+cr+'COMBODEFCOLOR'+cr+'CTOD'+cr
cfunc_list := cfunc_list+'CURDIR'+cr+'DATE'+cr+'DAY'+cr+'DAYS'+cr+'DBAPPEND'+cr+'DBCLEARFILTER'+cr
cfunc_list := cfunc_list+'DBCLEARINDEX'+cr+'DBCLEARRELATION'+cr+'DBCLOSEALL'+cr
cfunc_list := cfunc_list+'DBCLOSEAREA'+cr+'DBCOMMIT'+cr+'DBCOMMITALL'+cr+'DBCREATE'+cr
cfunc_list := cfunc_list+'DBCREATEINDEX'+cr+'DBDELETE'+cr+'DBEDIT'+cr+'DBEVAL'+cr+'DBF'+cr
cfunc_list := cfunc_list+'DBFIELDINFO'+cr+'DBFILEGET'+cr+'DBFILEPUT'+cr+'DBFILTER'+cr
cfunc_list := cfunc_list+'DBFONLY'+cr+'DBGOBOTTOM'+cr+'DBGOTO'+cr+'DBGOTOP'+cr+'DBGSHADOW'+cr
cfunc_list := cfunc_list+'DBINFO'+cr+'DBORDERINFO'+cr+'DBRECALL'+cr+'DBRECORDINFO'+cr
cfunc_list := cfunc_list+'DBREINDEX'+cr+'DBRELATION'+cr+'DBRLOCK'+cr+'DBRLOCKLIST'+cr
cfunc_list := cfunc_list+'DBRSELECT'+cr+'DBRUNLOCK'+cr+'DBSEEK'+cr+'DBSELECTAREA'+cr
cfunc_list := cfunc_list+'DBSETDRIVER'+cr+'DBSETFILTER'+cr+'DBSETINDEX'+cr+'DBSETORDER'+cr
cfunc_list := cfunc_list+'DBSETRELATION'+cr+'DBSKIP'+cr+'DBSTRUCT'+cr+'DBUNLOCK'+cr+'DBUNLOCKALL'+cr
cfunc_list := cfunc_list+'DBUSEAREA'+cr+'DBCONVERT'+cr+'DEFPATH'+cr+'DELETED'+cr
cfunc_list := cfunc_list+'DESCEND'+cr+'DEVOUT'+cr+'DEVOUTPICT'+cr+'DEVPOS'+cr+'DIRCHANGE'+cr
cfunc_list := cfunc_list+'DIRECTORY'+cr+'DIRREMOVE'+cr+'DISKCHANGE'+cr+'DISKNAME'+cr
cfunc_list := cfunc_list+'DISKSPACE'+cr+'DISPBEGIN'+cr+'DISPBOX'+cr+'DISPCOUNT'+cr+'DISPEND'+cr
cfunc_list := cfunc_list+'DISPOUT'+cr+'DISPOUTAT'+cr+'DOSERROR'+cr+'DOW'+cr+'DRAWMEMOAREA'+cr
cfunc_list := cfunc_list+'DTOC'+cr+'DTOS'+cr+'EDITMEMO'+cr+'ELAPTIME'+cr+'EMPTY'+cr+'EOF'+cr
cfunc_list := cfunc_list+'ERRORBLOCK'+cr+'ERRORINHANDLER'+cr+'ERRORLEVEL'+cr+'ERRORSYS'+cr
cfunc_list := cfunc_list+'EVAL'+cr+'EXP'+cr+'EXPON'+cr+'FCLOSE'+cr+'FCOUNT'+cr+'FCREATE'+cr
cfunc_list := cfunc_list+'FERASE'+cr+'FERROR'+cr+'FIELDBLOCK'+cr+'FIELDGET'+cr+'FIELDNAME'+cr
cfunc_list := cfunc_list+'FIELDPOS'+cr+'FIELDPUT'+cr+'FIELDNBLOCK'+cr+'FIELDNPUT'+cr+'FIELDWBLOCK'+cr
cfunc_list := cfunc_list+'FILE'+cr+'FKLABEL'+cr+'FKMAX'+cr+'FLOCK'+cr+'FOPEN'+cr+'FOUND'+cr
cfunc_list := cfunc_list+'FREAD'+cr+'FREADSTR'+cr+'FRENAME'+cr+'FSEEK'+cr+'FSETDEVMODE'+cr+'FWRITE'+cr
cfunc_list := cfunc_list+'GBMPDISP'+cr+'GBMPLOAD'+cr+'GELLIPSE'+cr+'GETACTIVE'+cr+'GETAPPLYKEY'+cr
cfunc_list := cfunc_list+'GETCLRBACK'+cr+'GETCLRFORE'+cr+'GETCLRPAIR'+cr+'GETDOSETKEY'+cr
cfunc_list := cfunc_list+'GETENV'+cr+'GETHITTEST'+cr+'GETNEW'+cr+'GETPAIRLEN'+cr+'GETPAIRPOS'+cr
cfunc_list := cfunc_list+'GETPOSTVALID'+cr+'GETPREVALID'+cr+'GETREADER'+cr+'GFNTERASE'+cr+'GFNTLOAD'+cr
cfunc_list := cfunc_list+'GFNTSET'+cr+'GFRAME'+cr+'GGETPIXEL'+cr+'GLINE'+cr+'GMODE'+cr+'GPOLYGON'+cr
cfunc_list := cfunc_list+'GPUTPIXEL'+cr+'GRECT'+cr+'GSETCLIP'+cr+'GSETEXCL'+cr+'GSETPAL'+cr
cfunc_list := cfunc_list+'GUIAPPLYKEY'+cr+'GUIPOSTVALIDATE'+cr+'GUIPREVALIDATE'+cr+'GUIREADER'+cr
cfunc_list := cfunc_list+'GWRITEAT'+cr+'HARDCR'+cr+'HB_OSNEWLINE'+cr+'HEADER'+cr+'I2BIN'+cr+'IF'+cr
cfunc_list := cfunc_list+'IIF'+cr+'INDEXEXT'+cr
cfunc_list := cfunc_list+'INDEXKEY'+cr+'INDEXORD'+cr+'INSPECTCOL'+cr+'INKEY'+cr+'INT'+cr
cfunc_list := cfunc_list+'ISAFFIRM'+cr+'ISALPHA'+cr+'ISARRAY'+cr+'ISCHARACTER'+cr+'ISCOLOR'+cr
cfunc_list := cfunc_list+'ISDATE'+cr+'ISDEFCOLOR'+cr+'ISDIGIT'+cr+'ISDISK'+cr+'ISLOGIC'+cr
cfunc_list := cfunc_list+'ISLOWER'+cr+'ISNEGATIVE'+cr+'ISNUMBER'+cr+'ISPRINTER'+cr+'ISSHORTCUT'+cr
cfunc_list := cfunc_list+'ISUPPER'+cr+'L2BIN'+cr+'LASTKEY'+cr+'LASTREC'+cr+'LEFT'+cr+'LEN'+cr
cfunc_list := cfunc_list+'LENNUM'+cr+'LISTBDEFCOLOR'+cr+'LISTBOX'+cr+'LOG'+cr+'LOWER'+cr+'LTRIM'+cr
cfunc_list := cfunc_list+'LUPDATE'+cr+'MAKEDIR'+cr+'MAX'+cr+'MAXCOL'+cr+'MAXROW'+cr+'MCOL'+cr
cfunc_list := cfunc_list+'MDBLCLK'+cr+'MEMOEDIT'+cr+'MEMOLINE'+cr+'MEMOREAD'+cr+'MEMORY'+cr
cfunc_list := cfunc_list+'MEMOSETSUPER'+cr+'MEMOTRAN'+cr+'MEMOWRIT'+cr+'MEMVARBLOCK'+cr
cfunc_list := cfunc_list+'MENUDEFCOLOR'+cr+'MENUITEM'+cr+'MENUMODAL'+cr+'MHIDE'+cr+'MIN'+cr
cfunc_list := cfunc_list+'MLCOUNT'+cr+'MLCTOPOS'+cr+'MLEFTDOWN'+cr+'MLPOS'+cr+'MOD'+cr+'MODULUS'+cr
cfunc_list := cfunc_list+'MONTH'+cr+'MPOSTOLC'+cr+'MPRESENT'+cr+'MRESTSTATE'+cr+'MRIGHTDOWN'+cr
cfunc_list := cfunc_list+'MROW'+cr+'MSAVESTATE'+cr+'MSETBOUNDS'+cr+'MSETCLIP'+cr+'MSETCURSOR'+cr
cfunc_list := cfunc_list+'MSETPOS'+cr+'MSHOW'+cr+'MSTATE'+cr+'NATIONMSG'+cr+'NETERR'+cr
cfunc_list := cfunc_list+'NETNAME'+cr+'NEWLOCKS'+cr+'NEXTKEY'+cr+'NOSNOW'+cr+'OPENMEMO'+cr
cfunc_list := cfunc_list+'ORDBAGEXT'+cr+'ORDBAGNAME'+cr+'ORDCONDSET'+cr+'ORDCREATE'+cr+'ORDDESCEND'+cr
cfunc_list := cfunc_list+'ORDDESTROY'+cr+'ORDFOR'+cr+'ORDISUNIQUE'+cr+'ORDKEY'+cr+'ORDKEYADD'+cr
cfunc_list := cfunc_list+'ORDKEYCOUNT'+cr+'ORDKEYDEL'+cr+'ORDKEYGOTO'+cr+'ORDKEYNO'+cr+'ORDKEYVAL'+cr
cfunc_list := cfunc_list+'ORDLISTADD'+cr+'ORDLISTCLEAR'+cr+'ORDLISTREBUILD'+cr+'ORDNAME'+cr
cfunc_list := cfunc_list+'ORDNUMBER'+cr+'ORDSCOPE'+cr+'ORDSETFOCUS'+cr+'ORDSETRELATION'+cr
cfunc_list := cfunc_list+'ORDSKIPUNIQUE'+cr+'OS'+cr+'OUTERR'+cr+'OUTSTD'+cr+'PAD'+cr+'PADC'+cr
cfunc_list := cfunc_list+'PADL'+cr+'PADR'+cr+'PARSEHEADER'+cr+'POPUP'+cr+'PCOL'+cr+'PCOUNT'+cr
cfunc_list := cfunc_list+'PROCFILE'+cr+'PROCLINE'+cr+'PROCNAME'+cr+'PROW'+cr+'PUSHBUTTON'+cr
cfunc_list := cfunc_list+'QEXP'+cr+'QOUT'+cr+'QQOUT'+cr+'RADGRPDEFCOLOR'+cr+'RADIOBUTTON'+cr
cfunc_list := cfunc_list+'RADIOGROUP'+cr+'RADITDEFCOLOR'+cr+'RANGECHECK'+cr+'RAT'+cr+'RDDDBFINFO'+cr
cfunc_list := cfunc_list+'RDDLIST'+cr+'RDDNAME'+cr+'RDDORDINFO'+cr+'RDDREGISTER'+cr+'RDDSETDEFAULT'+cr
cfunc_list := cfunc_list+'RDDSYS'+cr+'READEXIT'+cr+'READFORMAT'+cr+'READINSERT'+cr+'READKEY'+cr
cfunc_list := cfunc_list+'READKILL'+cr+'READMODAL'+cr+'READUPDATED'+cr+'READVAR'+cr+'RECCOUNT'+cr
cfunc_list := cfunc_list+'RECNO'+cr+'RECSIZE'+cr+'REPLICATE'+cr+'RESTOREMEMO'+cr+'RESTSCREEN'+cr
cfunc_list := cfunc_list+'RIGHT'+cr+'RLOCK'+cr+'ROUND'+cr+'ROW'+cr+'RTRIM'+cr+'RUN'+cr+'SAVESCREEN'+cr
cfunc_list := cfunc_list+'SCROLL'+cr+'SCROLLBAR'+cr+'SECONDS'+cr+'SELECT'+cr+'SET'+cr+'SETBLINK'+cr
cfunc_list := cfunc_list+'SETCANCEL'+cr+'SETCLRPAIR'+cr+'SETCOLOR'+cr+'SETCURSOR'+cr+'SETKEY'+cr
cfunc_list := cfunc_list+'SETMODE'+cr+'SETPOS'+cr+'SETPRC'+cr+'SETTYPEAHEAD'+cr+'SOUNDEX'+cr
cfunc_list := cfunc_list+'SPACE'+cr+'SQRT'+cr+'STR'+cr+'STRTRAN'+cr+'STRZERO'+cr+'STUFF'+cr
cfunc_list := cfunc_list+'SUBSTR'+cr+'SYSINIT'+cr+'TAPPLYKEY'+cr+'TBADDCOL'+cr+'TBAPPLYKEY'+cr
cfunc_list := cfunc_list+'TBBLOCK'+cr+'TBCLOSE'+cr+'TBCOLUMNNEW'+cr+'TBCREATE'+cr+'TBDELCOL'+cr
cfunc_list := cfunc_list+'TBDISPLAY'+cr+'TBEDITCELL'+cr+'TBFBLOCK'+cr+'TBGOBOT'+cr+'TBGOTOP'+cr
cfunc_list := cfunc_list+'TBINSCOL'+cr+'TBMODAL'+cr+'TBMOUSE'+cr+'TBREADER'+cr+'TBROWSEDB'+cr
cfunc_list := cfunc_list+'TBROWSENEW'+cr+'TBSBLOCK'+cr+'TBSKIP'+cr+'TIME'+cr+'TONE'+cr+'TOPBAR'+cr
cfunc_list := cfunc_list+'TRANSFORM'+cr+'TRIM'+cr+'TSTRING'+cr+'TYPE'+cr+'UPDATED'+cr+'UPPER'+cr
cfunc_list := cfunc_list+'USED'+cr+'VAL'+cr+'VALTYPE'+cr+'VERSION'+cr+'WORD'+cr+'YEAR'+cr+cr


cop_list := cop_list+'[OP_LIST]'+cr+cr
cop_list := cop_list+'-'+cr+'--'+cr+'!'+cr+'!='+cr+'#'+cr+'*'+cr+'*='+cr
cop_list := cop_list+'**'+cr+'/'+cr+'/='+cr+':'+cr+':='+cr+'@'+cr+'^'+cr
cop_list := cop_list+'^='+cr+'+'+cr+'++'+cr+'+='+cr+'<'+cr+'<='+cr+'<>'+cr
cop_list := cop_list+'='+cr+'-='+cr+'=='+cr+'>'+cr+'->'+cr+'>='+cr+cr

nfopen := fcreate(cfullpath,0)  //open w/r
fwrite(nfopen,cclick)
fwrite(nfopen,ccmd_list)
fwrite(nfopen,cfunc_list)
fwrite(nfopen,cop_list)
lfclose := fclose(nfopen)   //if we fail on close
IF !lfclose
   cferror := str(ferror(),2,0)   //convert error to two digit string for display
   attention('cannot create click.ini, the ferror() error is '+cferror)
   quit
endif
RETURN lfclose  //eof function createini


// 5/05 Harbour conversion of Click to support both dos/linux.  This function
// creates a click.hdr file in current directory if one doesn't exist.  The eol
// defaults to OS standard eol convention.  Headers will use the eol
// convention of the prg file.


*+--------------------------------------------------------------------
*+
*+
*+
*+    Function createhdr()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( prb_pop.prg  )   1 - procedure attention()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function createhdr(cClickhdr,cr)


local chdr   := ''
local nfopen,lfclose,cferror


//chdr=chdr+'Click! is a Clipper/Xbase++ source code reformatter.'+cr+cr
//chdr=chdr+'Copyright(C) 1996-1999 by Phil Barnett.'+cr+cr
chdr := chdr+'This is the default "click.hdr" file.  Edit this file in'+cr
chdr := chdr+'your source code directory (where your *.prg files reside),'+cr
chdr := chdr+'to include copyright (C) and software licensing information'+cr
chdr := chdr+'i.e. Copyright(C) 20XX  by Your Name  GNU GPL  etc.'
//chdr=chdr+'This program is free software; you can redistribute it and/or modify it'+cr
//chdr=chdr+'under the terms of the GNU General Public License as published by the'+cr
//chdr=chdr+'Free Software Foundation; either version 2 of the License, or (at your'+cr
//chdr=chdr+'option) any later version.'+cr+cr

//chdr=chdr+'This program is distributed in the hope that it will be useful, but'+cr
//chdr=chdr+'WITHOUT ANY WARRANTY; without even the implied warranty of'+cr
//chdr=chdr+'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU'+cr
//chdr=chdr+'General Public License for more details.'+cr+cr
//chdr=chdr+'You should have received a copy of the GNU General Public License along'+cr
//chdr=chdr+'with this program; if not, write to the Free Software Foundation, Inc.'+cr

nfopen := fcreate(cClickhdr,0)  //open w/r
fwrite(nfopen,chdr)
lfclose := fclose(nfopen)   //if we fail on close
IF !lfclose
   cferror := str(ferror(),2,0)   //convert error to two digit string for display
   attention('cannot create click.ini, the ferror() error is '+cferror)
   quit
endif
RETURN lfclose




/* start of S87 Function List, transcribed but not used in (x)Harbour Linux
   implementation of Click.
cfunc_list=cfunc_list+'[FUNC_LIST]'+cr+cr
cfunc_list=cfunc_list+'AADD'+cr+'ABS'+cr+'ACHOICE'+cr+'ACLONE'+cr+'ACOPY'+cr
cfunc_list=cfunc_list+'ADEL'+cr+'ADIR'+cr+'AEVAL'+cr+'AFIELDS'+cr+'AFILL'+cr
cfunc_list=cfunc_list+'AINS'+cr+'ALERT'+cr+'ALIAS'+cr+'ALLTRIM'+cr+'ALTD'+cr
cfunc_list=cfunc_list+'AMPM'+cr+'ARRAY'+cr+'ASC'+cr+'ASCAN'+cr+'ASIZE'+cr
cfunc_list=cfunc_list+'ASORT'+cr+'AT'+cr+'ATAIL'+cr+'BIN2I'+cr+'BIN2L'+cr
cfunc_list=cfunc_list+'BIN2W'+cr+'BOF'+cr+'BREAK'+cr+'BROWSE'+cr+'CDOW'+cr
cfunc_list=cfunc_list+'CHR'+cr+'CLS'+cr+'CMONTH'+cr+'COL'+cr+'COLORSELECT'+cr
cfunc_list=cfunc_list+'CTOD'+cr+'CURDIR'+cr+'DATE'+cr+'DAY'+cr+'DBAPPEND'+cr
cfunc_list=cfunc_list+'DBCLEARFIL'+cr+'DBCLEARIND'+cr+'DBCLOSEALL'+cr
cfunc_list=cfunc_list+'DBCLOSEAREA'+cr+'DBCOMMIT'+cr+'DBCOMMITALL'+cr
cfunc_list=cfunc_list+'DBCREATE'+cr+'DBCREATEIND'+cr+'DBDELETE'+cr+'DBEDIT'+cr
cfunc_list=cfunc_list+'DBEVAL'+cr+'DBF'+cr+'DBFILTER'+cr+'DBGOBOTTOM'+cr
cfunc_list=cfunc_list+'DBGOTO'+cr+'DBGOTOP'+cr+'DBRECALL'+cr+'DBREINDEX'+cr
cfunc_list=cfunc_list+'DBRELATION'+cr+'DBRLOCK'+cr+'DBRLOCKLIST'+cr
cfunc_list=cfunc_list+'DBRSELECT'+cr+'DBRUNLOCK'+cr+'DBSEEK'+cr+'DBSELECTAREA'+cr
cfunc_list=cfunc_list+'DBSETDRIVER'+cr+'DBSETFILTER'+cr+'DBSETINDEX'+cr
cfunc_list=cfunc_list+'DBSETORDER'+cr+'DBSETRELAT'+cr+'DBSKIP'+cr+'DBSTRUCT'+cr
cfunc_list=cfunc_list+'DBUNLOCK'+cr+'DBUNLOCKALL'+cr+'DBUSEAREA'+cr+'DELETED'+cr
cfunc_list=cfunc_list+'DESCEND'+cr+'DEVOUT'+cr+'DEVOUTPICT'+cr+'DEVPOS'+cr
cfunc_list=cfunc_list+'DIRECTORY'+cr+'DISKSPACE'+cr+'DISPBEGIN'+cr+'DISPBOX'+cr
cfunc_list=cfunc_list+'DISPCOUNT'+cr+'DISPEND'+cr+'DISPOUT'+cr+'DOSERROR'+cr
cfunc_list=cfunc_list+'DOW'+cr+'DTOC'+cr+'DTOS'+cr+'EMPTY'+cr+'EOF'+cr
cfunc_list=cfunc_list+'ERRORBLOCK'+cr+'ERRORLEVEL'+cr+'EVAL'+cr+'EXP'+cr
cfunc_list=cfunc_list+'FCLOSE'+cr+'FCOUNT'+cr+'FCREATE'+cr+'FERASE'+cr
cfunc_list=cfunc_list+'FERROR'+cr+'FIELDBLOCK'+cr+'FIELDGET'+cr+'FIELDNAME'+cr
cfunc_list=cfunc_list+'FIELDPOS'+cr+'FIELDPUT'+cr+'FIELDWBLOCK'+cr+'FILE'+cr
cfunc_list=cfunc_list+'FKLABEL'+cr+'FKMAX'+cr+'FLOCK'+cr+'FOPEN'+cr+'FOUND'+cr
cfunc_list=cfunc_list+'FREAD'+cr+'FREADSTR'+cr+'FRENAME'+cr+'FSEEK'+cr
cfunc_list=cfunc_list+'FWRITE'+cr+'GETENV'+cr+'HARDCR'+cr
cfunc_list=cfunc_list+'HB_OSNEWLINE+cr+'HEADER'+cr+'IF'+cr
cfunc_list=cfunc_list+'IIF'+cr+'INDEXEXT'+cr+'INDEXKEY'+cr+'INDEXORD'+cr
cfunc_list=cfunc_list+'INKEY'+cr+'INT'+cr+'ISALPHA'+cr+'ISARRAY'+cr
cfunc_list=cfunc_list+'ISCHARACTER'+cr+'ISCOLOR'+cr+'ISDATE'+cr+'ISDIGIT'+cr
cfunc_list=cfunc_list+'ISLOGIC'+cr+'ISLOWER'+cr+'ISNUMBER'+cr+'ISPRINTER'+cr
cfunc_list=cfunc_list+'ISUPPER'+cr+'I2BIN'+cr+'L2BIN'+cr+'LASTKEY'+cr
cfunc_list=cfunc_list+'LASTREC'+cr+'LEFT'+cr+'LEN'+cr+'LOG'+cr+'LOWER'+cr
cfunc_list=cfunc_list+'LTRIM'+cr+'LUPDATE'+cr+'MAX'+cr+'MAXCOL'+cr+'MAXROW'+cr
cfunc_list=cfunc_list+'MEMOEDIT'+cr+'MEMOLINE'+cr+'MEMOREAD'+cr+'MEMORY'+cr
cfunc_list=cfunc_list+'MEMOTRAN'+cr+'MEMOWRIT'+cr+'MEMVARBLOCK'+cr+'MIN'+cr
cfunc_list=cfunc_list+'MLCOUNT'+cr+'MLCTOPOS'+cr+'MLPOS'+cr+'MOD'+cr+'MONTH'+cr
cfunc_list=cfunc_list+'MPOSTOLC'+cr+'NETERR'+cr+'NETNAME'+cr+'NEXTKEY'+cr
cfunc_list=cfunc_list+'NOSNOW'+cr+'OS'+cr+'ORDBAGEXT'+cr+'ORDBAGNAME'+cr
cfunc_list=cfunc_list+'ORDCREATE'+cr+'ORDDESTROY'+cr+'ORDFOR'+cr+'ORDKEY'+cr
cfunc_list=cfunc_list+'ORDLISTADD'+cr+'ORDLISTCLEAR'+cr+'ORDLISTREBUI'+cr
cfunc_list=cfunc_list+'ORDNAME'+cr+'ORDNUMBER'+cr+'ORDSETFOCUS'+cr+'OUTERR'+cr
cfunc_list=cfunc_list+'OUTSTD'+cr+'PAD'+cr+'PADR'+cr+'PADL'+cr+'PCOL'+cr
cfunc_list=cfunc_list+'PCOUNT'+cr+'PROCLINE'+cr+'PROCNAME'+cr+'PROW'+cr
cfunc_list=cfunc_list+'QQOUT'+cr+'QOUT'+cr+'RAT'+cr+'RDDLIST'+cr+'RDDNAME'+cr
cfunc_list=cfunc_list+'RDDSETDEFAULT'+cr+'READEXIT'+cr+'READINSERT'+cr
cfunc_list=cfunc_list+'READKEY'+cr+'READMODAL'+cr+'READVAR'+cr+'RECCOUNT'+cr
cfunc_list=cfunc_list+'RECNO'+cr+'RECSIZE'+cr+'REPLICATE'+cr+'RESTSCREEN'+cr
cfunc_list=cfunc_list+'RIGHT'+cr+'RLOCK'+cr+'ROUND'+cr+'ROW'+cr+'RTRIM'+cr
cfunc_list=cfunc_list+'SAVESCREEN'+cr+'SCROLL'+cr+'SECONDS'+cr+'SELECT'+cr
cfunc_list=cfunc_list+'SET'+cr+'SETBLINK'+cr+'SETCANCEL'+cr+'SETCOLOR'+cr
cfunc_list=cfunc_list+'SETCURSOR'+cr+'SETKEY'+cr+'SETMODE'+cr+'SETPOS'+cr
cfunc_list=cfunc_list+'SETPRC'+cr+'SOUNDEX'+cr+'SPACE'+cr+'SQRT'+cr+'STR'+cr
cfunc_list=cfunc_list+'STRZERO'+cr+'STRTRAN'+cr+'STUFF'+cr+'SUBSTR'+cr+'TIME'+cr
cfunc_list=cfunc_list+'TONE'+cr+'TRANSFORM'+cr+'TRIM'+cr+'TYPE'+cr+'UPDATED'+cr
cfunc_list=cfunc_list+'UPPER'+cr+'USED'+cr+'VAL'+cr+'VALTYPE'+cr+'VERSION'+cr
cfunc_list=cfunc_list+'WORD'+cr+'YEAR'+cr+cr
end of S87 function list */


*+ EOF: filnpath.prg
*+
