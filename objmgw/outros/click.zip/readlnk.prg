*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/readlnk.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function readlnk()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+





*+--------------------------------------------------------------------
*+
*+
*+
*+    Function readlnk()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( obufread.prg )   2 - function bclose()
*+                ( obufread.prg )   2 - function beof()
*+                ( obufread.prg )   2 - function binit()
*+                ( obufread.prg )   2 - function bopen()
*+                ( obufread.prg )   2 - function breadline()
*+                ( filnpath.prg )   2 - function fileinpath()
*+                ( token.prg    )   2 - function numtoken()
*+                ( click.prg    )   3 - function rootname()
*+                ( token.prg    )   2 - function numtoken()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function readlnk(cFileName)



local hi
local nx
local w
local x
local y
local nY
local nFilePointer
local nPointer
local aFileList    := {}
local aLibList     := {}
local aLinkList    := {upper(cFileName)}
local aFileDone    := {.f.}
local cThisLine
local cThisFile

// we start this loop with the .LNK list we specified at runtime as the
// only entry, and mark it .f. for not processed. As we process this
// entry, we may come upon one or more references to other link scripts.
// If this is the case, they are added to the processing array and
// marked as not processed. When all have been processed, we have a
// complete list. It's easier than recursion.

do while .t.

   nFilePointer := ascan(aFileDone,.f.)

   // If 0, we finished finding and processing all .LNK files
   if nFilePointer == 0
      exit
   endif

   hi := binit(aLinkList[nFilePointer])
   if bopen(hi)

      do while !beof(hi)

         cThisLine := upper(ltrim(bReadLine(hi)))

         if left(cThisLine,1) == '@'
            // grab the filename
            cThisLine := substr(cThisLine,2)

            // strip comments
            if (nPointer := at('#',cThisLine)) > 0
               cThisLine := left(cThisLine,nPointer - 1)
            endif

            // trim any spaces
            cThisLine := alltrim(cThisLine)

            // check to see if this name is already in the list
            if (nPointer := ascan(aLinkList,cThisLine)) == 0

               // force the extension
               cThisFile := rootname(cThisLine)+'.LNK'

               // is it in the current directory?
               if ! file(cThisFile)
                  // is it in the LIB= path?
                  cThisFile := fileinpath(cThisFile,'LIB')
               endif

               // if it was not found in local dir or path, it is empty.
               if !empty(cThisFile)
                  aadd(aLinkList,cThisFile)
                  aadd(aFileDone,.f.)
               endif
            endif

         endif

      enddo

      bClose(hi)

   endif

   aFileDone[ nFilePointer ] := .t.

enddo

// once we have the link scripts all of them need to be scanned for
// library references and for source references. Library references are
// checked for validity against the environment, and program files are
// checked for existance in the local directory.

nY := len(aLinkList)

for y := 1 to nY
   hi := binit(aLinkList[y])
   if bopen(hi)
      do while !beof(hi)
         cThisLine := upper(alltrim(bReadLine(hi)))
         if (nPointer := at('#',cThisLine)) > 0
            cThisLine := trim(left(cThisLine,nPointer - 1))
         endif
         if left(cThisLine,2) $ 'LI|AL'
            cThisLine := alltrim(substr(cThisLine,at(' ',cThisLine)))
            if !empty(cThisLine)
               nx := numtoken(cThisLine,',')
               for x := 1 to nx
                  cThisFile := upper(token(cThisLine,',',x))
                  aadd(aLibList,fileinpath(rootname(cThisFile)+'.LIB'))
               next
            endif
         endif
         if left(cThisLine,2) == 'FI'
            cThisLine := alltrim(substr(cThisLine,at(' ',cThisLine)))
            if !empty(cThisLine)
               nx := numtoken(cThisLine,',')
               for x := 1 to nx
                  cThisFile := token(cThisLine,',',x)
                  w         := rat('/',cThisFile)
                  if w > 0
                     cThisFile := substr(cThisFile,w+1)
                  endif
                  cThisFile := rootname(cThisFile)+'.PRG'
                  if file(cThisFile)
                     aadd(aFileList,cThisFile)
                  endif
               next
            endif
         endif
      enddo
      bclose(hi)
   endif
next

// Exiting this routine, we have a pair of validated arrays which
// contain a list of all libraries and all files referred to in the
// link script being examined.

return {aFileList,aLibList}



*+ EOF: readlnk.prg
*+
