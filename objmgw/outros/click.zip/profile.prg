*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/profile.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function ProfileString()
*+               Function ProfileNum()
*+               Function ProfileDate()
*+               Static Function init_profile()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "common.ch"

static INI_DATA := {}
static INI_NAME := ''



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function ProfileString()
*+
*+    Called from ( click.prg    )  39 - procedure click()
*+                                   2 - static procedure thealigner()
*+                ( declbust.prg )   4 - procedure declbust()
*+                ( functrak.prg )   2 - procedure init_func_text()
*+                                  11 - procedure func_text()
*+                ( libread.prg  )   1 - procedure libread()
*+                ( obufwrit.prg )   1 - function bo_init()
*+                ( profile.prg  )   1 - function profilenum()
*+                                   1 - function profiledate()
*+
*+       Calls    ( profile.prg  )   1 - static function init_profile()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function ProfileString(cFile,cSection,cKey,cDefault)



//
//  This function reads a string from the specified .INI file.
//
//  Parameters: cFile    - The .INI file name to be used
//              cSection - The section from which to read
//              cKey     - The key value for which to search
//              cDefault - The default value if not found (optional)
//
//     Returns: cString - The string read from the file.
//

local nSPointer := 0
local nKPointer := 0
local cString

default cDefault to ''
cString := cDefault

begin sequence

   if INI_NAME <> cFile
      if !init_profile(cFile)
         break
      endif
   endif

   cSection := upper(alltrim(cSection))
   cKey     := upper(alltrim(cKey))

   if left(cSection,1) <> '['
      cSection := '['+cSection
   endif

   if right(cSection,1) <> ']'
      cSection += ']'
   endif

   nSPointer := ascan(INI_DATA,{| x | x[1] == cSection})

   if !empty(nSPointer)
      nKPointer := ascan(INI_DATA[nSPointer,2],{| x | x[1] == cKey})
      if !empty(nKPointer)
         cString := INI_DATA[nSPointer,2,nKPointer,2]
      endif
   endif

end sequence
return cString



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function ProfileNum()
*+
*+    Called from ( click.prg    )  12 - procedure click()
*+                ( libread.prg  )   1 - procedure libread()
*+
*+       Calls    ( profile.prg  )   1 - static function init_profile()
*+                ( profile.prg  )   1 - function profilestring()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function ProfileNum(cFile,cSection,cKey,nDefault)



//
//  This function reads a number from the specified .INI file.
//
//  Parameters: cFile    - The .INI/.ini file name to be used
//              cSection - The section from which to read
//              cKey     - The key value for which to search
//              nDefault - The default value if not found (optional)
//
//     Returns: nValue - The numeric value read from the file.
//

local retval

default nDefault to 0
retval := nDefault

begin sequence

   if INI_NAME <> cFile
      if !init_profile(cFile)
         break
      endif
   endif

   retval := ProfileString(cFile,cSection,cKey,'')

   if empty(retval)
      retval := nDefault
   else
      retval := val(retval)
   endif

end sequence

return retval



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function ProfileDate()
*+
*+       Calls    ( profile.prg  )   1 - static function init_profile()
*+                ( profile.prg  )   1 - function profilestring()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function ProfileDate(cFile,cSection,cKey,dDefault)



//
//  This function reads a date from the specified .INI file.
//
//  Parameters: cFile    - The .INI file name to be used
//              cSection - The section from which to read
//              cKey     - The key value for which to search
//              dDefault - The default date if not found (optional)
//
//     Returns: dDate - The date value read from the file.
//
local retval

default dDefault to ctod('')
retval := dDefault

begin sequence

   if INI_NAME <> cFile
      if !init_profile(cFile)
         break
      endif
   endif

   retval := ProfileString(cFile,cSection,cKey,'')

   if empty(retval)
      retval := dDefault
   else
      retval := ctod(retval)
   endif

end sequence

return retval

/*
function SetProfile( cFile, cSection, cKey, xValue )
//
//  This function writes a value to the .INI file specified.
//
//  Parameters: cFile    - The .INI file name to be used
//              cSection - The section for which to search
//              cKey     - The key value for which to search
//              xValue   - The new value to be written
//
//     Returns: .T. if successful, .F. otherwise.
//

Remember: When implementing this section that init_profile() throws away
anything that is empty line, comment (//) and anything that is not
either a section header or a line with no = sign.

This means that this section absolutely cannot rely on init_profile()
and must have it's own file reader/writer

return lRetCode
*/



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function init_profile()
*+
*+    Called from ( profile.prg  )   1 - function profilestring()
*+                                   1 - function profilenum()
*+                                   1 - function profiledate()
*+
*+       Calls    ( obufread.prg )   1 - function bclose()
*+                ( obufread.prg )   1 - function beof()
*+                ( obufread.prg )   1 - function binit()
*+                ( obufread.prg )   1 - function bopen()
*+                ( obufread.prg )   1 - function breadline()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function init_profile(cFile)



local oBufObj       := bInit(cFile)
local retval        := bopen(oBufObj)
local cThisLine
local lFoundSection := .f.
local nLastElement  := 0
local eqat

INI_DATA := {}
INI_NAME := ''

if retval
   INI_NAME := cFile
   do while !bEof(oBufObj)

      cThisLine := alltrim(bReadLine(oBufObj))

      if empty(cThisLine) .or. left(cThisLine,2) == '//'
         loop
      endif

      if !lFoundSection
         if left(cThisLine,1) == '[' .and. right(cThisLine,1) == ']'
            lFoundSection := .t.
         else
            loop
         endif
      endif

      if left(cThisLine,1) == '[' .and. right(cThisLine,1) == ']'
         aadd(INI_DATA,{upper(cThisLine),{}})
         nLastElement ++
      else
         eqat := at('=',cThisLine)
         if eqat > 0
            aadd(INI_DATA[nLastElement,2],;
             {upper(alltrim(left(cThisLine,eqat - 1))),;
             substr(cThisLine,eqat+1)})
         endif
      endif
   enddo
   bClose(oBufObj)
endif

return retval



*+ EOF: profile.prg
*+
