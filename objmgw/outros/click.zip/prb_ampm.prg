*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/prb_ampm.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function AM_PM()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "common.ch"



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function AM_PM()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                ( functrak.prg )   4 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function AM_PM(cTime,lShowSecs)



// my own ampm function with defaults

local nHour
local cAmPm := ' am'

default lShowSecs to .f.
default cTime to time()

nHour := val(left(cTime,2))

if nHour > 11
   cAmPm := ' pm'
   nHour -= 12
endif

if nHour = 0
   nHour := 12
endif

return str(nHour,2)+substr(cTime,3,iif(lShowSecs,6,3))+cAmPm



*+ EOF: prb_ampm.prg
*+
