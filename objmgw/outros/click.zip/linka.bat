copy c:\devgit\hb32\include\harbour.hbx
call call C:\DEVPRG\hb64mgw10\hb64mgw10
hbmk2 click.hbp
