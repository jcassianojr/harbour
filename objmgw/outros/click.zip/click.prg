*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/click.prg
*+
*+
*+    Functions: Procedure click()
*+               Static Function afront()
*+               Static Function bReadPart()
*+               Procedure centertext()
*+               Init Procedure CLIPINIT()
*+               Static Function dbc_identify()
*+               Procedure ERRORSYS()
*+               Static Procedure exitproc()
*+               Static Function func_head()
*+               Static Function IndentLevel()
*+               Static Procedure IndentReset()
*+               Static Function leadspace()
*+               Function lineparse()
*+               Static Procedure main_screen()
*+               Static Function pop_stack()
*+               Function RootName()
*+               Procedure setlinecont()
*+               Procedure show_in()
*+               Procedure show_out()
*+               Function TabSpStrip()
*+               Function TabStrip()
*+               Static Procedure TheAligner()
*+
*+       Tables: use ( cDBFPath ) //shared
*+               use ( cDBFPath ) exclusive
*+
*+      Indexes: index on click->FNCT+click->SRCE TAG funct_src UNIQUE //added click-> harbour 2/09
*+               index ON click->FNCT+click->SRCE TO (cNSXPath) //added click->harbour 2/09
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+

REQUEST HB_LANG_PT


//3/06 need to be lowercase for Linux
#include "directry.ch"
#include "common.ch"
#include "inkey.ch"
#include "fileio.ch"
#define CVERSION '3.00Harbour'
#define newline  11

static nLineCount    := 0
static nMasterCount  := 0
static lLineContinue := .f.
static lLastContinue := .f.
static nStripComment := 0
static lCommentMode  := .f.
static oOutHandle,cFuncDiv
static lDumpBuffer   := .f.
static lMoreToGo     := .f.
static aCommand      := {}
static aCmdLogic     := {}
static aFunction     := {}
static cComCase,cFunCase,cBoolCase
static nAlignMethod,nUnCase,nUnFor,nUnSequence
static lVerbose,lMode5,nComntTab,lConvertSlash,lConvertStar
static lConvertArray,lRemDupMTLine
static lGotClass     := .f.
static lDeflate1,lDeflate2,lDeflate3,lDeflate4,lDeflate5
static nTabIf,nIndIf,nTabFor,nIndFor,nTabCase,nIndCase,nTabFunc,nTabContinue
static nIndFunc,nTabBegin,nIndBegin,nTabWhile,nIndWhile,nTabClass
static lRestScrn
static nMidScreen    := 15



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure click()
*+
*+    Called from ( clickstart.p )   1 - function clickstart()
*+
*+       Calls    ( click.prg    )  16 - static function afront()
*+                ( prb_ampm.prg )   1 - function am_pm()
*+                ( obufread.prg )   2 - function bclose()
*+                ( obufread.prg )   3 - function beof()
*+                ( obufread.prg )   1 - function bgetset()
*+                ( obufread.prg )   3 - function binit()
*+                ( obufread.prg )   2 - function blinenumber()
*+                ( obufread.prg )   2 - function bopen()
*+                ( obufwrit.prg )   1 - procedure bo_close()
*+                ( obufwrit.prg )   1 - function bo_init()
*+                ( obufwrit.prg )   1 - function bo_open()
*+                ( obufwrit.prg )  22 - procedure bo_write()
*+                ( obufread.prg )   2 - function breadline()
*+                ( click.prg    )   3 - static function breadpart()
*+                ( obufread.prg )   1 - function brelative()
*+                ( obufread.prg )   1 - function brestset()
*+                ( click.prg    )   2 - procedure centertext()
*+                ( filnpath.prg )   1 - function createhdr()
*+                ( filnpath.prg )   1 - function createini()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( julian.prg   )   1 - function diff2jul()
*+                ( unresolved   )   1 - function DIRMAKE()
*+                ( functrak.prg )   1 - procedure end_func_text()
*+                ( err_log.prg  )  22 - procedure err_log()
*+                ( click.prg    )   8 - static procedure exitproc()
*+                ( profile.prg  )   2 - function profiledate()
*+                ( unresolved   )   2 - function filetime()
*+                ( functrak.prg )   1 - procedure func_call()
*+                ( click.prg    )   1 - static function func_head()
*+                ( functrak.prg )   1 - procedure init_func_text()
*+                ( prb_stak.prg )   1 - procedure getscreen()
*+                ( click.prg    )   7 - static function indentlevel()
*+                ( click.prg    )   4 - static procedure indentreset()
*+                ( functrak.prg )   1 - procedure init_func_text()
*+                ( cmd_list.prg )   1 - function init_list()
*+                ( libread.prg  )   2 - procedure libread()
*+                ( click.prg    )   2 - function lineparse()
*+                ( click.prg    )   2 - static procedure main_screen()
*+                ( nicedate.prg )   1 - function nicedate()
*+                ( cmd_list.prg )   1 - function op_list()
*+                ( prb_pop.prg  )   9 - procedure pop_msg()
*+                ( click.prg    )   1 - static function pop_stack()
*+                ( profile.prg  )  12 - function profilenum()
*+                ( profile.prg  )  39 - function profilestring()
*+                ( prb_stak.prg )   2 - procedure putscreen()
*+                ( readlist.prg )   1 - function readlist()
*+                ( readlnk.prg  )   1 - function readlnk()
*+                ( click.prg    )   4 - function rootname()
*+                ( click.prg    )   2 - procedure show_in()
*+                ( click.prg    )  14 - procedure show_out()
*+                ( julian.prg   )   4 - function td2jul()
*+                ( click.prg    )   1 - static procedure thealigner()
*+                ( prb_pop.prg  )   4 - function verify()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure click(filespec)   //to about line 1460


local aStack     := {}
local aFileNames,aParse,aLine,uLine,aType
local oBuffObj1,oBuffObj2
local aFileList  := {}
local aLibList   := {}
local aNewLine,aNewType,aAss,aTss,aVars,aTars
local atemp      := {}  //flagship debugging

local cThisFile,cPathFile,cOutFile,cOrigLine,nOrigLen
local cThisLine,uThisLine,cHeadText,cLast,cClickini
//local cOSCRLF    := HB_OSNewLine()
local cOSCRLF
local cContSpace := ''
local cDBFPath,cNSXPath,cComment,cOutput,cFirstWord,cErrorText,cThisText
local cGrab      := ''
local cHeadDiv,cOutExt,cOutDir,cOutOver,cClickLog,cFullPath
local dirsep,drivesep

local x,xx,y
local nNumFiles,nPointer,nDefIndent,nMaxSmartAlign,nOutPad,nParenCount
local nFileCount       := 0
local nFirstNonComment,nPcntDone,nOldPcntDone,nTo,nLineLen
local ntemp   //nHandle   //harbour conversion

local lContSpace  := .f.
local lGrabMore   := .f.
local lCaseIndent,lClickAdd,lClickEOF,lConvertDo,lDeclBust,lErrNotify
local lClickFunc,lClickKill,lEraseLog,lFuncIndent,lFileList,lGotFunction,lGotOne
local lIfCommand,lLinkList,lLocIndent,lMultKill,lRepl2Assign,lRetTimeDate
local lSkipFiles,lSnapKill,lStor2assign,lTheAligner

local nStartJulian
local cTemp

local oBuffSave,lTempFunction,bTempLine,tLine,tType,lOnReturn

//altd()
setmode(25,80)

HB_LANGSELECT('PT')       // Default language is now Portuguese
set scoreboard off
set cursor off
set epoch to year(date()) - 50
cOSCRLF := HB_OSNewLine()
IF CHR(13)+CHR(10) = cOSCRLF  //must be ms based
   dirsep   := '\'
   drivesep := DISKNAME()+':'
ELSE  //must be linux,chr(10) or mac chr(13)
   dirsep   := '/'
   drivesep := ''
   //  SET PATH '.;/home/paul/click')
ENDIF
cFullPath := drivesep+dirsep+CURDIR(drivesep)+dirsep  //10/03 local copy in startup directory
cDBFPath  := cFullPath+'click.dbf'
cNSXPath  := cFullPath+'click.ntx'  //5/05 just the name +ordbagext()
cClickini := cFullPath+'click.ini'
IF ! file(cfullpath+'click.hdr')   //just default to oscrlf, update if required later
   createhdr(cfullpath+'click.hdr',cOSCRLF)
ENDIF
if ! file(cClickini)   //if we add click.ini we probably added click.hdr
   createini(cClickini)
   if verify({'click.ini and click.hdr set to default.',;
              'Do you  wish to edit before proceeding?'},.f.,'Exit & edit','Continue')
      exitproc()
      quit
   endif
endif
cHeadDiv := ProfileString(cClickini,'CLICK','HEAD_DIV','-')
cOutExt  := ProfileString(cClickini,'CLICK','OUTPUT_EXTENSION','.prg')
cOutDir  := cFullPath+;
 ProfileString(cClickini,'CLICK','OUTPUT_DIRECTORY','clickout')+dirsep
ntemp := DIRCHANGE(cOutDir)   //returns 0 if successful
DO CASE   //make sure we have different output directory
CASE cFullPath == cOutDir .and. upper(cOutExt) = '.PRG'   //don't allow overwriting current prg files
   POP_MSG({'Exiting, input directory same as output:',cOutdir},.t.)
   exitproc()
   quit
CASE ntemp = 0  //successfully changed directory
   DIRCHANGE(cFullPath)   //back to original directory
CASE ntemp != 0   //we failed to change, try creating directory
   ntemp := DIRMAKE(cOutdir)
   IF ntemp != 0  //we failed to create directory
      POP_MSG({'Exiting, failed to create directory, ',cOutdir+;
       ', with error code '+STR(ntemp,4,0)},.t.)
      exitproc()
      quit
   endif
ENDCASE
cOutOver       := ProfileString(cClickini,'CLICK','OUTPUT_OVERWRITE','ASK')
cClickLog      := ProfileString(cClickini,'CLICK','CLICK_LOG','click.log')
nDefIndent     := ProfileNum(cClickini,'CLICK','DEFAULT_INDENT',8)
nMaxSmartAlign := ProfileNum(cClickini,'CLICK','SMART_ALIGN_MAX_ELEMENTS',11)
lSnapKill      := ProfileString(cClickini,'CLICK','REMOVE_SNAP_HEADERS','YES') == 'YES'
lMultKill      := ProfileString(cClickini,'CLICK','REMOVE_MULTIEDIT_HEADERS','YES') == 'YES'
lClickKill     := ProfileString(cClickini,'CLICK','REMOVE_CLICK_HEADERS','YES') == 'YES'
lClickAdd      := ProfileString(cClickini,'CLICK','ADD_CLICK_HEADER','YES') == 'YES'
lClickFunc     := ProfileString(cClickini,'CLICK','ADD_FUNCTION_HEADERS','YES') == 'YES'
lClickEOF      := ProfileString(cClickini,'CLICK','ADD_EOF_MARKER','YES') == 'YES'
lErrNotify     := ProfileString(cClickini,'CLICK','NOTIFY_OF_ERROR_ON_SCREEN','YES') == 'YES'
lEraseLog      := ProfileString(cClickini,'CLICK','CLICK_LOG_ERASE','YES') == 'YES'
lFuncIndent    := ProfileString(cClickini,'CLICK','INDENT_FUNCTIONS','NO') == 'YES'
lLocIndent     := ProfileString(cClickini,'CLICK','INDENT_LOCALS','NO') == 'YES'
lCaseIndent    := ProfileString(cClickini,'CLICK','INDENT_DO_CASE','NO') == 'YES'
lDeclBust      := ProfileString(cClickini,'CLICK','PREPROCESS_WITH_DECLARATION_BUSTER','YES') == 'YES'
lTheAligner    := ProfileString(cClickini,'CLICK','POSTPROCESS_WITH_THE_ALIGNER','YES') == 'YES'
lRepl2Assign   := ProfileString(cClickini,'CLICK','CHANGE_REPLACE_WITH_TO_ASSIGNMENT','YES') == 'YES'
lStor2Assign   := ProfileString(cClickini,'CLICK','CHANGE_STORE_TO_ASSIGNMENT','YES') == 'YES'
lRetTimeDate   := ProfileString(cClickini,'CLICK','RETAIN_ORIGINAL_TIME_DATE_ON_OUTPUT_FILES','YES') == 'YES'
lSkipFiles     := ProfileString(cClickini,'CLICK','SKIP_FILES_WITH_NO_CHANGES','YES') == 'YES'
lConvertDo     := ProfileString(cClickini,'CLICK','CONVERT_OLD_STYLE_FUNCTIONS','NO') == 'YES'
//end of group moved from local statements

cFuncDiv      := ProfileString(cClickini,'CLICK','FUNC_DIV','�')
cComCase      := ProfileString(cClickini,'CLICK','CASE_OF_COMMANDS','NOCHANGE')
cFunCase      := ProfileString(cClickini,'CLICK','CASE_OF_FUNCTIONS','NOCHANGE')
cBoolCase     := ProfileString(cClickini,'CLICK','CASE_OF_BOOLEAN','NOCHANGE')
nAlignMethod  := ProfileNum(cClickini,'CLICK','@_SAY_GET_ALIGNMENT_METHOD',1)
lVerbose      := ProfileString(cClickini,'CLICK','VERBOSE','YES') == 'YES'
nComntTab     := ProfileNum(cClickini,'CLICK','COMMENTTAB',10)
lConvertSlash := ProfileString(cClickini,'CLICK','CONVERT_&&_TO_//','YES') == 'YES'
lConvertStar  := ProfileString(cClickini,'CLICK','CONVERT_*_TO_//','YES') == 'YES'
lConvertArray := ProfileString(cClickini,'CLICK','CONVERT_][_TO_,','YES') == 'YES'
lDeflate1     := ProfileString(cClickini,'CLICK','DEFLATE_(','NO') == 'YES'
lDeflate2     := ProfileString(cClickini,'CLICK','DEFLATE_[','NO') == 'YES'
lDeflate3     := ProfileString(cClickini,'CLICK','DEFLATE_{','NO') == 'YES'
lDeflate4     := ProfileString(cClickini,'CLICK','DEFLATE_,','NO') == 'YES'
lDeflate5     := ProfileString(cClickini,'CLICK','DEFLATE_+','NO') == 'YES'


nTabIf       := ProfileNum(cClickini,'CLICK','INDENT_IF',3)
nIndIf       := 0
nTabFor      := ProfileNum(cClickini,'CLICK','INDENT_FOR',3)
nIndFor      := 0
nTabCase     := ProfileNum(cClickini,'CLICK','INDENT_CASE',3)
nIndCase     := 0
nTabFunc     := ProfileNum(cClickini,'CLICK','INDENT_FUNC',3)
nIndFunc     := 0
nTabBegin    := ProfileNum(cClickini,'CLICK','INDENT_BEGIN',3)
nIndBegin    := 0
nTabWhile    := ProfileNum(cClickini,'CLICK','INDENT_WHILE',3)
nIndWhile    := 0
nTabClass    := ProfileNum(cClickini,'CLICK','INDENT_CLASS',3)
nTabContinue := ProfileNum(cClickini,'CLICK','INDENT_CONTINUE_LINE',1)

lMode5        := upper(ProfileString(cClickini,'CLICK','RUNMODE','5.X')) == '5.X'
lRestScrn     := upper(ProfileString(cClickini,'CLICK','RESTORE_SCREEN_ON_EXIT','NO')) == 'YES'
lRemDupMTLine := ProfileString(cClickini,'CLICK','REMOVE_DUPLICATE_EMPTY_LINES','YES') == 'YES'
if !lMode5
   lDeclBust := .f.
endif
default filespec to '*.prg'
putscreen()

if UPPER(filespec) $ '/REBUILD|/UPDATE|CLICK.DBF'
   main_screen(filespec)
   libread(cDBFPath,cNSXPath,cClickini)
   exitproc()
   quit
endif

lFileList := left(filespec,1) == '@'

lLinkList := '.LNK' $ UPPER(filespec)   //probably not a xHarbour thing

if RootName(filespec) == filespec
   filespec += '.prg'   //default to lower case prg file
endif

do case
case lLinkList
   if left(filespec,1) == '@'
      filespec := substr(filespec,2)
   endif

   cTemp     := readlnk(filespec)
   aFileList := cTemp[1]
   aLibList  := cTemp[2]

case lFileList
   aFileList := readlist(substr(filespec,2),'@')
otherwise
   aFileNames := directory(filespec)
   nNumFiles  := len(aFileNames)
   for x := 1 to nNumFiles
      aadd(aFileList,aFileNames[x,F_NAME])
   next
endcase

aFileList := asort(aFileList)

nNumFiles := len(aFileList)

if nNumFiles == 0
   clear screen
   ? 'Click! '+CVERSION
   ?
   ? 'Usage:'
   ?
   ? '    CLICK [ [@]<filename/filespec> ]'
   ?
   ? '       Where:'
   ?
   ? '       <filename> is the name of your link script (myprog.lnk)'
   ? '   or'
   ? '       <filespec> is a legal filespec. Wildcards permitted.'
   ? '                  (myprog.prg) (*.prg)'
   ? '                  Click with no parameters assumes *.prg'
   ? '   or'
   ? '       @<filename> is a text file containing a list of filenames'
   ? '                   (progname.txt)'
   ?
   quit
endif

main_screen(filespec)

if ! file(cDBFPath)
   if verify('Click! needs to scan your library files.',.t.,'OK','Quit')
      putscreen()
      libread(cDBFPath,cNSXPath,cClickini)
      getscreen()
   else
      devpos(maxrow() - 2,0)
      exitproc()
      quit
   endif
endif

if lConvertDo
   if verify({'You have turned on the conversion of DO/WITH',;
              'to formal function with parameters',;
              '',;
              'CONVERT_OLD_STYLE_FUNCTIONS=YES',;
              '',;
              'Due to DO/WITH passing the parameters by reference',;
              'and FUNCTION( PARAMETERS ) not passing by reference,',;
              'the only way to make the change is to precede all',;
              'parameters in the parameter list with @',;
              '',;
              'This has the potential to cause compiler error C2009',;
              '',;
              'To correct the compiler errors, you will have to',;
              'remove the @ sign when it is not needed in the',;
              'converted function call and recompile'},.f.,'Continue','Stop')
   else
      quit
   endif
endif

dbcloseall()
use ( cDBFPath ) //shared
if file(cNSXPath)
   set index to (cNSXPath)
else
   dbcloseall()
   use ( cDBFPath ) exclusive
   show_in('Creating '+cNSXPath+' for '+cDBFPath)
   index on click->FNCT+click->SRCE TAG funct_src UNIQUE  //added click-> harbour 2/09
   //don't think funct_src tag is required
   index ON click->FNCT+click->SRCE TO (cNSXPath)   //added click->harbour 2/09
   dbcloseall()
   use ( cDBFPath ) //shared
   set index to (cNSXPath)
endif

click->(dbsetorder(1))

cClickLog := cOutDir+cClickLog

if lEraseLog
   ferase(cClickLog)
endif

err_log(cClickLog,'>>>>>> Click! Run Start: '+dtos(date())+' '+time())
err_log(cClickLog,'')

// Initialize the arrays that the program uses to figure out things...

show_in('Initializing Arrays from '+cClickini+' file')

aLine     := init_list(cClickini)   // why waste a variable name here???
aCommand  := aLine[1]   //it sure makes dubugging interesting!
aFunction := aLine[2]
aCmdLogic := aLine[3]
op_list('')

nStartJulian := td2jul()

begin sequence  //start looping through file list
   for xx := 1 to nNumFiles   //next around 1335

      cThisFile := afileList[xx]

      if ! file(cThisFile)
         loop
      endif

      IndentReset()
      cContSpace    := ''
      lContSpace    := .f.
      lCommentMode  := .f.
      lLineContinue := .f.
      lLastContinue := .f.
      nLineCount    := 0
      nStripComment := 0

      @  4,1 clear to 4,maxcol() - 1

      cPathFile := cFullPath+cThisFile

      centertext('Current File => '+cPathFile,4)

      if upper(cOutExt) == '.PRG' .and. (cOutDir == '.' .or. empty(cOutDir))
         pop_msg({'You cannot use the .PRG extension',;
          'unless you direct output to a different directory'})
         devpos(maxrow() - 2,0)
         exitproc()
         quit
      endif

      if lSkipFiles   //skip files without changes
         cOutFile := cOutDir+RootName(cThisFile)+cOutExt
         if file(cOutFile)
            if td2jul(filetime(cOutFile),filedate(cOutFile)) >= ;
                              td2jul(filetime(cPathFile),filedate(cPathFile))
               show_out('Skipping '+cPathFile)
               loop
            endif
         endif
      endif

      if lTheAligner
         cOutFile := '$prealin.tmp'
      else
         cOutFile := cOutDir+RootName(cThisFile)+cOutExt
      endif

      if cOutOver != 'ALWAYS'
         if file(cOutFile)
            if cOutOver == 'ASK'
               if !verify({'Output file exists. Overwrite?','','<Esc> to end Click!'})
                  if lastkey() == 27
                     exitproc()
                     quit
                  else
                     loop
                  endif
               endif
            else
               loop
            endif
         endif
      endif

      nFileCount ++

      @  6,5 clear to 6,maxcol() - 5

      @  6,5 say 'PASS'         

      centertext('File '+ltrim(str(xx))+' of '+ltrim(str(nNumFiles)),7)

      if lDeclBust
         @  6,10 say '1' //this strips indents and puts variable delcarations on separate lines         
         declbust(cThisFile,'$declbst.tmp',cClickini)
         oBuffObj1 := bInit('$declbst.tmp')   //set obuff to this temp file
      else
         oBuffObj1 := bInit(cThisFile)  //set obuff to this original file
      endif
      @  6,10 say '2'         
      init_func_text(cThisFile,cClickini)
      nPcntDone := 0
      if bopen(oBuffObj1)   //opening $declbst or cthisfile(.prg file)

         ferase(cOutFile)
         oOutHandle := bo_init(cOutFile,FO_WRITE,oBuffObj1[newline],cClickini)
         bo_open(oOutHandle)  //open the output file

         if lClickAdd
            bo_write(oOutHandle,'*+'+replicate(cHeadDiv,68)+oBuffObj1[newline])
            bo_write(oOutHandle,'*+'+oBuffObj1[newline])
            //bo_write(oOutHandle,'*+    Source Module => '+cFullPath+cThisFile+oBuffObj1[newline])
            bo_write(oOutHandle,'*+    Programa  : '+cThisFile+oBuffObj1[newline])
            oBuffObj2 := {}
            oBuffObj2 := bInit('click.hdr',,)
            if !empty(oBuffObj2)
               bo_write(oOutHandle,'*+'+oBuffObj1[newline])
               if bopen(oBuffObj2)
                  do while !beof(oBuffObj2)   //write will match whatever is in original file
                     bo_write(oOutHandle,'*+    '+bReadLine(oBuffObj2)+oBuffObj1[newline])
                     @  6,67 say str(bLineNumber(oBuffObj2),8)         
                  enddo
               endif
               bclose(oBuffObj2)
            endif

            bo_write(oOutHandle,'*+'+oBuffObj1[newline])
            //bo_write(oOutHandle,'*+    Reformatted by Click! '+CVERSION+' on '+nicedate(date())+' at '+am_pm(time())+oBuffObj1[newline])
            bo_write(oOutHandle,'*+    Documentado em '+nicedate(date())+' as '+am_pm(time())+oBuffObj1[newline])
            bo_write(oOutHandle,'*+'+oBuffObj1[newline])
            bo_write(oOutHandle,'*+'+replicate(cHeadDiv,68)+oBuffObj1[newline])
            if !lRemDupMTLine   //3/06 comment out ??
               bo_write(oOutHandle,oBuffObj1[newline])
            endif
         endif

         do while !beof(oBuffObj1) .or. lMoreToGo   //end of loop ~1340

            nOldPcntDone := nPcntDone
            nPcntDone    := int(bRelative(oBuffObj1) * 50)  //return percent processed
            if nOldPcntDone <> nPcntDone
               @  6,14 say replicate('',nPcntDone) color 'GB+/B'        
            endif
            aParse    := bReadPart(oBuffObj1)   //read line from buffer pass it to parser
            aLine     := aParse[1]  //all columns of row one
            aType     := aParse[2]  //all columns of row two
            cOrigLine := aParse[3]  //all columns of row three
            nLineLen  := len(aLine)
            if lGrabMore
               lGrabMore := .f.
               cOrigLine := cGrab+cOrigLine
               aParse    := lineparse(cOrigLine)
               aLine     := aParse[1]
               aType     := aParse[2]
            else
               lGrabMore := .f.
               if nlineLen == 3
                  if upper(aLine[1]) == 'DO' .and. aLine[3] == ';'
                     lGrabMore := .t.
                     cGrab     := aLine[1]+' '
                     loop
                  endif
               endif
            endif

            // does the user want out?

            if inkey() == 27
               break
            endif
            //if lastcontinue was true at this point and an * is
            //first should be a multiply but becomes a comment
            lLastContinue := lLineContinue
            lLineContinue := ascan(aType,'LC') > 0

            // Blow past empty lines

            if empty(aLine)
               bo_write(oOutHandle,oBuffObj1[newline])
               show_out('')
               lMoreToGo  := .f.
               cContSpace := ''
               lContSpace := .f.
               loop
            endif

            // Kill Click Headers

            if pad(cOrigLine,2) == '*�'   // old style headers that sucked
               loop
            endif

            if lClickKill
               if pad(cOrigLine,2) == '*+'
                  loop
               endif
            endif

            // Kill Snap Headers

            if lSnapKill
               if pad(cOrigLine,2) $ '*:|*!'
                  loop
               endif
            endif

            // Kill Multi-Edit headers

            if lMultKill
               if pad(cOrigLine,2) == '#/' .or. ;
                               left(cOrigLine,6) == '/* --%'
                  loop
               endif
            endif

            // Check for /* and */ comments and skip them

            if lCommentMode
               if (nPointer := at('*/',cOrigLine)) > 0
                  nPointer ++
                  lCommentMode := .f.
                  bo_write(oOutHandle,left(cOrigLine,nPointer)+oBuffObj1[newline])
                  show_out(left(cOrigLine,nPointer))
                  cOrigLIne := substr(cOrigLine,nPointer+1)
                  if !empty(cOrigLine)
                     nStripComment := nPointer+1
                  endif
                  loop
               else
                  bo_write(oOutHandle,cOrigLine+oBuffObj1[newline])
                  show_out(cOrigLine)
                  loop
               endif
            else
               if atail(aType) == '/*'
                  lCommentMode := .t.
               endif
            endif

            // write comments and loop


            if left(aLine[1],1) == '*' .and. !llastcontinue   //no comments in middle of line 3/06
               cOrigLine := alltrim(cOrigLine)
               nOrigLen  := len(cOrigLine)
               if lConvertStar
                  do case
                  case nOrigLen == 1
                     cOrigLine := '//'
                  case nOrigLen > 1 .and. left(cOrigLine,2) <> '*+'
                     cOrigLine := '// '+substr(cOrigLine,2)
                  endcase
               endif
               bo_write(oOutHandle,space(IndentLevel())+cOrigline+oBuffObj1[newline])
               show_out(space(IndentLevel())+cOrigLine)
               lDumpBuffer := .t.
               loop
            endif

            // write # directives and loop

            if aType[1] == '#'

               bo_write(oOutHandle,ltrim(cOrigLine)+oBuffObj1[newline])
               lDumpBuffer := .t.
               show_out(ltrim(cOrigLine))
               if ascan(aType,'LC') > 0
                  // if right( trim( cOrigLine ), 1 ) == ';'
                  do while .t.
                     cOrigLine := bReadLine(oBuffObj1)
                     @  6,67 say str(bLineNumber(oBuffObj1),8)         
                     bo_write(oOutHandle,cOrigLine+oBuffObj1[newline])
                     show_out(ltrim(cOrigLine))
                     aParse := lineparse(cOrigLine)
                     aLine  := aParse[1]
                     aType  := aParse[2]
                     if ascan(aType,'LC') == 0
                        exit
                     endif
                  enddo
               endif
               loop
            endif

            // smart indent on @

            if aLine[1] == '@' .and. !lLastContinue
               if len(aLine) > 2
                  if val(aLine[3]) < 10 .and. aLine[3] $ '9876543210'
                     aLine[ 3 ] := ' '+aLine[3]
                  endif
               endif
               if len(aLine) > 5
                  if val(aLine[6]) < 10 .and. aLine[6] $ '9876543210'
                     aLine[ 6 ] := ' '+aLine[6]
                  endif
               endif
            endif

            // clone the aLine array, but in upper case

            uLine    := aclone(aLine)
            nPointer := len(ULine)
            for y := 1 to nPointer
               uLine[ y ] := upper(uLine[y])
            next

            // it's possible that a line starts with a /**/ comment
            // if so, find the first non-comment pointer

            nFirstNonComment := 1
            for x := 1 to nPointer
               if aType[x] == '/**/' .or. aLine[x] == ' '
                  nFirstNonComment := x+1
                  if nFirstNonComment > len(aType)
                     nFirstNonComment := 1
                  endif
               else
                  exit
               endif
            next

            // decrease the indent level on an END or NEXT

            if !lLastContinue
               begin sequence
                  //this will pickup both 'C' and 'CT' types
                  if aType[nFirstNonComment] $ 'CT' .and. ;
                             (left(uLine[nFirstNonComment],3) == 'END' .or. ;
                             left(uLine[nFirstNonComment],4) == 'NEXT')

                     if (left(uLine[nFirstNonComment],8) == 'ENDCLASS' .or. ;
                                   (len(uLine) > 2 .and. ;
                                   left(uLine[nFirstNonComment],3) == 'END') .and. ;
                                   left(uLine[nFirstNonComment+2],5) == 'CLASS')
                        break
                     endif

                     cLast := pop_stack(aStack)
                     do case
                     case empty(cLast)
                        cErrorText := 'Control Underflow: Error detected at line '+alltrim(str(nLineCount))
                        if lErrNotify
                           pop_msg(cErrorText)
                        endif
                        err_log(cClickLog,cPathFile)
                        err_log(cClickLog,cErrorText)
                        err_log(cClickLog,'')
                        IndentReset()
                        aStack := {}
                     case cLast == 'IF'
                        nIndIf --
                     case cLast == 'FOR'
                        nIndFor --
                     case cLast == 'CASE'
                        nIndCase --
                        if lCaseIndent .and. cLast == 'CASE'
                           nIndCase --
                        endif
                     case cLast == 'BEGIN'
                        nIndBegin --
                     case cLast == 'WHILE'
                        nIndWhile --
                     endcase

                  endif
               end sequence
            endif

            if lFuncIndent

               // read ahead to see if this is the last return

               if aType[nFirstNonComment] $ 'CT' .and. ;
                          left(uLine[nFirstNonComment],4) == 'RETU'
                  oBuffSave := bGetSet(oBuffObj1)   //save pointer position

                  lTempFunction := .f.
                  lOnReturn     := .t.
                  tType         := aclone(aType)
                  do while .t.

                     if lOnReturn
                        if ascan(tType,'LC') > 0
                           bTempLine := bReadPart(oBuffObj1)
                           tLine     := bTempLine[1]
                           tType     := bTempLine[2]
                           loop
                        endif
                        lOnReturn := .f.
                     endif

                     bTempLine := bReadPart(oBuffObj1)

                     tLine := bTempLine[1]
                     tType := bTempLine[2]

                     do case
                     case len(tLine) > 2 .and. ;
                         upper(pad(tLine[1],4)) $ 'FUNC|PROC|METH|CLAS' .and. ;
                         tType[1] $ 'CT' .and. ;
                         left(tLine[2],1) <> '('
                        lTempFunction := .t.
                     case len(tLine) > 4 .and. ;
                         upper(left(tLine[1],4)) $ 'STAT|EXIT|INIT' .and. ;
                         tType[3] $ 'CT' .and. ;
                         upper(pad(tLine[3],4)) $ 'FUNC|PROC|METH|CLAS'
                        lTempFunction := .t.
                     case bEof(oBuffObj1)
                        lTempFunction := .t.
                     case empty(tLine) .or. '//' $ tType[1] .or. '/*' $ tType[1]
                     otherwise
                        exit
                     endcase

                     if lTempFunction
                        nIndFunc --
                        exit
                     endif

                  enddo

                  oBuffObj1 := bRestSet(oBuffSave)  //restore pointer position to obuffsave
               endif

            endif

            // check for underflow at any time

            if IndentLevel() < 0
               cErrorText := 'Control Underflow: Error detected at line '+alltrim(str(nLineCount))
               if lErrNotify
                  pop_msg(cErrorText)
               endif
               err_log(cClickLog,cPathFile)
               err_log(cClickLog,cErrorText)
               err_log(cClickLog,'')
               IndentReset()
               aStack := {}
            endif

            // correct Replace x with y statements if necessary

            if lRepl2Assign .and. lDeclBust
               if aType[nFirstNonComment] $ 'CT' .and. ;
                          left(uLine[nFirstNonComment],4) == 'REPL'

                  if ascan(uLine,'ALL') == 0 .and. ;
                                ascan(uLine,'WHIL') == 0 .and. ;
                                ascan(uLine,'FOR') == 0 .and. ;
                                ascan(uLine,'REST') == 0 .and. ;
                                ascan(uLine,'RECO') == 0 .and. ;
                                ascan(uLine,'NEXT') == 0

                     // Dump the word REPLACE and the space following it

                     adel(aLine,1)
                     adel(aLine,1)
                     asize(aLine,len(aLine) - 2)

                     adel(uLine,1)
                     adel(uLine,1)
                     asize(uLine,len(aLine))

                     adel(aType,1)
                     adel(aType,1)
                     asize(aType,len(aLine))

                     // put the field-> designator on the field name if needed

                     if at('->',aLine[1]) == 0
                        aLine[ 1 ] := 'FIELD->'+aLine[1]
                        uLine[ 1 ] := 'FIELD->'+uLine[1]
                     endif

                     // Then, replace the WITH with an :=

                     nPointer := len(aLine)

                     for x := 1 to nPointer
                        if uLine[x] == 'WITH'
                           aLine[ x ] := ':='
                           uLine[ x ] := ':='
                           aType[ x ] := 'O'
                        endif
                     next

                  endif

               endif
            endif

            if lMode5   //are we in clipper5.x mode?

               // correct STORE x to y, m, w statements if necessary

               if lStor2Assign
                  if aType[nFirstNonComment] $ 'CT' .and. ;
                             left(uLine[nFirstNonComment],4) == 'STOR'

                     do case
                     case atail(aType) == 'LC'
                        cErrorText := 'No Conversion of STORE due to ; at end of line '+alltrim(str(nLineCount))
                        if lErrNotify
                           pop_msg(cErrorText)
                        endif
                        err_log(cClickLog,cPathFile)
                        err_log(cClickLog,cErrorText)
                        err_log(cClickLog,'')

                     otherwise

                        // Dump the word STORE and the space following it

                        adel(aLine,1)
                        adel(aLine,1)
                        asize(aLine,len(aLine) - 2)

                        adel(uLine,1)
                        adel(uLine,1)
                        asize(uLine,len(aLine))

                        adel(aType,1)
                        adel(aType,1)
                        asize(aType,len(aLine))

                        // Find the pointer to the TO command.

                        nTo := ascan(uLine,{| x | x == 'TO'})

                        if nTo > 0

                           // grab the left half (assignment)

                           aNewLine := aclone(aLine)
                           aNewType := aclone(aType)

                           aAss := {}
                           aTss := {}
                           for x := 1 to nTo - 2
                              aadd(aAss,aNewLine[x])
                              aadd(aTss,aNewType[x])
                           next

                           // grab the vars to assign to

                           aVars       := {}
                           aTars       := {}
                           nParenCount := 0
                           for x := nTo+2 to len(aLine)
                              if aType[x] == '+'
                                 nParenCount ++
                              endif
                              if aType[x] == '-'
                                 nParenCount --
                              endif
                              if aLine[x] == ',' .and. nParenCount == 0
                                 aadd(aVars,' :=')
                                 aadd(aTars,'O')
                              else
                                 aadd(aVars,aNewLine[x])
                                 aadd(aTars,aNewType[x])
                              endif
                           next

                           aadd(aVars,' := ')
                           aadd(aTars,'O')

                           aLine := aclone(aVars)
                           aType := aclone(aTars)

                           for x := 1 to len(aAss)
                              aadd(aLine,aAss[x])
                              aadd(aType,aTss[x])
                           next

                        endif
                     endcase
                  endif
               endif
            endif
            // does this line start a function or method?
            //remember you never list a function until it is called

            lGotFunction := .f.
            if len(aLine) > 2 .and. ;
                        upper(pad(aLine[1],4)) $ 'FUNC|PROC|METH|CLAS' .and. ;
                        aType[1] $ 'CT' .and. ;
                        left(aLine[2],1) <> '('
               lGotFunction := .t.
            endif
            if len(aLine) > 4 .and. ;
                        upper(left(aLine[1],4)) $ 'STAT|EXIT|INIT|CREA' .and. ;
                        aType[3] $ 'CT' .and. ;
                        upper(pad(aLine[3],4)) $ 'FUNC|PROC|METH|CLAS'
               lGotFunction := .t.
            endif

            // turn off header detection in the middle of a class creation

            if lGotFunction .and. lGotClass
               lGotFunction := .f.
            endif

            if nIndFunc > 0 .and. lFuncIndent .and. lGotFunction
               nIndFunc --
            endif

            // check for overflow and create header if necessary

            if lGotFunction .and. !empty(cHeadText := func_head(aLine,oBuffObj1))
               if IndentLevel() > 0
                  cErrorText := 'Control Overflow: Error detected at line '+alltrim(str(nLineCount))
                  if lErrNotify
                     pop_msg(cErrorText)
                  endif
                  err_log(cClickLog,cPathFile)
                  err_log(cClickLog,cErrorText)
                  err_log(cClickLog,'')
               endif
               IndentReset()
               aStack := {}
               if lClickFunc
                  bo_write(oOutHandle,cHeadText)
               endif
            endif

            //this is the function that builds cross references
            //03/06 added a 'P' in atype for do procedure references,
            //could have used the 'F'
            //remember only define procedures when they are called!!!
            if !lGotFunction
               func_call(aLine,aType,cOrigLine)
            endif

            // identify the function IF( by comma in program line
            // remember, anything followed is already assumed to be
            // a function, so if we find it's not a function, we
            // make it a command and put back the missing space

            if upper(aLine[nFirstNonComment]) == 'IF' .and. left(aLine[nFirstNonComment+1],1) == '('
               nPointer    := len(aLine)
               nParenCount := 0
               lIfCommand  := .t.
               lGotOne     := .f.   // .t. means we got a command

               if nPointer >= nFirstNonComment+4
                  if '=' $ aType[nFirstNonComment+4]
                     lGotOne := .t.   //this means we got a command
                  endif
               endif

               if !lGotOne
                  for x := nFirstNonComment to nPointer
                     if aType[x] == '+' .or. (aType[x] == 'V' .and. '(' $ aLine[x])
                        nParenCount ++
                        lGotOne := .t.
                     endif
                     if aType[x] == '-' .or. (aType[x] == 'V' .and. ')' $ aLine[x])
                        nParenCount --
                     endif
                     if aLIne[x] == ',' .and. nParenCount == 1
                        lIfCommand := .f.
                        exit
                     endif
                     if nParenCount == 0 .and. lGotOne
                        exit
                     endif
                  next
               endif

               if lIfCommand
                  aType[ nFirstNonComment ] := 'CT'
                  asize(aLine,len(aLine)+1)
                  asize(aType,len(aType)+1)
                  ains(aLine,nFirstNonComment+1)
                  ains(aType,nFirstNonComment+1)
                  aLine[ nFirstNonComment + 1 ] := ' '
                  aType[ nFirstNonComment + 1 ] := 'SP'
               endif

            endif

            if lGotFunction .and. len(aLine) > 2 .and. ;
                       ((upper(left(aLine[1],5)) == 'CLASS' .and. ;
                       upper(left(aLine[3],6)) != 'METHOD') .or. ;
                       (upper(left(aLine[1],6)) == 'CREATE' .and. ;
                       upper(left(aLine[3],5)) == 'CLASS'))
               lGotClass := .t.
            endif

            if lGotClass .and. ;
                       (upper(left(aLine[1],8)) == 'ENDCLASS' .or. ;
                       (len(aLine) > 2 .and. ;
                       upper(left(aLine[1],3)) == 'END' .and. ;
                       upper(left(aLine[3],5)) == 'CLASS'))
               lGotClass := .f.
            endif

            cThisLine := ''
            cComment  := ''
            nLineLen  := len(aLine)
            for y := 1 to nLineLen
               if aType[y] == '//' .and. y > 1
                  cComment := aLine[y]
               else
                  cThisLine += aLine[y]
               endif
            next

            uThisLine := upper(cThisLine)

            nUnFor      := 0
            nUnCase     := 0
            nUnSequence := 0

            if aType[nFirstNonComment] $ 'CT'
               cFirstWord := upper(pad(aLine[nFirstNonComment],4))
               do case
               case cFirstWord == 'ELSE'
                  nUnFor := 1
               case cFirstWord $ 'CASE|OTHE'
                  nUnCase := 1
               case cFirstWord == 'RECO'
                  nUnSequence := 1
               endcase
            endif

            cOutput := space(IndentLevel())+cContSpace+cThisLine

            nUnFor      := 0
            nUnCase     := 0
            nUnSequence := 0

            if !empty(cComment)
               nOutPad  := len(cOutput)
               nOutPad  += nComntTab - (nOutPad % nComntTab)
               cOutput  := pad(cOutput,nOutPad)+cComment
               cComment := ''
            endif

            //most lines get written out here
            if lFuncIndent .and. !lLocIndent
               cTemp := upper(ltrim(cOutput))
               if pad(upper(alltrim(cTemp)),4) $ ;
                           'LOCA|PRIV|MEMV|STAT|PUBL|FIEL'
                  cOutput := ltrim(cOutput)
               endif
               bo_write(oOutHandle,cOutput+oBuffObj1[newline])
               show_out(cOutput)
            else
               bo_write(oOutHandle,cOutput+oBuffObj1[newline])
               show_out(cOutput)
            endif

            if lGotFunction .and. !lRemDupMTLine .and. !ascan(aType,'LC') > 0
               bo_write(oOutHandle,oBuffObj1[newline])
            endif

            if !lLastContinue
               cThisText := upper(aLine[nFirstNonComment])
               do case
               case cThisText == 'IF'
                  do case
                  case left(aLine[nFirstNonComment+1],1) <> '('
                     nIndIf ++
                     aadd(aStack,'IF')
                  case aType[nFirstNonComment] $ 'CT'
                     nIndIf ++
                     aadd(aStack,'IF')
                  endcase

               case lFuncIndent .and. lGotFunction
                  nIndFunc ++
                  aadd(aStack,'FUNC')

               otherwise
                  // do not indent these if they are variables
                  if aType[nFirstNonComment] $ 'CT'
                     do case
                     case left(cThisText,7) == 'DO WHIL'
                        nIndWhile ++
                        aadd(aStack,'WHILE')
                     case left(cThisText,4) == 'WHIL'
                        nIndWhile ++
                        aadd(aStack,'WHILE')
                     case pad(cThisText,4) == 'FOR '
                        nIndFor ++
                        aadd(aStack,'FOR')
                     case left(cThisText,7) == 'DO CASE'
                        nIndCase ++
                        aadd(aStack,'CASE')
                        if lCaseIndent
                           nIndCase ++
                        endif
                     case left(cThisText,4) == 'BEGI'
                        nIndBegin ++
                        aadd(aStack,'BEGIN')
                     endcase
                  endif
               endcase

            endif

            // The smart alignment section of Click!

            if ascan(aType,'LC') > 0
               if !lContSpace
                  cContSpace := ''
                  nLineLen   := len(aLine)
                  do case
                  case upper(aLine[nFirstNonComment]) == 'IF'
                     do case
                     case nLineLen > 6 .and. aLine[7] == '{'
                        cContSpace := space(len(afront(aLine,8)) - 3)
                     case nLineLen > 5 .and. aLine[6] == '{'
                        cContSpace := space(len(afront(aLine,7)) - 3)
                     case nLineLen > 4 .and. aLine[5] == '('
                        if nLineLen > 9 .and. aLine[9] == ':='
                           cContSpace := space(len(afront(aLine,10)) - 3)
                        else
                           cContSpace := space(len(afront(aLine,6)) - 3)
                        endif
                     case nLineLen > 3 .and. aLine[4] == '('
                        if nLineLen > 8 .and. aLine[8] == ':='
                           cContSpace := space(len(afront(aLine,9)) - 3)
                        else
                           cContSpace := space(len(afront(aLine,5)) - 3)
                        endif
                     case nLineLen > 2 .and. aLine[3] == '('
                        if nLineLen > 7 .and. aLine[7] == ':='
                           cContSpace := space(len(afront(aLine,8)) - 3)
                        else
                           cContSpace := space(len(afront(aLine,4)) - 3)
                        endif
                     case nLineLen > 3 .and. aLine[4] == '->' .and. aLine[nFirstNonComment+4] == '('
                        cContSpace := space(len(afront(aLine,nFirstNonComment+5)) - 3)
                     case nLineLen > 1 .and. aLine[2] == '(' .and. aType[nFirstNonComment] $ 'CT'
                        cContSpace := space(len(afront(aLine,nFirstNonComment+3)))
                     case aLine[2] == '('
                        cContSpace := space(len(afront(aLine,3)))
                     otherwise
                        cContSpace := space(nDefIndent)
                     endcase
                  case upper(aLine[1]) == 'DO'
                     cContSpace := space(len(afront(aLine,4)) - 3)
                  case upper(left(aLine[1],4)) == 'WHIL'
                     cContSpace := space(len(afront(aLine,2)) - 3)
                  otherwise
                     do case
                        //3/06 smart aligner not always correctly spacing line continue
                     case llastContinue   //3/06 continue with spacing
                        //no more indent for second/third continue lines
                     case llineContinue   //3/06 a continue line, indent from previous line
                        cContSpace := cContSpace+SPACE(nTabContinue)
                     case nLineLen > 6 .and. aLine[3] == ':=' .and. aLine[7] == '+'
                        cContSpace := space(len(afront(aLine,4)))
                     case (nPointer := ascan(aLine,'{')) > 0
                        if nPointer < nMaxSmartAlign
                           cContSpace := space(len(afront(aLine,nPointer+1)))
                        endif
                     case (nPointer := ascan(aLine,'(')) > 0  //left paren
                        if nPointer < nMaxSmartAlign
                           cContSpace := space(len(afront(aLine,nPointer+1)))
                        endif
                     endcase
                  endcase
                  if len(cContSpace) == 0 .and. !llineContinue  //3/06 stop no additional
                     cContSpace := space(nDefIndent)  //indent on lLineContinue
                  endif   //going to nDefIndent
                  lContSpace := .t.
               endif  //!lContSpace
            else
               cContSpace := ''
               lContSpace := .f.
            endif

         enddo  //done with file (BIG LOOP)  start at ~606

         if lClickEOF

            if !lRemDupMTLine
               bo_write(oOutHandle,oBuffObj1[newline])
            endif
            bo_write(oOutHandle,'*+ EOF: '+cThisFile+oBuffObj1[newline])
            show_out('*+ EOF: '+cThisFile)

         endif

         bo_close(oOutHandle)

         bclose(oBuffObj1)

         if lFuncIndent .and. nIndFunc == 1
            nIndFunc --
         endif

         if IndentLevel() < 0
            cErrorText := 'Control Underflow: Error detected at line '+alltrim(str(nLineCount))
            if lErrNotify
               pop_msg(cErrorText)
            endif
            err_log(cClickLog,cPathFile)
            err_log(cClickLog,cErrorText)
            err_log(cClickLog,'')
         endif

         if IndentLevel() > 0
            cErrorText := 'Control Overflow: Error detected at line '+alltrim(str(nLineCount))
            if lErrNotify
               pop_msg(cErrorText)
            endif
            err_log(cClickLog,cPathFile)
            err_log(cClickLog,cErrorText)
            err_log(cClickLog,'')
         endif

         end_func_text()

         if lTheAligner
            @  6,10 say ;         
             TheAligner('$prealin.tmp',cOutDir+dirsep+RootName(cThisFile)+cOutExt,cClickini)
         endif

         //  03/06 commented out option to set write time of output file
         //         if lRetTimeDate
         //            setfdati( cOutDir + '\' + RootName( cThisFile ) + cOutExt, filedate( cThisFile ), filetime( cThisFile ) )
         //         endif

      endif

      if lastkey() == 27
         exit
      endif

   next   //for xx:=1 to nNumFiles ~line 400 once for each file

   func_text(aLibList,aFileList,cClickini)

end sequence

if lDeclBust
   ferase('$declbst.tmp')
endif

if lTheAligner
   ferase('$prealin.tmp')
endif

lVerbose := .t.

scroll(9,1,nMidScreen - 1,maxcol() - 1)
scroll(nMidScreen+1,1,maxrow() - 3,maxcol() - 1)

show_out('Processed '+alltrim(str(nFileCount))+' files, containing '+alltrim(str(nMasterCount))+' lines of source code')
show_out('')
show_out('Time in process: '+diff2jul(td2jul(),nStartJulian))
show_out('')

err_log(cClickLog,'>>>>>> Click! Run End:   '+dtos(date())+' '+time())
err_log(cClickLog,'')

if lastkey() == 27
   errorlevel(1)
endif

exitproc()
return  //Procedure click
// **************************************************************************




*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function afront()
*+
*+    Called from ( click.prg    )  16 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function afront(aLine,nHowMany)



local cSomeData := ''
local x

nHowMany := min(nHowMany,len(aLine))

if nHowMany > 0
   for x := 1 to nHowMany
      cSomeData += aLine[x]
   next
endif

return cSomeData
// ********************************************************************
// read a line from the buffer and pass it off to the line parser for
// analysis


*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function bReadPart()
*+
*+    Called from ( click.prg    )   3 - procedure click()
*+
*+       Calls    ( obufread.prg )   2 - function beof()
*+                ( obufread.prg )   1 - function blinenumber()
*+                ( obufwrit.prg )   2 - procedure bo_write()
*+                ( obufread.prg )   1 - function breadline()
*+                ( obufread.prg )   1 - function brelative()
*+                ( click.prg    )   1 - function lineparse()
*+                ( click.prg    )   1 - procedure show_in()
*+                ( click.prg    )   2 - procedure show_out()
*+                ( click.prg    )   5 - function tabspstrip()
*+                ( click.prg    )   1 - function tabstrip()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function bReadPart(oBuffObj1)



local aLineParts := {}
local aLeftLine  := {}
local aLeftType  := {}

local cComment
local cThisLine

local nNumParts
local nNumDivs
local x
local nLBPointer
local nNumTaken
local lClickIgnore := .f.
local nOldPcntDone
local nPcntDone    := 0

static aLine     := {}
static aType     := {}
static cLineBuff := ''

if lDumpBuffer
   aLine       := {}
   aType       := {}
   cLineBuff   := ''
   lDumpBuffer := .f.
endif

if empty(aLine)

   do while .t.

      if nStripComment > 0
         cLineBuff     := substr(cLineBuff,nStripComment)
         nStripComment := 0
      else
         cLineBuff := bReadLine(oBuffObj1)
         @  6,67 say str(bLineNumber(oBuffObj1),8)         
         show_in(cLineBuff)
         nLineCount ++
         nMasterCount ++

         nOldPcntDone := nPcntDone
         nPcntDone    := int(bRelative(oBuffObj1) * 50)
         if nOldPcntDone <> nPcntDone
            @  6,14 say replicate('',nPcntDone) color 'GB+/B'        
         endif

         if upper(TabSpStrip(cLineBuff)) == '*+CLICKOFF' .or. ;
                            upper(TabSpStrip(cLineBuff)) == 'TEXT'
            lClickIgnore := .t.
         endif
         if lClickIgnore
            bo_write(oOutHandle,cLineBuff+oBuffObj1[newline])
            show_out(cLineBuff)
            if upper(TabSpStrip(cLineBuff)) == '*+CLICKON' .or. ;
                               upper(TabSpStrip(cLineBuff)) == 'ENDTEXT' .or. ;
                               bEof(oBuffObj1)
               lClickIgnore := .f.
            endif
            loop
         endif
      endif

      cLineBuff := tabstrip(cLineBuff)

      if lCommentMode .and. !('*/' $ cLineBuff) .and. !bEof(oBuffObj1)
         bo_write(oOutHandle,cLineBuff+oBuffObj1[newline])
         show_out(cLineBuff)
         loop
      else
         exit
      endif

   enddo

   cThisLine := alltrim(cLineBuff)

   // waste any remaining tabs or spaces on the left of the line
   cThisLine := TabSpStrip(cThisLine)

   if left(cThisLine,1) == '*'
      aLine := {cThisLine}
      aType := {'  //'}
   else
      aLineParts := lineparse(cThisLine)
      aLine      := aLineParts[1]
      aType      := alineParts[2]
   endif

endif

// Is this a multipart command with a comment?
// If so, comment goes in second position

// if this is the beginning of a strikeout section, comment stays on end

nNumParts  := len(aLine)
nNumDivs   := 0
nLBPointer := 0
for x := 1 to nNumParts
   if aType[x] == 'LB'
      if empty(nLBPointer)
         // this grabs an array pointer to the last item before the LB
         nLBPointer := x - 1
      endif
      nNumDivs ++
   endif
next

if nNumDivs > 0

   cComment := ''
   if atail(aType) == '//'
      // remove the comment to be appended to first element
      cComment := aLine[len(aLine)]
      asize(aLine,len(aLine) - 2)
      asize(aType,len(aType) - 2)
   endif

   aLeftLine := {}
   aLeftType := {}
   for x := 1 to nLBPointer
      aadd(aLeftLine,aLine[x])
      aadd(aLeftType,aType[x])
   next

   nNumTaken := len(aLeftLine)+2  // toss the data, LB and space
   for x := 1 to nNumTaken
      adel(aLine,1)
      adel(aType,1)
   next
   asize(aLine,len(aLine) - nNumTaken)
   asize(aType,len(aType) - nNumTaken)

   // if we grabbed a comment off of the end of the line,
   // we append it to the first line element

   if !empty(cComment)
      aadd(aLeftLine,' ')
      aadd(aLeftType,'SP')
      aadd(aLeftLine,cComment)
      aadd(aLeftType,'//')
   endif

   lMoreToGo := .t.

else
   aLeftLine := aLine
   aLeftType := aType
   aLine     := {}
   aType     := {}
   lMoreToGo := .f.
endif
return {aLeftLine,aLeftType,cLineBuff}  //function bReadPart
// ********************************************************************



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure centertext()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   3 - static procedure main_screen()
*+                ( functrak.prg )   5 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure centertext(cSomeText,nLineNumber,cColor)


@ nLineNumber,(maxcol() - len(cSomeText)) / 2 say cSomeText color cColor        
return
// *************************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Init Procedure CLIPINIT()
*+
*+       Calls    ( unresolved   )   1 - function __Quit()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
init procedure CLIPINIT


errorblock({| e | fwrite(2,chr(13)+chr(10)+'ERROR '+;
 e:subsystem+':'+ltrim(str(e:subcode))),__Quit()})
return
// **********************************************************************



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function dbc_identify()
*+
*+    Called from ( click.prg    )   1 - static procedure thealigner()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function dbc_identify(aType)



local logic := .t.

if len(aType) >= 20

   do case
   case aType[1] != 'V'
      logic := .f.
   case aType[3] != 'O'
      logic := .f.
   case aType[5] != '+'
      logic := .f.
   case aType[7] != '+'
      logic := .f.
   case aType[9] != 'S'
      logic := .f.
   case aType[12] != 'S'
      logic := .f.
   case aType[15] != 'V'
      logic := .f.
   case aType[18] != 'V'
      logic := .f.
   case aType[20] != '-'
      logic := .f.
   endcase
else
   logic := .f.
endif

return logic
// ******************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure ERRORSYS()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure ERRORSYS()



return
// ***********************************************************************



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Procedure exitproc()
*+
*+    Called from ( click.prg    )   8 - procedure click()
*+
*+       Calls    ( prb_stak.prg )   1 - procedure getscreen()
*+                ( click.prg    )   2 - procedure show_out()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static procedure exitproc()



if lRestScrn
   show_out('  Press any Key to End Click!  ','GR+/R')
   show_out('')
   inkey(0)
   getscreen()
else
   devpos(maxrow() - 2,0)
endif

return
// *******************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function func_head()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( functrak.prg )   1 - procedure functrak()
*+                ( click.prg    )   6 - procedure show_out()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function func_head(aLine,oBuffObj1)



local cDataOut := ''

local nWordLen
local cThisWord
local cFuncChars := ''

local lFunc := .f.
local lProc := .f.
local lClas := .f.
local lMeth := .f.

local lStat := .f.
local lInit := .f.
local lExit := .f.

if len(aLine) > 2
   cThisWord := upper(aLine[1])
   if len(cThisWord) < 4
      cThisWord := pad(cThisWord,4)
   endif
   nWordLen := len(cThisWord)

   if left('FUNCTION',nWordLen) == cThisWord
      lFunc := .t.
   elseif left('PROCEDURE',nWordLen) == cThisWord
      lProc := .t.
   elseif left('METHOD',nWordLen) == cThisWord .and. ':' $ aLine[3]
      lMeth := .t.
   elseif left('CLASS',nWordLen) == cThisWord
      lClas := .t.
   elseif left('CREATE',nWordLen) == cThisWord
      lClas := .t.
   endif

endif

if (!lFunc .or. !lProc .or. !lMeth) .and. len(aLine) > 4
   cThisWord := upper(aLine[1])
   if len(cThisWord) < 4
      cThisWord := pad(cThisWord,4)
   endif
   nWordLen := len(cThisWord)

   if left('STATIC',nWordLen) == cThisWord
      lStat := .t.
   endif

   if left('INIT',nWordLen) == cThisWord
      lInit := .t.
   endif

   if left('EXIT',nWordLen) == cThisWord
      lExit := .t.
   endif

   if lStat .or. lInit .or. lExit

      cThisWord := upper(aLine[3])
      if len(cThisWord) < 4
         cThisWord := pad(cThisWord,4)
      endif
      nWordLen := len(cThisWord)

      if left('FUNCTION',nWordLen) == cThisWord
         lFunc := .t.
      elseif left('PROCEDURE',nWordLen) == cThisWord
         lProc := .t.
      elseif left('METHOD',nWordLen) == cThisWord .and. ':' $ aLine[3]
         lMeth := .t.
      elseif left('CLASS',nWordLen) == cThisWord
         lClas := .t.
      else
         lStat := .f.
      endif

   endif

endif

if lStat .or. lInit .or. lExit .or. lFunc .or. lProc .or. lMeth .or. lClas
   if !lRemDupMTLine
      cDataOut += oBuffObj1[newline]
   endif
   cDataOut += '*+'+replicate(cFuncDiv,68)+oBuffObj1[newline]
   show_out('*+'+replicate(cFuncDiv,68))
   cDataOut += '*+'+oBuffObj1[newline]
   show_out('*+')

   do case
   case lStat .and. lFunc
      cFuncChars := '*+'+space(4)+'Static Function '+aLine[5]+'()'
   case lStat .and. lProc
      cFuncChars := '*+'+space(4)+'Static Procedure '+aLine[5]+'()'
   case lStat .and. lMeth
      cFuncChars := '*+'+space(4)+'Static Method '+aLine[5]+'()'

   case lInit .and. lFunc
      cFuncChars := '*+'+space(4)+'Init Function '+aLine[5]+'()'
   case lInit .and. lProc
      cFuncChars := '*+'+space(4)+'Init Procedure '+aLine[5]+'()'
   case lInit .and. lMeth
      cFuncChars := '*+'+space(4)+'Init Method '+aLine[5]+'()'

   case lExit .and. lFunc
      cFuncChars := '*+'+space(4)+'Exit Function '+aLine[5]+'()'
   case lExit .and. lProc
      cFuncChars := '*+'+space(4)+'Exit Procedure '+aLine[5]+'()'
   case lExit .and. lMeth
      cFuncChars := '*+'+space(4)+'Exit Method '+aLine[5]+'()'

   case lFunc
      cFuncChars := '*+'+space(4)+'Function '+aLine[3]+'()'
   case lProc
      cFuncChars := '*+'+space(4)+'Procedure '+aLine[3]+'()'
   case lMeth
      cFuncChars := '*+'+space(4)+'Method '+aLine[3]+'()'

   case lClas .and. upper(aLine[3]) == 'METHOD'
      cFuncChars := '*+'+space(4)+'Class Method '+aLine[5]+'()'
   case lClas .and. upper(aLine[1]) == 'CREATE' .and. upper(aLine[3]) == 'CLASS'
      cFuncChars := '*+'+space(4)+'Create Class '+aLine[5]+'()'
   case lClas
      cFuncChars := '*+'+space(4)+'Class '+aLine[3]

   endcase

   cDataOut += cFuncChars+oBuffObj1[newline]
   show_out(cFuncChars)

   functrak(substr(cFuncChars,7))

   cDataOut += '*+'+oBuffObj1[newline]
   show_out('*+')
   cDataOut += '*+'+replicate(cFuncDiv,68)+oBuffObj1[newline]
   show_out('*+'+replicate(cFuncDiv,68))
   cDataOut += '*+'+oBuffObj1[newline]
   show_out('*+')

endif

return cDataOut
// eof func_head()
// *******************************************************************




*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function IndentLevel()
*+
*+    Called from ( click.prg    )   7 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function IndentLevel()



return ;
 (nTabIf * nIndIf)+;
 (nTabFor * (nIndFor - nUnFor))+;
 (nTabCase * (nIndCase - nUnCase))+;
 (nTabFunc * nIndFunc)+;
 (nTabBegin * (nIndBegin - nUnSequence))+;
 (nTabWhile * nIndWhile)
// *********************************************************************




*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Procedure IndentReset()
*+
*+    Called from ( click.prg    )   4 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static procedure IndentReset()



nIndIf      := 0
nIndFor     := 0
nIndCase    := 0
nIndFunc    := 0
nIndBegin   := 0
nIndWhile   := 0
nUnFor      := 0
nUnCase     := 0
nUnSequence := 0
return
// *********************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function leadspace()
*+
*+    Called from ( click.prg    )   8 - static procedure thealigner()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function leadspace(aString)



local x
local nStrLength := len(aString)

for x := 1 to nStrLength
   if substr(aString,x,1) != ' '
      x --
      exit
   endif
next

if x > nStrLength
   x := nStrLength
endif
return x
// *******************************************************************



// take a line of code and break it down into parts, return an array with
// parts (aline) and type of entry (atype) separated by 'SP' type entries
// FF=function  LB=line continuation (;)  LC=line continuation (;)
// //=comment  CT=comment (*)  /* and  */=more comment type
// C=in cmd_list()  M=macro N=number  0=various operator and separator pairs
// OP=matches click.ini cop_list   SP=space U=??  V=assign value(=)
// W=word which can update to C if in cmd_list becomes CT if not considered a function
// or FF if in click.ini function list,
// otherwise it ends up a V  F=functions  P=procedures for sorting
// U=?? but gets updated to LB,+,-,or OP if op_list



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function lineparse()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static function breadpart()
*+                                   7 - static procedure thealigner()
*+                ( declbust.prg )   3 - procedure declbust()
*+
*+       Calls    ( cmd_list.prg )   2 - function cmd_list()
*+                ( cmd_list.prg )   2 - function fnc_list()
*+                ( token.prg    )   1 - function numtoken()
*+                ( cmd_list.prg )   1 - function op_list()
*+                ( prb_prop.prg )   4 - function proper()
*+                ( token.prg    )   1 - function numtoken()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function lineparse(cThisLine)



local lQuoteMode  := .f.
local lWordMode   := .f.
local lAction     := .f.
local lBrackMode  := .f.
local aLine       := {}
local aTemp1      := {}
local aTemp2      := {}
local aType       := {}
local cThisChar
local uThisChar
local cThisPair
local cWord
local cQuoteChar
local cLookFor
local cTheString  := ''
local cThisWord   := ''
local wordchars
local cRestOfline := ''
local nElements
local nPointer    := 0
local nLineLen    := len(cThisLine)
local x
local xx
local nX
local cLeft
local cRight
local uThisLine   := upper(cThisLine)
local lShortCut
local nParenLevel
local nStartElem

static cTab := chr(K_TAB)


begin sequence

   if left(cThisLine,1) == '*' .or. lCommentMode
      aLine := {cThisLine}
      aType := {'  //'}
      break
   endif

   if left(cThisLine,2) $ '//|&&'
      aLine := {cThisLine}
      aType := {'  //'}
      break
   endif

   if left(cThisLine,1) == '#'
      aLine := {cThisLine}
      aType := {'#'}
      break
   endif

   lShortCut := .f.
   do case
   case left(uThisLIne,4) == 'USE '
      lShortCut := .t.
   case left(uThisLIne,5) == 'COPY '
      lShortCut := .t.
   case left(uThisLIne,5) == 'SAVE '
      lShortCut := .t.
   case left(uThisLIne,6) == 'ERASE '
      lShortCut := .t.
   case left(uThisLIne,7) == 'CREATE '
      lShortCut := .t.
   case left(uThisLine,8) == 'COPY TO '
      lShortCut := .t.
   case left(uThisLine,8) == 'RESTORE '
      lShortCut := .t.
   case left(uThisLine,8) == 'SET COLO'
      lShortCut := .t.
   case left(uThisLine,8) == 'SET ORDE'
      lShortCut := .t.
   case left(uThisLine,10) == 'COPY FILE '
      lShortCut := .t.
   case left(uThisLine,11) == 'DELETE FILE'
      lShortCut := .t.
   endcase
   if lShortCut
      nX := numtoken(cThisLine,' ')
      for x := 1 to nX
         aadd(aLine,token(cThisLine,' ',x))
         aadd(aType,'V')
         if x < nX
            aadd(aLine,' ')
            aadd(aType,'V')
         endif
      next

      nX := len(aLine)

      for x := 1 to nX

         do case
         case cmd_list(aLine[x],@nPointer)
            aType[ x ] := 'C'   //doesn't have * as first character
            if aCmdLogic[nPointer]  //has an * as first character
               aType[ x ] := 'CT'
            endif
            do case
            case cComCase == 'UPPER'
               aLine[ x ] := upper(aLine[x])
            case cComCase == 'LOWER'
               aLine[ x ] := lower(aLine[x])
            case cComCase == 'PROPER'
               aLine[ x ] := proper(aLine[x])
            case cComCase == 'LIKEINFILE'
               aLine[ x ] := trim(aCommand[nPointer])
            endcase
         case fnc_list(aLine[x],@nPointer)
            aType[ x ] := 'FF'
            // fix 13Dec'98 (DJW): case below was using cComCase instead of cFunCase
            do case
            case cFunCase == 'UPPER'
               aLine[ x ] := upper(aLine[x])
            case cFunCase == 'LOWER'
               aLine[ x ] := lower(aLine[x])
            case cFunCase == 'PROPER'
               aLine[ x ] := proper(aLine[x])
            case cFunCase == 'LIKEINFILE'
               aLine[ x ] := trim(aFunction[nPointer])
            endcase
         case aLine[x] == ';'
            aType[ x ] := 'LC'
         otherwise
            aType[ x ] := 'V'
         endcase
      next
      break
   endif

   for x := 1 to nLineLen
      cThisChar := substr(cThisLine,x,1)
      uThisChar := upper(cThisChar)
      // padding added to eliminate recognition of single :
      cThisPair := pad(substr(cThisLine,x,2),2)

      if cThisPair $ '&&|:='
         wordchars := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890._\'
      else
         wordchars := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890._\&:'
      endif

      // This is the beginning of a quote
      if !lQuoteMode .and. (cThisChar == '"' .or. cThisChar == "'" .or. (lBrackMode .and. cThisChar == '['))
         // If we are in word mode and find the start of a quote
         // save the word and end word mode, then start quote mode.
         if lWordMode
            aadd(aLine,cThisWord)
            aadd(aType,'W')
            lWordMode := .f.
            cThisWord := ''
         endif
         if (lBrackMode .and. cThisChar == '[')
            cQuoteChar := ']'
            cTheString := '['
         else
            cQuoteChar := cThisChar
            cTheString := cThisChar
         endif
         lQuoteMode := .t.
         loop
      endif

      // This is the end of a quote
      if lQuoteMode .and. cThisChar == cQuoteChar
         cTheString += cThisChar
         aadd(aLine,cTheString)
         aadd(aType,'S')  // String
         cTheString := ''
         lQuoteMode := .f.
         loop
      endif

      // if we are in quote mode, just gather the characters
      if lQuoteMode
         cTheString += cThisChar
         loop
      endif

      // this is the beginning of a word
      if !lWordMode .and. uThisChar $ wordchars
         lWordMode := .t.
         if x == nLineLen
            aadd(aLine,cThisChar)
            aadd(aType,'W')   // Word
         else
            cThisWord := cThisChar
         endif
         lBrackMode := .f.
         loop
      endif

      // This is the end of a word
      if lWordMode .and. (!(uThisChar $ wordchars) .or. x == nLineLen)
         if x == nLineLen .and. uThisChar $ wordchars
            aadd(aLine,cThisWord+cThisChar)
            aadd(aType,'W')
            exit
         else
            aadd(aLine,cThisWord)
            aadd(aType,'W')
         endif
         lWordMode := .f.
         cThisWord := ''
      endif

      // if we are in word mode, just gather the characters
      if lWordMode
         cThisWord += cThisChar
         loop
      endif

      do case
      case cThisPair == '/*'
         cRestOfLine := substr(cThisLine,x)
         if (npointer := at('*/',cRestOfLine)) > 0
            aadd(aLine,left(cRestOfLine,nPointer+1))
            aadd(aType,'/**/')
            x += nPointer
         else
            aadd(aLine,cRestOfLine)
            aadd(aType,'/*')
            exit
         endif
      case cThisPair == '//' .or. cThisPair == '&&'
         if lConvertSlash
            aadd(aLine,'//'+substr(cThisLine,x+2))
         else
            aadd(aLine,substr(cThisLine,x))
         endif
         aadd(aType,'//')
         exit
      case cThisPair == '*/'
         aadd(aLine,'*/')
         aadd(aType,'*/')
         x ++
      case cThisPair == '()'
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisPair == '{}'
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisPair == '<>'
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisPair == '<='
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisPair == '>='
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisPair == '->'
         aadd(aLine,cThisPair)
         aadd(aType,'O')
         x ++
      case cThisChar $ '-+/*=?|:' .and. atail(aLine) == cThisChar
         aLine[len(aLine)] += cThisChar
      case cThisChar == '=' .and. !empty(aLine) .and. atail(aLine) $ '+-/*^:'
         aLine[len(aLine)] += cThisChar
      case cThisChar $ '-+/*=?|:'
         aadd(aLine,cThisChar)
         aadd(aType,'O')  // Operator
      case cThisChar == '&'
         aadd(aLine,cThisChar)
         aadd(aType,'M')  // Macro
      case cThisChar == '\'   //this is not a file slash in linux??
         aadd(aLine,cThisChar)  //might be a problem somewhere??
         aadd(aType,'\')  // File Slash
      case cThisChar == cTab
         aadd(aLine,' ')  // Convert Tab to Space for stripping.
         aadd(aType,'SP')   //a space type
      otherwise
         aadd(aLine,cThisChar)
         aadd(aType,'U')
      endcase

      if cThisChar $ '-+/*=?|:(,'
         lBrackMode := .t.
      endif

   next

   nElements := len(aLine)

   if nElements > 0

      if '.AND.' $ uThisLine

         // check for .and. boolean command imbedded in words

         for x := 1 to nElements
            if aType[x] == 'W' .and. len(aLine[x]) > 5
               do while len(aLine[x]) > 5 .and. (nPointer := at('.AND.',upper(aLine[x]))) > 0

                  cLeft  := left(aLine[x],nPointer - 1)
                  cRight := substr(aLine[x],nPointer+5)

                  if !empty(cLeft)
                     nElements ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cLeft
                     aType[ x ] := 'W'
                     x ++
                  endif

                  aLine[ x ] := substr(aLine[x],nPointer,5)
                  aType[ x ] := 'W'   // to be identified later...

                  if !empty(cRight)
                     nElements ++
                     x ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cRight
                     aType[ x ] := 'W'
                  endif

               enddo
            endif
         next

      endif

      // check for .or. boolean command imbedded in words

      if '.OR.' $ uThisLine

         nElements := len(aLine)
         for x := 1 to nElements
            if aType[x] == 'W' .and. len(aLine[x]) > 4
               do while len(aLine[x]) > 4 .and. (nPointer := at('.OR.',upper(aLine[x]))) > 0

                  cLeft  := left(aLine[x],nPointer - 1)
                  cRight := substr(aLine[x],nPointer+4)

                  if !empty(cLeft)
                     nElements ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cLeft
                     aType[ x ] := 'W'
                     x ++
                  endif

                  aLine[ x ] := substr(aLine[x],nPointer,4)
                  aType[ x ] := 'W'   // to be identified later...

                  if !empty(cRight)
                     nElements ++
                     x ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cRight
                     aType[ x ] := 'W'
                  endif

               enddo
            endif
         next
      endif

      // check for .not. boolean command imbedded in words

      if '.NOT.' $ uThisLine

         nElements := len(aLine)
         for x := 1 to nElements
            if aType[x] == 'W' .and. len(aLine[x]) > 5
               do while len(aLine[x]) > 5 .and. (nPointer := at('.NOT.',upper(aLine[x]))) > 0

                  cLeft  := left(aLine[x],nPointer - 1)
                  cRight := substr(aLine[x],nPointer+5)

                  if !empty(cLeft)
                     nElements ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cLeft
                     aType[ x ] := 'W'
                     x ++
                  endif

                  aLine[ x ] := substr(aLine[x],nPointer,5)
                  aType[ x ] := 'W'   // to be identified later...

                  if !empty(cRight)
                     nElements ++
                     x ++
                     asize(aLine,nElements)
                     asize(aType,nElements)
                     ains(aLine,x)
                     ains(aType,x)
                     aLine[ x ] := cRight
                     aType[ x ] := 'W'
                  endif

               enddo
            endif
         next

      endif

      // Kill off the space elements in the array

      nElements := len(aLine)
      aTemp1    := {}
      aTemp2    := {}
      for x := 1 to nElements
         if aLine[x] != ' '
            aadd(aTemp1,aLine[x])
            aadd(aTemp2,aType[x])
         endif
      next

      // combine two word commands

      nElements := len(aTemp1) - 1
      for x := 1 to nElements

         cWord := upper(aTemp1[x])

         if '|'+cWord+'|' $ '|DO|BEGIN|END|SET|CLEAR|COPY STRU|APPEND|LABEL|REPORT|CREATE|DELETE|MENU|RESTORE|SAVE|'

            lAction  := .f.
            cLookFor := upper(pad(aTemp1[x+1],4))

            do case
            case cWord == 'DO' .and. cLookFor $ 'WHIL|CASE'   //move lookfor up here 3/06
               lAction := .t.   //3/06 make all other do follow a procedure
            case cWord == 'DO' .and. x = 1 .and. len(aTemp2) > 1
               aTemp2[ 2 ] := 'P'   //3/06 add DO P(rocedure) type
            case cWord == 'SET' .and. x = 1 .and. atemp1[2] = 'KEY' .and. Len(atemp2) > 4
               IF atemp2[5] == 'W'  //test that it isn't a comment
                  atemp2[5] = 'P'   //3/06 add SET KEY procedure tracking
               ENDIF
            case cWord == 'BEGIN'
               lAction := cLookFor $ 'SEQU'
            case cWord == 'END'
               lAction := cLookFor $ 'CASE|DO  |IF  |SEQU|WHIL'
            case cWord == 'SET'   //3/06 added EVENTMASK
               lAction := cLookFor $ 'ALTE|BELL|CENT|COLO|CONF|CONS|CURS|DATE|DECI|DEFA|DELE|DELI|DEVI|EPOC|ESCA|EVEN|EXAC|EXCL|FILT|FIXE|FORM|FUNC|INDE|INTE|KEY |MARG|MESS|ORDE|PATH|PRIN|PROC|RELA|SCOR|SOFT|TYPE|UNIQ|WRAP'
            case cWord == 'CLASS'
               lAction := cLookFor $ 'METH|VAR '
            case cWord == 'CLEAR'
               lAction := cLookFor $ 'ALL |GETS|MEMO|SCRE|TYPE'
            case cWord == 'COPY'
               lAction := cLookFor $ 'FILE|STRU|TO  '
            case pad(cWord,9) == 'COPY STRU'
               lAction := cLookFor == 'EXTE'
            case cWord == 'APPEND'
               lAction := cLookFor $ 'BLAN|FROM'
            case cWord == 'LABEL'
               lAction := cLookFor == 'FORM'
            case cWord == 'REPORT'
               lAction := cLookFor == 'FORM'
            case cWord == 'CREATE'
               lAction := cLookFor == 'FROM'
            case cWord == 'DELETE'
               lAction := cLookFor == 'FILE'
            case cWord == 'MENU'
               lAction := cLookFor == 'TO  '
            case cWord == 'RESTORE'
               lAction := cLookFor == 'SCRE'
            case cWord == 'SAVE'
               lAction := cLookFor == 'SCRE'
            endcase
            if lAction
               aTemp1[x] += ' '+aTemp1[x+1]
               adel(aTemp1,x+1)
               adel(aTemp2,x+1)
               asize(aTemp1,nElements)
               asize(aTemp2,nElements)
               nElements --
               aTemp2[ x ] := 'W'
            endif

         endif

      next

      // Now, put a space element in every other position

      nElements := len(aTemp1)
      aLine     := {}
      aType     := {}

      for x := 1 to nElements
         aadd(aLine,aTemp1[x])
         aadd(aType,aTemp2[x])
         if x < nElements
            aadd(aLine,' ')
            aadd(aType,'SP')
         endif
      next

      // identify the 'W' and 'U' elements

      nElements := len(aLine)

      nParenLevel := 0

      for x := 1 to nElements

         do case
         case aType[x] = 'P'
            //leave it as set 3/06 adding do procedures
         case aType[x] == 'W'
            do case
            case val(aLine[x]) > 0
               aType[ x ] := 'N'
            case upper(aLine[x]) $ '.AND.|.OR.|.NOT.' .and. ;
                left(aLine[x],1) == '.' .and. ;
                right(aLine[x],1) == '.'

               aType[ x ] := 'BOOL'
               do case
               case cBoolCase == 'UPPER'
                  aLine[ x ] := upper(aLine[x])
               case cBoolCase == 'LOWER'
                  aLine[ x ] := lower(aLine[x])
               endcase

            case nParenLevel == 0 .and. cmd_list(aLine[x],@nPointer)
               aType[ x ] := 'C'
               if aCmdLogic[nPointer]
                  aType[ x ] := 'CT'
               endif
               do case
               case cComCase == 'UPPER'
                  aLine[ x ] := upper(aLine[x])
               case cComCase == 'LOWER'
                  aLine[ x ] := lower(aLine[x])
               case cComCase == 'PROPER'
                  aLine[ x ] := proper(aLine[x])
               case cComCase == 'LIKEINFILE'
                  aLine[ x ] := trim(aCommand[nPointer])
               endcase

            case nElements > x+1 .and. left(aLine[x+2],1) == '(' .and. fnc_list(aLine[x],@nPointer)
               aType[ x ] := 'FF'
               // fix 13Dec'98 (DJW): case below was using cComCase instead of cFunCase
               do case
               case cFunCase == 'UPPER'
                  aLine[ x ] := upper(aLine[x])
               case cFunCase == 'LOWER'
                  aLine[ x ] := lower(aLine[x])
               case cFunCase == 'PROPER'
                  aLine[ x ] := proper(aLine[x])
               case cFunCase == 'LIKEINFILE'
                  aLine[ x ] := trim(aFunction[nPointer])
               endcase

            otherwise
               aType[ x ] := 'V'

            endcase

         case aType[x] == 'U'

            do case
            case aLine[x] == ';'
               aType[ x ] := 'LB'

            case aLine[x] $ '({['
               aType[ x ] := '+'
               nParenLevel ++

            case aLine[x] $ ')}]'
               aType[ x ] := '-'
               nParenLevel --

            case op_list(aLine[x])
               aType[ x ] := 'OP'

            endcase
         endcase
      next

      //commented this out 3/06 as it was adding a bunch of IF functions to altd()
      //afunclist{} in func_call(), suspect this removal will cause trouble in code
      //the if function/command/operator
      //      if nElements > 0 .and. upper( aLine[ 1 ] ) == 'IF'
      //        aType[ 1 ] := 'F'  //first element of line
      //      endif

      // Identify SET( as a function

      if upper(aLine[1]) == 'SET'
         if len(aLine) > 2
            if aLine[3] == '('
               aType[ 1 ] := 'FF'
            endif
         endif
      endif

      // throw away spaces after functions and before parenthesis or brackets

      nElements := len(aLine) - 1

      for x := 2 to nElements

         if upper(aLine[x]) == 'IF'   // any IF after the first element is a function!
            aType[ x ] := 'FF'
         endif

         if aLine[x] == ' ' .and. ;
                    left(aLine[x+1],1) $ '([' .and. ;
                    aType[x - 1] $ 'FFVC'

            if left(aLine[x+1],1) == '('
               if aType[x - 1] <> 'FF'
                  aType[ x - 1 ] := 'F'
               endif
            endif
            adel(aLine,x)
            adel(aType,x)
            asize(aLine,nElements)
            asize(aType,nElements)
            nElements --
            x --
         endif

      next

      // throw away spaces after macro's

      nElements := len(aLine) - 1

      for x := 2 to nElements
         if aLine[x] == ' ' .and. aType[x - 1] == 'M'
            adel(aLine,x)
            adel(aType,x)
            asize(aLine,nElements)
            asize(aType,nElements)
            nElements --
            x --
         endif
      next

      // throw away spaces before commas

      nElements := len(aLine) - 1

      for x := 1 to nElements
         if aLine[x] == ' ' .and. aLine[x+1] == ','
            adel(aLine,x)
            adel(aType,x)
            asize(aLine,nElements)
            asize(aType,nElements)
            nElements --
         endif
      next

      // throw away spaces after ! and @ except:
      //    a. When first element on line starts with !=,
      //    b. When the line starts with @ and lLastContinue

      if (aLine[1] == '!' .and. aLine[3] == '=') .or. ;
               (aLine[1] == '@' .and. lLastContinue)
         nStartElem := 1
      else
         nStartElem := 2
      endif

      nElements := len(aLine) - 1

      for x := nStartElem to nElements
         if (left(aLine[x],1) $ '!@' .or. aLine[x] == '::') .and. ;
                       left(aLine[x+1],1) == ' '
            adel(aLine,x+1)
            adel(aType,x+1)
            asize(aLine,nElements)
            asize(aType,nElements)
            nElements --
         endif
      next

      // throw away spaces on both sides of -> and : and \
      // Make into a single element...

      nElements := len(aLine) - 2

      for x := 3 to nElements
         if aLine[x] == '->' .or. aLine[x] $ ':\'
            aLine[x - 2] += aLine[x]+aLine[x+2]
            aType[ x - 2 ] := 'V'
            for xx := 1 to 4
               adel(aLine,x - 1)
               adel(aType,x - 1)
            next
            nElements -= 4
            asize(aLine,nElements+2)
            asize(aType,nElements+2)
         endif
      next

      // Identify line breaks and line continuations

      nElements := len(aLine)

      for x := 1 to nElements
         if aType[x] == 'LB'
            // if a ; (linebreak) is in the last position,
            // it ALWAYS means that the line is continued.
            if x == nElements
               aType[ x ] := 'LC'
            endif
            if x == nElements - 2
               if left(atail(aType),1) == '/'
                  aType[ x ] := 'LC'
               endif
            endif
         endif
      next

      if len(aLine) > 2 .and. aLine[1] == '@' .and. aLine[2] == ' ' .and. left(aLine[3],1) == ':'
         adel(aLine,2)
         adel(aType,2)
         asize(aLine,len(aLine) - 1)
         asize(aType,len(aType) - 1)
      endif

      if lMode5   // this is 5.x specific stuff

         // throw away spaces after >)}] and before : // oo stuff

         nElements := len(aLine) - 2

         for x := 1 to nElements

            if aType[x] $ 'O-' .and. ;
                       aType[x+1] == 'SP' .and. ;
                       aType[x+2] $ 'F' .and. ;
                       left(aLine[x+2],1) == ':'

               adel(aLine,x+1)
               adel(aType,x+1)

               asize(aLine,nElements+1)
               asize(aType,nElements+1)

               nElements --

            endif
         next

         // throw away spaces between ] [

         nElements := len(aLine) - 2

         for x := 1 to nElements

            if aLine[x] == ']' .and. ;
                       aType[x+1] == 'SP' .and. ;
                       aLine[x+2] = '['

               if lConvertArray

                  aLine[ x ] := ', '+substr(aLine[x+2],2)

                  adel(aLine,x+1)
                  adel(aType,x+1)

                  adel(aLine,x+1)
                  adel(aType,x+1)

                  asize(aLine,nElements)
                  asize(aType,nElements)

                  nElements -= 2
               else
                  adel(aLine,x+1)
                  adel(aType,x+1)

                  asize(aLine,nElements+1)
                  asize(aType,nElements+1)

                  nElements --
               endif

            endif
         next

         // See if this is an assignment beyond position 3 but not
         // surrounded by parenthetic levels  like:
         // x[ 4 ] := .t.  // := in position 8

         if !(left(aType[1],1) $ 'CF')

            nParenLevel := 0
            nElements   := len(aLine)
            for x := 1 to nElements

               do case
               case aType[x] == '+'
                  nParenLevel ++
               case aType[x] == '-'
                  nParenLevel --
               endcase

               if nParenLevel == 0 .and. aLine[x] == ':='

                  // incorporate all 2 thru x-2 elements into element 1
                  // and delete the combined pieces
                  // resize the array appropriately

                  aType[ 1 ] := 'V'
                  for xx := 2 to x - 2
                     aLine[1] += aLine[xx]
                  next
                  for xx := 2 to x - 2
                     adel(aLine,2)
                     adel(aType,2)
                     nElements --
                  next
                  asize(aLine,nElements)
                  asize(aType,nElements)

                  exit

               endif

            next

         endif

         // if there is an = in position 3, it must be an assignment!
         // unless it is a continued line

         if !lLineContinue

            if len(aLine) > 2
               if aLine[3] == '='
                  aLine[ 3 ] := ':='
                  aType[ 1 ] := 'V'
               endif
            endif

            // also, the = in a for next is an assignment

            if len(aLine) > 10
               if aLine[5] == '=' .and. upper(aLine[1]) == 'FOR'
                  aLine[ 5 ] := ':='
                  aType[ 3 ] := 'V'
               endif
            endif

         endif


         // If deflate1 is on, throw away spaces after ( and before )
         if lDeflate1
            nElements := len(aLine) - 1
            for x := 1 to nElements
               if right(aLine[x],1) == '(' .and. ;
                             aType[x+1] == 'SP'
                  adel(aLine,x+1)
                  adel(aType,x+1)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
            for x := 1 to nElements
               if left(aLine[x+1],1) == ')' .and. ;
                            aType[x] == 'SP'
                  adel(aLine,x)
                  adel(aType,x)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
         endif

         // If deflate2 is on, throw away spaces after [ and before ]
         if lDeflate2
            nElements := len(aLine) - 1
            for x := 1 to nElements
               if right(aLine[x],1) == '[' .and. ;
                             aType[x+1] == 'SP'
                  adel(aLine,x+1)
                  adel(aType,x+1)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
            for x := 1 to nElements
               if left(aLine[x+1],1) == ']' .and. ;
                            aType[x] == 'SP'
                  adel(aLine,x)
                  adel(aType,x)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
         endif

         // If deflate3 is on, throw away spaces after { and before }
         if lDeflate3
            nElements := len(aLine) - 1
            for x := 1 to nElements
               if right(aLine[x],1) == '{' .and. ;
                             aType[x+1] == 'SP'
                  adel(aLine,x+1)
                  adel(aType,x+1)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
            for x := 1 to nElements
               if left(aLine[x+1],1) == '}' .and. ;
                            aType[x] == 'SP'
                  adel(aLine,x)
                  adel(aType,x)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
         endif

         // If deflate4 is on, throw away spaces after ,
         if lDeflate4
            nElements := len(aLine) - 1
            for x := 1 to nElements
               if aLine[x] == ',' .and. ;
                          aType[x+1] == 'SP'
                  adel(aLine,x+1)
                  adel(aType,x+1)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
         endif

         // If deflate5 is on, throw away spaces surrounding +
         if lDeflate5
            nElements := len(aLine) - 1
            for x := 1 to nElements
               if aLine[x] == '+' .and. ;
                          aType[x+1] == 'SP'
                  adel(aLine,x+1)
                  adel(aType,x+1)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
            for x := 1 to nElements
               if aLine[x+1] == '+' .and. ;
                          aType[x] == 'SP'
                  adel(aLine,x)
                  adel(aType,x)
                  asize(aLine,nElements)
                  asize(aType,nElements)
                  nElements --
               endif
            next
         endif

      endif

      // Identify known assignments as variables.

      nElements := len(aLine)

      for x := 3 to nElements
         if aLine[x] == ':='
            aType[ x - 2 ] := 'V'
         endif
      next

   endif

end sequence
return {aLine,aType}  //function lineparse()
// *******************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Procedure main_screen()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+
*+       Calls    ( click.prg    )   3 - procedure centertext()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static procedure main_screen(filespec)


STATIC cBox := ".-.|'-`| "
nMidScreen := 8+int(((maxrow() - 2) - 8) / 2)

setcolor('w+/b')

clear screen

dispbox(0,0,8,maxcol(),cBox)
dispbox(8,0,nMidScreen,maxcol(),cBox)
dispbox(nMidScreen,0,maxrow() - 2,maxcol(),cBox)
@  8,0                say '+'         
@  8,maxcol()         say '�'         
@ nMidScreen,0        say '+'         
@ nMidScreen,maxcol() say '�'         

centertext(' Click! Clipper Source Code Reformatter,  Version '+CVERSION+' ',0,'GR+/R')

centertext('Working set: '+filespec,2)

centertext(' Copyright (C) 1996-98, Phil Barnett. All Rights Reserved Worldwide ',maxrow() - 2,'W+/RB')
return
// ********************************************************************************************




*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function pop_stack()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function pop_stack(aStack)



local nLength := len(aStack)
local retval  := ''

if nLength > 0
   retval := aStack[nLength]
   asize(aStack,nLength - 1)
endif
return retval
// ***********************************************************************






*+--------------------------------------------------------------------
*+
*+
*+
*+    Function RootName()
*+
*+    Called from ( click.prg    )   4 - procedure click()
*+                ( libread.prg  )   2 - procedure libread()
*+                ( readlnk.prg  )   3 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function RootName(FILE_NAME)



local DOTAT := rat('.',FILE_NAME)

if DOTAT > 0
   FILE_NAME := left(FILE_NAME,DOTAT - 1)
endif
return alltrim(FILE_NAME)
// **********************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure setlinecont()
*+
*+    Called from ( declbust.prg )   1 - procedure declbust()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure setlinecont(aType)


// sets these static variables when called from declbuster.
lLastContinue := lLineContinue
lLineContinue := ascan(aType,'LC') > 0
return
// ********************************************************************





*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure show_in()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static function breadpart()
*+                                   3 - static procedure thealigner()
*+                ( cmd_list.prg )   5 - function init_list()
*+                ( functrak.prg )   5 - procedure func_text()
*+                ( libread.prg  )   3 - procedure libread()
*+                                   1 - static procedure dir_recurs()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure show_in(cData)



if lVerbose
   scroll(9,1,nMidScreen - 1,maxcol() - 1,1)
   @ nMidScreen - 1,2 say left(cData,maxcol() - 4)         
endif

return




*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure show_out()
*+
*+    Called from ( click.prg    )  14 - procedure click()
*+                                   2 - static function breadpart()
*+                                   2 - static procedure exitproc()
*+                                   6 - static function func_head()
*+                                  14 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )  12 - procedure func_text()
*+                ( libread.prg  )   2 - procedure libread()
*+                                   1 - static procedure dir_recurs()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure show_out(cData,cColor)


if lVerbose
   default cColor to 'W+/B'
   scroll(nMidScreen+1,1,maxrow() - 3,maxcol() - 1,1)
   @ maxrow() - 3,2 say left(cData,maxcol() - 4) color cColor        
endif
return
// ************************************************************************


// *************************************************************************


*+--------------------------------------------------------------------
*+
*+
*+
*+    Function TabSpStrip()
*+
*+    Called from ( click.prg    )   5 - static function breadpart()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function TabSpStrip(cString)


// strips tabs and spaces in any combination from left end of string
local nPointer := 1
local TABSPACE := ' '+chr(K_TAB)
do while substr(cString,nPointer,1) $ TABSPACE
   nPointer ++
enddo
return substr(cString,nPointer)
// **************************************************************************


// *******************************************************************
//Added 10/03 for Harbour Linux Conversion


*+--------------------------------------------------------------------
*+
*+
*+
*+    Function TabStrip()
*+
*+    Called from ( click.prg    )   1 - static function breadpart()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
FUNCTION TabStrip(cCharString)


LOCAL ii := 1,cFirst := SUBSTR(cCharString,1,1)
DO WHILE substr(cCharString,ii,1) == CHR(K_TAB)
   ii ++
ENDDO
return SUBSTR(cCharString,ii)
// ********************************************************************



//this is last step after initial parsing and smart alignment


*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Procedure TheAligner()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( obufread.prg )   1 - function bclose()
*+                ( obufread.prg )   2 - function beof()
*+                ( obufread.prg )   1 - function binit()
*+                ( obufread.prg )   3 - function blinenumber()
*+                ( obufread.prg )   4 - function bnextline()
*+                ( obufread.prg )   1 - function bopen()
*+                ( obufwrit.prg )   1 - procedure bo_close()
*+                ( obufwrit.prg )   1 - function bo_init()
*+                ( obufwrit.prg )   1 - function bo_open()
*+                ( obufwrit.prg )  17 - procedure bo_writenodupe()
*+                ( obufread.prg )   3 - function breadline()
*+                ( obufread.prg )   1 - function brelative()
*+                ( click.prg    )   1 - static function dbc_identify()
*+                ( click.prg    )   8 - static function leadspace()
*+                ( click.prg    )   7 - function lineparse()
*+                ( profile.prg  )   2 - function profilestring()
*+                ( click.prg    )   3 - procedure show_in()
*+                ( click.prg    )  14 - procedure show_out()
*+                ( click.prg    )   1 - function tabspstrip()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static procedure TheAligner(cInFile,cOutFile,cClickini)



local oBuffObj4    := bInit(cInFile)
local oHandle
local nOldPcntDone
local nPcntDone    := 0
local cThisLine    := ''
local cTempLine
local cThisCommand
local cNextLine
local cOutput
local aLines       := {}
local aLControl    := {}
local x
local y
local nY

local aParse
local aLine      := {}
local aType      := {}
local aNextParse
local aNextLine
local aNextType
local aControl   := {'@   ','SAY ','GET ','PICT','VALI',;
 'RANG','WHEN','COLO','SEND','MESS'}
local aOutPut
local aOutLines
local aOutMax   := array(10)

local nNumLines
local nNumElements
local nPointer
local nLastPointer
local lClickIgnore := .f.
local nMaxLen
local nHowmany
local nShorter
local nLeadSpace
local lInDbcre8    := .f.
local lInDbcre82   := .f.
local lInClasAlin  := .f.
local nMaxName
local nMaxN1
local nMaxN2
local lWorking
local nCommaAt
local cTabStrip
local cComment
local nOffset
local nOutPad
local nLineLen
local lTwoLevel,lbopen

//local cFullPath     := if( file( 'CLICK.INI' ), 'CLICK', RootName( ft_origin() ) ) + '.INI'
local dbCreateAlign := ProfileString(cClickini,'CLICK','ALIGN_DBCREATE_IN_THE_ALIGNER','YES') == 'YES'
local lClassAlign   := ProfileString(cClickini,'CLICK','ALIGN_CLASS_IN_THE_ALIGNER','YES') == 'YES'

local cAlignChars := if(lMode5,':=|+=|-=|*=|/=|^=|!=','=|!=')

lbopen := bOpen(oBuffObj4)  //must do this first to get crlf setting
ferase(cOutFile)
oHandle := bo_init(cOutFile,,oBuffObj4[newline],cClickini)
if bo_open(oHandle)
   if lbopen  //bOpen( oBuffObj4 )
      do while !bEof(oBuffObj4)

         lLineContinue := ascan(aType,'LC') > 0

         cThisLine := bReadLine(oBuffObj4)
         @  6,67 say str(bLineNumber(oBuffObj4),8)         
         show_in(cThisLine)

         nOldPcntDone := nPcntDone
         nPcntDone    := int(bRelative(oBuffObj4) * 50)
         if nOldPcntDone <> nPcntDone
            @  6,14 say replicate('',nPcntDone) color 'B/B'        
         endif

         aParse    := lineparse(ltrim(cThisLine))
         aLine     := aParse[1]
         aType     := aParse[2]
         cTabStrip := TabSpStrip(cThisLine)
         nLineLen  := len(aLine)
         //IF upper(substr(cthisline,1,7))="COUTDIR"
         //altd()
         //endif
         if upper(cTabStrip) == '*+CLICKOFF'
            lClickIgnore := .t.
         endif
         if lClickIgnore
            bo_writeNoDupe(oHandle,cThisLine+oBuffObj4[newline])
            show_out(cThisLine)
            if upper(cTabStrip) == '*+CLICKON' .or. bEof(oBuffObj4)
               lClickIgnore := .f.
            endif
            if at('*/',cThisLine) > 0
               lCommentMode := .f.
            endif
            loop
         endif

         if left(cTabStrip,1) == '*' .or. left(cTabStrip,2) $ '//|&&'
            bo_writeNoDupe(oHandle,cThisLine+oBuffObj4[newline])
            show_out(cThisLine)
            if at('*/',cThisLine) > 0
               lCommentMode := .f.
            endif
            loop
         endif

         if lCommentMode
            if (nPointer := at('*/',cThisLine)) > 0
               nPointer ++

               lCommentMode := .f.
               bo_writeNoDupe(oHandle,left(cThisLine,nPointer)+oBuffObj4[newline])
               show_out(left(cThisLine,nPointer))
               cThisLine := substr(cThisLine,nPointer+1)
               if !empty(cThisLine)
                  nStripComment := nPointer+1
               endif
               loop
            else
               bo_writeNoDupe(oHandle,cThisLine+oBuffObj4[newline])
               show_out(cThisLine)
               loop
            endif
         else
            if atail(aType) == '/*'
               lCommentMode := .t.
            endif
         endif

         do case

            // This case aligns CLASS HEADERS
         case lClassAlign .and. ;
             ((nLineLen > 2 .and. upper(aLine[1]) == 'CREATE' .and. upper(aLine[3]) == 'CLASS') .or. ;
             (nLineLen > 0 .and. upper(aLine[1]) == 'CLASS') .or. lInClasAlin)

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType})

            if empty(aLine) .or. ;
                          ! (upper(aLine[1]) == 'ENDCLASS' .or. ;
                          (len(aLine) > 2 .and. upper(aLine[1]) == 'END' .and. upper(aLine[3]) == 'CLASS'))
               lInClasAlin := .t.
               loop
            endif
            lInClasAlin := .f.

            nNumLines := len(aLines)

            lTwoLevel := .f.
            for x := 1 to nNumLines
               if len(aLines[x,3]) > 0 .and. ;
                            right(aLines[x,3,1],1) == ':'
                  lTwoLevel := .t.
                  exit
               endif
            next

            for x := 1 to nNumLines

               nY        := len(aLines[x,3])
               cTempLine := ''

               if nY > 0
                  for y := 1 to nY
                     cTempline += aLines[x,3,y]
                  next
               endif

               do case
               case x == 1 .or. x == nNumLines
                  aLines[ x, 1 ] := 0
               case len(aLines[x,3]) > 0 .and. ;
                   right(aLines[x,3,1],1) == ':'
                  aLines[ x, 1 ] := nTabClass
               otherwise
                  aLines[ x, 1 ] := iif(lTwoLevel,nTabClass * 2,nTabClass)
               endcase

               cTempLine := space(aLines[x,1])+cTempline

               if (nPointer := at('//',cTempline)) > 0
                  cComment  := substr(cTempline,nPointer)
                  cTempLine := trim(left(cTempline,nPointer - 1))
               else
                  cComment := ''
               endif

               cTempLine += space(nComntTab - (len(cTempLine) % nComntTab))+cComment

               bo_writeNoDupe(oHandle,trim(cTempline)+oBuffObj4[newline])
            next

            aLines := {}

            // This case aligns DBCREATE()
         case dbCreateAlign .and. nLineLen > 0 .and. ;
             (upper(aLine[1]) == 'DBCREATE' .or. lInDbcre8)

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType})

            //cNextLine  := bNextLine( oBuffObj4 )
            //aNextParse := lineparse( ltrim( cNextLine ) )
            //aNextLine  := aNextParse[ 1 ]
            //aNextType  := aNextParse[ 2 ]

            // lLineContinue := ascan( aNextType, 'LC' ) > 0 .or. ascan( aType, 'LC' ) > 0

            if ascan(aType,'LC') > 0
               lInDbcre8 := .t.
               loop
            endif
            lInDbcre8 := .f.

            nNumLines := len(aLines)

            nMaxName := 0
            nMaxN1   := 0
            nMaxN2   := 0
            nCommaAt := ascan(aLines[1,3],',')
            lWorking := nCommaAt > 0

            if lWorking

               begin sequence

                  for x := 1 to nNumLines
                     if len(aLines[x,3]) > if(x == 1,20,12) .and. ;
                                  aLines[x,3,if(x == 1,nCommaAt+2,1)] == '{' .and. ;
                                  aLines[x,3,if(x == 1,nCommaAt+4,1)] == '{'
                        nMaxName := max(nMaxName,len(aLines[x,3,if(x == 1,11,3)]))
                        nMaxN1   := max(nMaxN1,len(aLines[x,3,if(x == 1,17,9)]))
                        nMaxN2   := max(nMaxN2,len(aLines[x,3,if(x == 1,20,12)]))
                     else
                        lWorking := .f.
                        break
                     endif
                  next

               end sequence

            endif

            if lWorking
               for x := 1 to nNumLines
                  if len(aLines[x,3]) > if(x == 1,20,12)
                     aLines[ x, 3, if( x == 1, 11, 3 ) ]  := upper(padr(aLines[x,3,if(x == 1,11,3)],nMaxName))
                     aLines[ x, 3, if( x == 1, 17, 9 ) ]  := padl(aLines[x,3,if(x == 1,17,9)],nMaxN1)
                     aLines[ x, 3, if( x == 1, 20, 12 ) ] := padl(aLines[x,3,if(x == 1,20,12)],nMaxN2)
                  endif
               next

               aLines[ 1, 3, 4 ] := upper(aLines[1,3,4])
            endif

            for x := 1 to nNumLines
               nY        := len(aLines[x,3])
               cTempLine := ''
               for y := 1 to nY
                  cTempline += aLines[x,3,y]
               next

               bo_writeNoDupe(oHandle,space(aLines[x,1])+cTempline+oBuffObj4[newline])
            next

            aLines := {}

            // This case aligns arrays which contain DBCREATE() data
         case dbCreateAlign .and. nLineLen > 0 .and. ;
             (dbc_identify(aType) .or. lInDbcre82)

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType})

            cNextLine  := bNextLine(oBuffObj4)
            aNextParse := lineparse(ltrim(cNextLine))
            aNextLine  := aNextParse[1]
            aNextType  := aNextParse[2]

            lLineContinue := ascan(aNextType,'LC') > 0 .or. ascan(aType,'LC') > 0

            if lLineContinue
               lInDbcre82 := .t.
               loop
            endif
            lInDbcre82 := .f.

            nNumLines := len(aLines)

            nMaxName := 0
            nMaxN1   := 0
            nMaxN2   := 0
            lWorking := .t.

            begin sequence

               for x := 1 to nNumLines
                  if len(aLines[x,3]) > if(x == 1,20,12) .and. ;
                               aLines[x,3,if(x == 1,5,1)] == '{' .and. ;
                               aLines[x,3,if(x == 1,7,1)] == '{'
                     nMaxName := max(nMaxName,len(aLines[x,3,if(x == 1,9,3)]))
                     nMaxN1   := max(nMaxN1,len(aLines[x,3,if(x == 1,15,9)]))
                     nMaxN2   := max(nMaxN2,len(aLines[x,3,if(x == 1,18,12)]))
                  else
                     lWorking := .f.
                     break
                  endif
               next

            end sequence

            if lWorking
               for x := 1 to nNumLines
                  if len(aLines[x,3]) > if(x == 1,20,12)
                     aLines[ x, 3, if( x == 1, 9, 3 ) ]   := upper(padr(aLines[x,3,if(x == 1,9,3)],nMaxName))
                     aLines[ x, 3, if( x == 1, 15, 9 ) ]  := padl(aLines[x,3,if(x == 1,15,9)],nMaxN1)
                     aLines[ x, 3, if( x == 1, 18, 12 ) ] := padl(aLines[x,3,if(x == 1,18,12)],nMaxN2)
                  endif
               next

               aLines[ 1, 3, 4 ] := upper(aLines[1,3,4])
            endif

            nOffset := at(':=',aLines[1,2]) - at(':=',aLines[1,3,1]+aLines[1,3,2]+aLines[1,3,3])

            for x := 1 to nNumLines
               nY        := len(aLines[x,3])
               cTempLine := ''
               for y := 1 to nY
                  cTempline += aLines[x,3,y]
               next

               bo_writeNoDupe(oHandle,space(aLines[x,1] - if(x > 1,nOffset,0))+cTempline+oBuffObj4[newline])
            next

            aLines := {}

            // This case aligns @ say gets
         case !lLineContinue .and. nAlignMethod > 0 .and. nLineLen > 0 .and. aLine[1] == '@'

            if nLineLen > 2 .and. val(aLine[3]) < 10 .and. aLine[3] $ '9876543210'
               aLine[ 3 ] := ' '+aLine[3]
            endif
            if nLineLen > 5 .and. val(aLine[6]) < 10 .and. aLine[6] $ '9876543210'
               aLine[ 6 ] := ' '+aLine[6]
            endif

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType})

            cNextLine  := bNextLine(oBuffObj4)
            aNextParse := lineparse(ltrim(cNextLine))
            aNextLine  := aNextParse[1]
            aNextType  := aNextParse[2]

            if len(aNextLine) > 0 .and. aNextLine[1] == '@'
               loop
            endif

            nNumLines := len(aLines)

            aOutLines := {}
            afill(aOutMax,0)

            for x := 1 to nNumLines

               aOutPut := array(10)
               afill(aOutPut,'')
               nLastPointer := 1
               nNumElements := len(aLines[x,3])
               for y := 1 to nNumElements
                  if /*aLines[ x, 4, y ] $ 'CT' .or.*/ pad(upper(aLines[x,3,y]),4) $ 'SAY |GET |PICT|COLO|WHEN|RANG|VALI'
                     cThisCommand := pad(upper(aLines[x,3,y]),4)  // grab the matching command

                     // look for it in the control array
                     nPointer := ascan(aControl,{| a | cThisCommand == a})

                     if nPointer > 0
                        if nAlignMethod == 1
                           nLastPointer := nPointer
                        else
                           nLastPointer ++
                        endif
                     endif
                  endif

                  aOutPut[nLastPointer] += aLines[x,3,y]

               next

               aadd(aOutLines,aclone(aOutPut))

            next

            asize(aLControl,nNumLines)
            afill(aLControl,.t.)

            for x := 1 to nNumLines
               cTempLine := ''
               for y := 2 to 10
                  cTempLine += trim(aOutLines[x,y])
               next
               if empty(cTempLine)
                  aLControl[ x ] := .f.
               else
                  for y := 1 to 10
                     aOutMax[ y ] := max(aOutMax[y],len(trim(aOutLines[x,y]))+1)
                  next
               endif
            next

            for x := 1 to nNumLines
               if aLControl[x]
                  if nAlignMethod == 3
                     for y := 2 to 10
                        if y == 2
                           cTempline := space(aLines[x,1])+;
                            aOutLines[x,1]+;
                            aOutLines[x,y]+;
                            iif(!empty(aOutLines[x,y+1]),';','')
                           bo_writeNoDupe(oHandle,cTempline+oBuffObj4[newline])
                           show_out(cTempLine)
                        else
                           if !empty(aOutLines[x,y])
                              cTempline := space(aLines[x,1])+;
                               space(len(aOutLines[x,1]))+;
                               aOutLines[x,y]+;
                               iif(x < 10 .and. !empty(aOutLines[x,y+1]),';','')
                              bo_writeNoDupe(oHandle,cTempline+oBuffObj4[newline])
                              show_out(cTempLine)
                           endif
                        endif
                     next
                  else
                     cTempLine := ''
                     for y := 1 to 10
                        cTempLine += pad(aOutLines[x,y],aOutMax[y])
                     next
                     bo_writeNoDupe(oHandle,space(aLines[x,1])+cTempLine+oBuffObj4[newline])
                     show_out(space(aLines[x,1])+cTempLine)
                  endif
               else
                  bo_writeNoDupe(oHandle,space(aLines[x,1])+aLines[x,2]+oBuffObj4[newline])
                  show_out(space(aLines[x,1])+aLines[x,2])
               endif
            next

            aLines    := {}
            aOutLines := {}

            // This case aligns assignments
         case !lLineContinue .and. nLineLen > 2 .and. ;
             pad(aLine[3],2) $ cAlignChars

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType,at(aLine[3],cThisLine)})

            cNextLine  := bNextLine(oBuffObj4)
            aNextParse := lineparse(ltrim(cNextLine))
            aNextLine  := aNextParse[1]
            aNextType  := aNextParse[2]

            if len(aNextLine) > 2 .and. ;
                            pad(aNextLine[3],2) $ cAlignChars .and. ;
                            ! ascan(aType,'LC') > 0
               loop
            endif

            nNumLines := len(aLines)
            aOutLines := {}
            nMaxLen   := 0

            for x := 1 to nNumLines
               nMaxLen := max(len(aLines[x,3,1]),nMaxLen)
            next

            nMaxLen += 1

            for x := 1 to nNumLines
               aLines[ x, 3, 2 ] := space(nMaxLen - len(aLines[x,3,1]))

               aLines[ x, 2 ] := ''
               nHowMany       := len(aLines[x,3])
               cComment       := ''
               for y := 1 to nHowMany
                  if aLines[x,4,y] == '//'
                     cComment := aLines[x,3,y]
                  else
                     aLines[x,2] += aLines[x,3,y]
                  endif
               next

               cOutput := space(aLines[x,1])+aLines[x,2]

               if !empty(cComment)
                  cOutput += space(nComntTab - (len(cOutput) % nComntTab))+cComment
               endif

               bo_writeNoDupe(oHandle,cOutput+oBuffObj4[newline])
               show_out(space(aLines[x,1])+aLines[x,2])
            next

            // was the last line continued?
            if ascan(aLines[nNumLines,4],'LC') > 0
               nShorter := aLines[nNumLines,5] - at(aLines[nNumLines,3,3],space(aLines[nNumLines,1])+aLines[nNumLines,2])

               nShorter ++

               do while .t.

                  cThisLine := bReadLine(oBuffObj4)
                  @  6,67 say str(bLineNumber(oBuffObj4),8)         
                  show_in(cThisLine)

                  nLeadSpace := leadspace(cThisLine)
                  /*3/06 Following code sometimes overides the indentation
                    set by INDENT_CONTINUE_LINE option added to the smart allignment 
                    section.  The original intent vs a fixed indent really depends coding
                    style and/or the design intent of Click.  Will just leave this
                    waiting for someone with a better plan,PS
                  */

                  do case
                  case nLeadSpace > nShorter .and. nShorter < 0
                     cOutput := space(abs(nShorter)+1)+cThisLine
                  case nLeadSpace > nShorter
                     cOutput := substr(cThisLine,nShorter)
                  otherwise
                     cOutput := cThisLine
                  endcase

                  /*
                  Until I can figure out how to align comments here, I
                  will not mess with them.(Phil comment)

                  if ( nPointer := rat( '//', cOutput ) ) > 0
                     cLeft   := trim( left( cOutput, nPointer - 1 ) )
                     cRight  := substr( cOutput, nPointer )
                     cOutput := cLeft + space( nComntTab - ( len( cLeft ) % nComntTab ) ) + cRight
                  endif
                  */

                  bo_writeNoDupe(oHandle,cOutput+oBuffObj4[newline])
                  show_out(cOutput)

                  aParse := lineparse(ltrim(cThisLine))
                  aLine  := aParse[1]
                  aType  := aParse[2]
                  if ascan(aType,'LC') == 0   // no more continues
                     exit
                  endif

               enddo
            endif

            aLines    := {}
            aOutLines := {}

            // this case aligns declarations.
         case !lLineContinue .and. nLineLen > 0 .and. ;
             aType[1] $ 'CT' .and. ;
             upper(pad(aLine[1],4)) $ 'LOCA|STAT|PUBL|PRIV|MEMV|FIEL'

            aadd(aLines,{leadspace(cThisLine),ltrim(cThisLine),aLine,aType,at(aLine[3],cThisLine)})

            cNextLine  := bNextLine(oBuffObj4)
            aNextParse := lineparse(ltrim(cNextLine))
            aNextLine  := aNextParse[1]
            aNextType  := aNextParse[2]

            if len(aNextLine) > 0 .and. ;
                            aNextType[1] $ 'CT' .and. ;
                            upper(pad(aNextLine[1],4)) $ 'LOCA|STAT|PUBL|PRIV|MEMV|FIEL'
               loop
            endif

            nNumLines := len(aLines)
            aOutLines := {}
            nMaxLen   := 0

            for x := 1 to nNumLines
               nMaxLen := max(len(aLines[x,3,1]+aLines[x,3,2]+aLines[x,3,3]),nMaxLen)
            next

            nMaxLen += 1

            for x := 1 to nNumLines
               if len(aLines[x,3]) > 4 .and. aLines[x,3,5] == ':='
                  aLines[ x, 3, 4 ] := space(nMaxLen - len(aLines[x,3,1]+aLines[x,3,2]+aLines[x,3,3]))
               endif

               aLines[ x, 2 ] := ''
               nHowMany       := len(aLines[x,3])
               for y := 1 to nHowMany
                  if aLines[x,4,y] == '//'
                     nOutPad        := len(aLines[x,2])
                     nOutPad        += nComntTab - (nOutPad % nComntTab)
                     aLines[ x, 2 ] := pad(aLines[x,2],nOutPad)+aLines[x,3,y]
                  else
                     alines[x,2] += aLines[x,3,y]
                  endif
               next

               bo_writeNoDupe(oHandle,space(aLines[x,1])+aLines[x,2]+oBuffObj4[newline])
               show_out(space(aLines[x,1])+aLines[x,2])
            next

            // was the last line continued?
            if ascan(aLines[nNumLines,4],'LC') > 0
               nShorter := aLines[nNumLines,5] - at(aLines[nNumLines,3,3],space(aLines[nNumLines,1])+aLines[nNumLines,2])

               nShorter ++

               do while .t.
                  cThisLine := bReadLine(oBuffObj4)
                  @  6,67 say str(bLineNumber(oBuffObj4),8)         
                  show_in(cThisLine)
                  if leadspace(cThisLine) > nShorter
                     bo_writeNoDupe(oHandle,substr(cThisLine,nShorter)+oBuffObj4[newline])
                     show_out(substr(cThisLine,nShorter))
                  else
                     bo_writeNoDupe(oHandle,cThisLine+oBuffObj4[newline])
                     show_out(cThisLine)
                  endif

                  aParse := lineparse(ltrim(cThisLine))
                  aLine  := aParse[1]
                  aType  := aParse[2]
                  if ascan(aType,'LC') == 0   // no more continues
                     exit
                  endif

               enddo
            endif

            aLines    := {}
            aOutLines := {}

         otherwise
            bo_writeNoDupe(oHandle,cThisLine+oBuffObj4[newline])
            show_out(cThisLine)
         end case

      enddo


   endif

   bClose(oBuffObj4)

   bo_close(oHandle)

endif
return  //TheAligner
// *********************************************************************




*+ EOF: click.prg
*+
