*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/functrak.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Procedure init_func_text()
*+               Procedure functrak()
*+               Procedure func_call()
*+               Procedure end_func_text()
*+               Procedure func_text()
*+               Static Function findfunc()
*+               Static Function SubArrySrch()
*+
*+       Tables: USE (atemp[ii,1])
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+


#include 'fileio.ch'
#define newline  11

static aFuncs     := {}   // List of functions in each module
static aThisSrc   := {}   // Module Name, sub function list
static aFuncList  := {}   // The big collection of how each function gets called
static aTable     := {}   // contains table references for the TABLE.TXT file
static aIndex     := {}   // contains index references for the INDEX.TXT file
static sFuncText  := ''   // contains the function header line
static sModule    := ''   // contains the current module name
static cFullPath  := ''   // contains a reference to the
static aMyLibFunc := {}   // static array of table function names
static aMyIndFunc := {}   // static array of index function names



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure init_func_text()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( token.prg    )   2 - function numtoken()
*+                ( profile.prg  )   2 - function profilestring()
*+                ( token.prg    )   2 - function numtoken()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure init_func_text(cModule,cClickini)



// called at the beginning of each file

local cMyLibFunc
local cMyIndFunc
local nElems
local x
if cFullPath == ''
   cFullPath  := cClickini  //this retains original program logic
   cMyLibFunc := upper(ProfileString(cFullPath,'CLICK','MY_TABLE_FUNCTION',''))
   cMyIndFunc := upper(ProfileString(cFullPath,'CLICK','MY_INDEX_FUNCTION',''))
   if !empty(cMyLibFunc)
      nElems := numtoken(cMyLibFunc,'|')
      asize(aMyLibFunc,nElems)
      for x := 1 to nElems
         aMyLibFunc[ x ] := upper(token(cMyLibFunc,'|',x))
      next
      // add this to the array
      aadd(aMyLibFunc,'DBUSEAREA')
   endif
   if !empty(cMyIndFunc)
      nElems := numtoken(cMyIndFunc,'|')
      asize(aMyIndFunc,nElems)
      for x := 1 to nElems
         aMyIndFunc[ x ] := upper(token(cMyIndFunc,'|',x))
      next
      // add this to the array
      aadd(aMyIndFunc,'DBCREATEIND')
   endif
endif

sModule := cModule

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure functrak()
*+
*+    Called from ( click.prg    )   1 - static function func_head()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure functrak(cFuncText)



// Called as each function header is created

sFuncText := cFuncText

if empty(aThisSrc)
   aThisSrc := {sModule,{}}
endif

aadd(aThisSrc[2],sFuncText)

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure func_call()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( functrak.prg )   2 - static function subarrysrch()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure func_call(aLine,aType)



// called as each line is parsed.

local x
local nHowmany  := len(aType)
local nPointer
local nPointer2
local uFW       := upper(aLine[1])
local cLine     := ''

for x := 1 to nHowMany  //3/06 added P type 'do procedure' & 'set key proc' removed 2/09
   //causing problem with 'to' proc/func in set key lines
   if aType[x] == 'F'   // .or. aType[x] == 'P'  //to be add to the afunclist array
      //this is good place of trapping unusual function entries altd()
      nPointer := ascan(aFuncList,{| y | upper(y[1]) == upper(aLine[x])})
      if empty(nPointer)
         aadd(afunclist,{aLine[x],{{sFuncText,sModule,1}}})
      else
         if (nPointer2 := ascan(aFuncList[nPointer,2],{| y | y[1] == sFuncText .and. y[2] == sModule})) == 0
            aadd(afunclist[nPointer,2],{sFuncText,sModule,1})
         else
            aFuncList[nPointer,2,nPointer2,3] ++
         endif
      endif
   endif
next

// this collects TABLE and INDEX information

do case
case uFW == 'USE' .or. SubArrySrch(aMyLibFunc,aLine)

   for x := 1 to nHowMany
      cLine += aLine[x]
   next

   nPointer := ascan(aTable,{| y | y[1] == sModule})

   if empty(nPointer)
      aadd(aTable,{sModule,{{sFuncText,cLine,1}}})
   else
      if (nPointer2 := ascan(aTable[nPointer,2],{| y | y[1] == sFuncText .and. upper(y[2]) == upper(cLine)})) == 0
         aadd(aTable[nPointer,2],{sFuncText,cLine,1})
      else
         aTable[nPointer,2,nPointer2,3] ++
      endif
   endif

case uFW == 'INDEX' .or. SubArrySrch(aMyIndFunc,aLine)

   for x := 1 to nHowMany
      cLine += aLine[x]
   next

   nPointer := ascan(aIndex,{| y | y[1] == sModule})

   if empty(nPointer)
      aadd(aIndex,{sModule,{{sFuncText,cLine,1}}})
   else
      if (nPointer2 := ascan(aIndex[nPointer,2],{| y | y[1] == sFuncText .and. upper(y[2]) == upper(cLine)})) == 0
         aadd(aIndex[nPointer,2],{sFuncText,cLine,1})
      else
         aIndex[nPointer,2,nPointer2,3] ++
      endif
   endif

endcase

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure end_func_text()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure end_func_text()



// called at the end of each file

if !empty(aThisSrc)
   aadd(aFuncs,aThisSrc)
   aThisSrc := {}
endif

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure func_text()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+       Calls    ( prb_ampm.prg )   4 - function am_pm()
*+                ( obufread.prg )   1 - function bclose()
*+                ( obufread.prg )   1 - function beof()
*+                ( obufread.prg )   1 - function binit()
*+                ( obufread.prg )   1 - function bopen()
*+                ( obufwrit.prg )   5 - procedure bo_close()
*+                ( obufwrit.prg )   5 - function bo_init()
*+                ( obufwrit.prg )   5 - function bo_open()
*+                ( obufwrit.prg )  57 - procedure bo_write()
*+                ( obufread.prg )   1 - function breadline()
*+                ( obufread.prg )   1 - function brelative()
*+                ( click.prg    )   5 - procedure centertext()
*+                ( unresolved   )   1 - function dbfsize()
*+                ( filnpath.prg )   1 - function fileinpath()
*+                ( functrak.prg )   1 - static function findfunc()
*+                ( nicedate.prg )   4 - function nicedate()
*+                ( profile.prg  )  11 - function profilestring()
*+                ( click.prg    )   5 - procedure show_in()
*+                ( click.prg    )  12 - procedure show_out()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure func_text(aLibList,aFileList,cClickini)



// called after all files have been processed

// Pass 4, with the purple progress meter.

local cSrcOut   := ProfileString(cClickini,'CLICK','SOURCE_XREF_FILE','SRC_CROS.TXT')
local cFncOut   := ProfileString(cClickini,'CLICK','FUNCTION_XREF_FILE','FNC_CROS.TXT')
local cTblOut   := ProfileString(cClickini,'CLICK','TABLE_XREF_FILE','TBL_CROS.TXT')
local cFldOut   := ProfileString(cClickini,'CLICK','FIELD_XREF_FILE','FLD_CROS.TXT')
local lSrcAdd   := ProfileString(cClickini,'CLICK','FUNCTION_REF_INTO_SOURCE','YES') == 'YES'
local lFncAdd   := ProfileString(cClickini,'CLICK','FUNCTION_XREF_INTO_SOURCE','YES') == 'YES'
local lTblAdd   := ProfileString(cClickini,'CLICK','TABLE_XREF_INTO_SOURCE','YES') == 'YES'
local lIndAdd   := ProfileString(cClickini,'CLICK','INDEX_XREF_INTO_SOURCE','YES') == 'YES'
local lTimeDate := ProfileString(cClickini,'CLICK','RETAIN_ORIGINAL_TIME_DATE_ON_OUTPUT_FILES','YES') == 'YES'
local cHeadDiv  := ProfileString(cClickini,'CLICK','HEAD_DIV','�')

local bo_Handle
local bi_Handle
//this OSCRLF used for cross reference .txt files
//while prg files retain the eol of original input file 10/03
local OSCRLF  //   := HB_OSNewLine()
local cOutput,cOutDir,cFullPath,ii,jj,kk  //cThisOut,ctest,nW 2/09
local v,w,x,y,z,cFoundIn,nV,nX,nY,cThisProg,cLastProg,cProg,dirsep,drivesep
local cThisFile,cOutFile,lGotHeader,cThisLine,cThisFunc,spat,nOldPcntDone,cProcFunc
local nPcntDone  := 0,ntemp
local lStatic,lFoundOne := .f.
local lNoLibList := empty(aLibList)
local lGotIt,cLookFor,lstarttrap := .f.
local aLib       := {}
local aHit       := {}
local nPointer,nPointer1,nPointer2,nMinPntr
local aF2F       := {}
local aTemp      := {},afld_list := {},ctemp,cdatatype
local sp         := space(6)
OSCRLF := HB_OSNewLine()
IF CHR(13) $ OSCRLF
   dirsep   := '\'
   drivesep := DISKNAME()+':'   //? windows version
ELSE  //must be linux
   dirsep   := '/'
   drivesep := ''
ENDIF
cFullPath := drivesep+dirsep+CURDIR(drivesep)+dirsep  //10/03 local copy in startup directory
cOutDir   := cFullPath+ProfileString(cClickini,'CLICK','OUTPUT_DIRECTORY','clickout')+dirsep
if lSrcAdd .or. lFncAdd .or. lTblAdd .or. lIndAdd

   nV := len(aFilelist)
   for v := 1 to nV   //loop thru each file in list
      cThisFile := cOutDir+aFileList[v]
      show_out(cThisFile)
      cOutFile := cOutDir+'$tempfil.$$$'
      @  4,1 clear to 4,maxcol() - 1
      centertext('Current File => '+cThisFile,4)
      @  6,11 clear to 6,maxcol() - 5
      @  6,10 say '4'         
      // initialize buffered input first to get newline character
      bi_handle := binit(cThisFile)
      bOpen(bi_handle)  //must open file and get correct newline
      bo_handle := bo_init(cOutFile,FO_WRITE,bi_handle[newline],cClickini)
      bo_Open(bo_handle)
      lGotHeader   := .f.   //will need a new file header
      nOldPcntDone := 0
      do while !beof(bi_handle)   //on same file, get another line
         nOldPcntDone := nPcntDone
         nPcntDone    := int(bRelative(bi_handle) * 50)
         if nOldPcntDone <> nPcntDone
            @  6,15 say replicate('',nPcntDone) color 'RB+/B'        
         endif
         cThisLine := bReadLine(bi_handle)
         if left(cThisLine,2) == '*+'

            do case
               //this case happens once per file
            case left(cThisLine,27) == '*+    Reformatted by Click!'
               //This insert functions & procedures contained within this file
               lGotHeader := .t.
               if lSrcAdd
                  w := ascan(aFuncs,{| x | x[1] == aFileList[v]})
                  if w > 0
                     nY := len(aFuncs[w,2])
                     if nY > 0
                        for y := 1 to nY
                           if y == 1
                              bo_write(bo_handle,'*+    Functions: '+aFuncs[w,2,y]+bi_handle[newline])
                           else
                              bo_write(bo_handle,'*+               '+aFuncs[w,2,y]+bi_handle[newline])
                           endif
                        next
                        bo_write(bo_handle,'*+'+bi_handle[newline])
                     endif
                  endif
               endif
               // This inserts table data into the FILE HEADER.
               if lTblAdd
                  if (nPointer := ascan(aTable,{| x | x[1] == aFileList[v]})) > 0
                     nY := len(aTable[nPointer,2])
                     if lTblAdd .and. nY > 0
                        for y := 1 to nY
                           if y == 1
                              bo_write(bo_handle,'*+       Tables: '+aTable[nPointer,2,y,2]+bi_handle[newline])
                           else
                              bo_write(bo_handle,'*+               '+aTable[nPointer,2,y,2]+bi_handle[newline])
                           endif
                        next
                        bo_write(bo_handle,'*+'+bi_handle[newline])
                     endif
                  endif
               endif
               // This inserts index data into the FILE HEADER.
               if lIndAdd
                  if (nPointer := ascan(aIndex,{| x | x[1] == aFileList[v]})) > 0
                     nY := len(aIndex[nPointer,2])
                     if lTblAdd .and. nY > 0
                        for y := 1 to nY
                           if y == 1
                              bo_write(bo_handle,'*+      Indexes: '+aIndex[nPointer,2,y,2]+bi_handle[newline])
                           else
                              bo_write(bo_handle,'*+               '+aIndex[nPointer,2,y,2]+bi_handle[newline])
                           endif
                        next
                        bo_write(bo_handle,'*+'+bi_handle[newline])
                     endif
                  endif
               endif
               //no more writing until we get to next header
               bo_write(bo_handle,cThisLine+bi_handle[newline])
               //following case happens once per procedure/function
            case lFncAdd .and. lGotHeader .and. left(cThisLine,6) == '*+    '
               //should only get here needing functions in a proc/func header
               // This inserts function data into the FUNCTION HEADERS
               cProcFunc := Alltrim(SUBSTR(cThisLine,3))
               cThisFunc := upper(substr(cThisLine,7))
               lStatic   := upper(left(cThisFunc,4)) == 'STAT'
               spat      := rat(' ',cThisFunc)
               cThisFunc := substr(cThisFunc,spat+1)
               cThisFunc := left(cThisFunc,len(cThisFunc) - 2)
               x         := ascan(aFuncList,{| x | upper(x[1]) == cThisFunc})
               bo_write(bo_handle,cThisLine+bi_handle[newline])
               bo_write(bo_handle,'*+'+bi_handle[newline])

               if x > 0   //are there any called by in aFuncList
                  nY        := len(aFuncList[x,2])
                  cLastProg := '________'
                  z         := 0
                  for y := 1 to nY  //print the entire called by list
                     if lStatic   // is the function static?

                        // Here, we are scoping the search. If this is
                        // a static function, then there could be several
                        // of the function by the same name, so this
                        // routine figures out if the function is static
                        // and then eliminates impossible calls from other
                        // modules.

                        // if these match, then the call belongs to this
                        // static function in this module
                        if aFileList[v] == aFuncList[x,2,y,2]
                           cThisProg := ' ( '+;
                            pad(lower(aFuncList[x,2,y,2]),12)+;
                            ' ) '

                           if cThisProg <> cLastProg
                              cProg := cThisProg
                           else
                              cProg := space(18)
                           endif
                           cOutput := if(++ z == 1,'Called from',space(11))+;
                            cProg+;
                            str(aFuncList[x,2,y,3],3)+' - '+;
                            lower(aFuncList[x,2,y,1])
                           cLastProg := cThisProg
                           show_out(cOutput)
                           bo_write(bo_handle,'*+    '+cOutput+bi_handle[newline])
                        endif

                     else   //not lStatic

                        // So if we are here, the function was not static.
                        // include ALL calls.

                        cThisProg := ' ( '+;
                         pad(lower(aFuncList[x,2,y,2]),12)+;
                         ' ) '

                        if cThisProg <> cLastProg
                           cProg := cThisProg
                        else
                           cProg := space(18)
                        endif
                        cOutput := if(y == 1,'Called from',space(11))+;
                         cProg+;
                         str(aFuncList[x,2,y,3],3)+' - '+;
                         lower(aFuncList[x,2,y,1])
                        cLastProg := cThisProg
                        show_out(cOutput)
                        bo_write(bo_handle,'*+    '+cOutput+bi_handle[newline])
                     endif  //finished whether lStatic T/Ft
                  next  //done with the called by list
                  bo_write(bo_handle,'*+'+bi_handle[newline])
               endif  //were there any called by candidates, x>0
               //finished with called from function/procedures
               //now add functions/prg called by this prg added 3/06
               //kind of a reverse funclist array lookup
               //afilelist[v] = list of all prg files
               atemp := {}  //empty array
               FOR ii := 1 to len(afunclist)  //step thru all the proc/func identified
                  FOR jj := 1 to len(afunclist[ii,2])   //step throu all the called from functions
                     //if file we are on=called from file .and. procedure/function we are on
                     //matches called from function add it to the list
                     IF Upper(afilelist[v]) == Upper(afunclist[ii,2,jj,2]) .and. ;
                                       Upper(cProcFunc) == Upper(afunclist[ii,2,jj,1])
                        aadd(atemp,{afunclist[ii,1]+'()',str(aFuncList[ii,2,jj,3],3)+' - '})
                     ENDIF
                  NEXT  //jj
               NEXT   //ii
               //arrange them so they print alphabetically
               atemp := asort(atemp,,,{| x,y | Upper(x[1]) < Upper(y[1])})  //sort list
               for ii := 1 to len(atemp)
                  atemp[ ii ] := atemp[ii,2]+atemp[ii,1]  //combine back to one dimension
               next
               FOR ii := 1 to len(atemp)  //update all the references with
                  FOR jj := 1 to len(afuncs)  //step thru all prg files
                     FOR kk := 1 to len(afuncs[jj,2])   //step thru all functions in the file
                        IF Upper(SUBSTR(atemp[ii],7)) $ Upper(afuncs[jj,2,kk])
                           DO CASE  //a static test
                           CASE UPPER(afuncs[jj,1]) = UPPER(afilelist[v]) .and. ;
                               'STAT' = UPPER(SUBSTR(afuncs[jj,2,kk],1,4))  //best we can do
                              atemp[ ii ] := '  ( '+Pad(afuncs[jj,1],12)+' ) '+;
                               SUBSTR(atemp[ii],1,6)+lower(afuncs[jj,2,kk])
                              kk := len(afuncs[jj,2])   //stop the search
                           CASE 'STAT' = UPPER(substr(afuncs[jj,2,kk],1,4))
                              //out of scope don't enter anything
                           OTHERWISE
                              atemp[ ii ] := '  ( '+Pad(afuncs[jj,1],12)+' ) '+;
                               SUBSTR(atemp[ii],1,6)+lower(afuncs[jj,2,kk])
                              //continue in case we find a static match
                           ENDCASE
                        ENDIF
                     NEXT
                  NEXT
                  IF substr(atemp[ii],1,4) != '  ( ' .and. ii <= len(atemp)
                     //we didn't find the function in a *.prg file, mark unresolved function
                     atemp[ ii ] := '  ( '+Pad('unresolved',12)+' ) '+;
                      substr(atemp[ii],1,6)+'function '+substr(atemp[ii],7)
                  endif
               NEXT
               IF len(atemp) > 0  //were there any "Calls to" found
                  //sort the array before writing the handle
                  FOR ii := 1 to LEN(atemp)   //now print the calls to stuff out
                     cOutput := if(ii == 1,'   Calls  ',space(10))+;
                      atemp[ii]
                     show_out(cOutput)
                     bo_write(bo_handle,'*+    '+cOutput+bi_handle[newline])
                  NEXT
               ENDIF  //len(atemp)>0
               bo_write(bo_handle,'*+'+bi_handle[newline])
            otherwise
               bo_write(bo_handle,cThisLine+bi_handle[newline])
               bo_write(bo_handle,'*+'+bi_handle[newline])
            endcase   //get header first the function calls
         else   //nothing special just write the line
            bo_write(bo_handle,cThisLine+bi_handle[newline])
         endif  //left( cThisLine, 2 ) == '*+'
      enddo   //while not end-of-file
      bclose(bi_handle)
      bo_close(bo_handle)

      //removed 10/03, not sure how to do this, or if it's still a good idea
      //      if lTimeDate  // From CLICK.INI sets time/date to original file
      //         setfdati( cOutFile, filedate( cThisFile ), filetime( cThisFile ) )
      //      endif

      ferase(cThisFile)   //temporarily out debugging altd
      frename(cOutFile,cThisFile)

   next   //for next file in file list line~291
endif   //done putting info into source files

@  4,1 clear to 7,maxcol() - 1

if !empty(cSrcOut)

   // This creates the text file in the output directory which contains
   // the entire function reference for every module.
   // It dumps the multidimensional array to a text file in a pretty format.

   centertext('Current File => '+cOutDir+cSrcOut,4)
   ferase(cOutDir+cSrcOut)
   bo_Handle := bo_init(cOutDir+cSrcOut,FO_WRITE,OSCRLF,cClickini)  //this will pickup OS newline
   bo_open(bo_Handle)

   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+    Created by Click! on '+nicedate(date())+' at '+am_pm(time())+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF+OSCRLF)

   show_out('Sorting Master Function List')
   aFuncs := asort(aFuncs,,,{| x,y | upper(x[1]) < upper(y[1])})

   show_out('Sorting Sub Function List')
   nX := len(aFuncs)
   for x := 1 to nX
      show_out(aFuncs[x,1])
      bo_write(bo_handle,aFuncs[x,1]+OSCRLF+OSCRLF)
      aeval(aFuncs[x,2],{| x | bo_write(bo_handle,'  '+x+OSCRLF)})
      bo_write(bo_handle,OSCRLF)
   next
   bo_close(bo_handle)
endif   //done outputting function reference for modules

if !empty(cFncOut)

   // This creates the text file in the output directory which contains
   // the function to function reference for every module.

   // It dumps the multidimensional array to a text file in a pretty format.

   @  4,1 clear to 4,maxcol() - 1
   centertext('Current File => '+cOutDir+cFncOut,4)

   ferase(cOutDir+cFncOut)
   bo_Handle := bo_init(cOutDir+cFncOut,FO_WRITE,OSCRLF,cClickini)
   bo_open(bo_Handle)

   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+    Created by Click! on '+nicedate(date())+' at '+am_pm(time())+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF)

   show_out('Sorting Called Function List')
   aFuncList := asort(aFuncList,,,{| x,y | upper(x[1]) < upper(y[1])})

   nX := len(aFuncList)
   for x := 1 to nX
      cLookFor := lower(aFunclist[x,1])
      if cLookFor == 'if'
         loop
      endif
      cOutput  := pad(cLookFor+'()',15)
      cFoundIn := findfunc(' '+aFunclist[x,1]+'()')
      cLookFor += ' '
      if empty(cFoundIn)
         // Not found in the internal function array
         lGotIt := .f.
         // is it in the CLICK.DBF?
         if click->(dbseek(cLookFor))
            // if we weren't passed a .LNK file, we have no LIB list
            if lNoLibList
               // show them all
               do while cLookFor $ click->fnct
                  if len(cOutPut) == 15
                     cOutput += ' in '+trim(click->srce)+OSCRLF
                  else
                     cOutput += space(15)+' or '+trim(click->srce)+OSCRLF
                  endif
                  show_in(space(19)+click->srce)
                  lGotIt := .t.
                  click->(dbskip(1))
               enddo
            else
               // aha! we do have a lib list

               // first, find all the matches in the lib list.

               aLib     := {}
               aHit     := {}
               nMinPntr := 9999999999
               do while cLookFor $ click->fnct
                  if (nPointer := ascan(aLibList,{| aParm | aParm $ trim(click->srce)})) > 0
                     aadd(aHit,nPointer)
                     aadd(aLib,aLibList[nPointer])
                     nMinPntr := min(nMinPntr,nPointer)
                  endif
                  click->(dbskip(1))
               enddo

               // then, figure out which one is the first one in the current path.

               if len(aHit) > 0
                  nPointer := ascan(aHit,nMinPntr)
                  cOutput  += ' in '+fileinpath(aLib[nPointer],'LIB')+OSCRLF
                  show_in(space(19)+aLib[nPointer])
                  lGotIt := .t.
               endif

            endif
         endif

         // never found a match???

         if !lGotIt
            cOutput += ' <unresolved function>'
            show_in(cOutput)
            cOutput += OSCRLF
         endif

      else
         cOutput += ' in '+lower(cFoundIn)
         show_in(cOutput)
         cOutput += OSCRLF
      endif

      bo_write(bo_Handle,OSCRLF+cOutput+OSCRLF)
      cLastProg := '________'

      aFuncList[ x, 2 ] := asort(aFuncList[x,2],,,{| x,y | upper(x[2]+x[1]) < upper(y[2]+y[1])})
      nY                := len(aFuncList[x,2])
      for y := 1 to nY
         cThisProg := ' ( '+;
          pad(lower(aFuncList[x,2,y,2]),12)+;
          ' ) '

         if cThisProg <> cLastProg
            cProg := cThisProg
         else
            cProg := space(18)
         endif
         cOutput := if(y == 1,'  Called from',space(13))+;
          cProg+;
          str(aFuncList[x,2,y,3],3)+' - '+;
          lower(aFuncList[x,2,y,1])

         cLastProg := cThisProg
         show_out(cOutput)
         bo_write(bo_handle,cOutput+OSCRLF)
      next
   next
   bo_close(bo_Handle)
endif   //output function information

if !empty(cTblOut)

   centertext('Current File => '+cOutDir+cTblOut,4)

   ferase(cOutDir+cTBLOut)
   bo_Handle := bo_init(cOutDir+cTblOut,FO_WRITE,OSCRLF,cClickini)
   bo_open(bo_Handle)

   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+    Created by Click! on '+nicedate(date())+' at '+am_pm(time())+OSCRLF)
   bo_write(bo_handle,'*+'+OSCRLF)
   bo_write(bo_handle,'*+'+replicate(cHeadDiv,68)+OSCRLF)
   bo_write(bo_handle,OSCRLF)

   for v := 1 to nV

      nPointer1 := ascan(aTable,{| x | x[1] == aFileList[v]})
      nPointer2 := ascan(aIndex,{| x | x[1] == aFileList[v]})

      if nPointer1 > 0 .or. nPointer2 > 0

         bo_write(bo_handle,aFileList[v]+OSCRLF+OSCRLF)
         show_in(aFileList[v])

         if nPointer1 > 0
            nY := len(aTable[nPointer1,2])
            if nY > 0
               for y := 1 to nY
                  if y == 1
                     bo_write(bo_handle,'   Tables: '+aTable[nPointer1,2,y,2]+OSCRLF)
                  else
                     bo_write(bo_handle,'           '+aTable[nPointer1,2,y,2]+OSCRLF)
                  endif
                  show_out(aTable[nPointer1,2,y,2])
               next
               bo_write(bo_handle,OSCRLF)
            endif
         endif

         if nPointer2 > 0
            nY := len(aIndex[nPointer2,2])
            if lTblAdd .and. nY > 0
               for y := 1 to nY
                  if y == 1
                     bo_write(bo_handle,'  Indexes: '+aIndex[nPointer2,2,y,2]+OSCRLF)
                  else
                     bo_write(bo_handle,'           '+aIndex[nPointer2,2,y,2]+OSCRLF)
                  endif
                  show_out(aIndex[nPointer2,2,y,2])
               next
               bo_write(bo_handle,OSCRLF)
            endif
         endif

      endif

   next

   bo_close(bo_Handle)

endif   //output table/index information

if !empty(cFldOut)

   centertext('Current File => '+cOutDir+cFldOut,4)

   ferase(cOutDir+cFldOut)
   bo_Handle := bo_init(cOutDir+cFldOut,FO_WRITE,OSCRLF,cClickini)
   bo_open(bo_Handle)

   bo_write(bo_handle,'*+  File:'+cOutDir+cFldOut+OSCRLF)
   bo_write(bo_handle,'*+    Created by Click! on '+nicedate(date())+' at '+am_pm(time())+OSCRLF)
   bo_write(bo_handle,'*+'+replicate('-',75)+OSCRLF)
   bo_write(bo_handle,OSCRLF)
   atemp := {}
   atemp := directory('*.dbf')
   IF len(atemp) = 0
      atemp := directory('*.DBF')
   ENDI
   asort(atemp,,,{| x,y | upper(x[1]) < upper(y[1])})
   ntemp := ascan(atemp,{| x | upper(x[1]) == 'CLICK.DBF'},,)
   IF ntemp != 0  //don't need the click.dbf one
      adel(atemp,ntemp)
      asize(atemp,len(atemp) - 1)
   ENDIF
   for ii := 1 to len(atemp)
      USE (atemp[ii,1])
      afld_list := DBSTRUCT()
      bo_write(bo_handle,OSCRLF+PAD('  DATABASE: '+atemp[ii,1],25)+'  Printed On:'+DTOC(DATE())+OSCRLF)
      bo_write(bo_handle,PAD('  Record Count: '+LTRIM(STR(LASTREC())),22)+;
       pad('Table Size: '+LTRIM(TRANSFORM(dbfsize(),'999,999,999,999'))+;
       '  ',57)+OSCRLF+OSCRLF)  //pwidth-22=79-22=57
      bo_write(bo_handle,'Position (.dbf)       Field Name        Type          Width      Dec.'+OSCRLF)
      atemp[ii,1] = ' ('+SUBSTR(atemp[ii,1],1,AT('.',atemp[ii,1]) - 1)+'->)'  //drop the .dbf
      FOR X := 1 TO FCOUNT()
         DO CASE
         CASE afld_list[x,2] == 'C'
            cdatatype := 'Character'
         CASE afld_list[x,2] == 'N'
            cdatatype := 'Numeric  '
         CASE afld_list[x,2] == 'L'
            cdatatype := 'Logical  '
         CASE afld_list[x,2] == 'M'
            cdatatype := 'Memo     '
         CASE afld_list[x,2] == 'D'
            cdatatype := 'Date     '
         OTHERWISE
            cdatatype := afld_list[x,2]
         ENDCASE
         IF afld_list[x,4] == 0
            ctemp := ''   //SPACE(4)
         ELSE
            ctemp := STR(afld_list[x,4],4)
         ENDIF

         show_out(STR(afld_list[x,4],4))
         bo_write(bo_handle,PAD(STR(X,4)+atemp[ii,1],17)+sp+;
          PAD(afld_list[x,1],10)+sp+cdatatype+sp+;
          STR(afld_list[x,3],4)+sp+ctemp+OSCRLF)

      NEXT
      bo_write(bo_handle,'*+'+replicate('-',75)+OSCRLF)   //end of fields marker

   next

   bo_close(bo_Handle)

endif   //output some database field information

@  4,1 clear to 4,maxcol() - 1
@  6,1 clear to 6,maxcol() - 1

return  //eof func_text



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function findfunc()
*+
*+    Called from ( functrak.prg )   1 - procedure func_text()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function findfunc(cThisFunc)



local x
local nX
local y
local nY
local lRetVal  := ''
local nFuncLen
local cLookIn

// This function finds a function reference in the master array.

cThisFunc := upper(cThisFunc)
nFuncLen  := len(cThisFunc)+2

nX := len(aFuncs)
for x := 1 to nX
   nY := len(aFuncs[x,2])
   for y := 1 to nY
      cLookIn := right(upper(aFuncs[x,2,y]),nFuncLen)
      if cThisFunc $ cLookIn
         lRetVal := aFuncs[x,1]
      endif
   next
next

return lRetVal



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function SubArrySrch()
*+
*+    Called from ( functrak.prg )   2 - procedure func_call()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function SubArrySrch(aFuncs,aLine)



local x
local y
local lRetVal := .f.

begin sequence
   for y := 1 to len(aLine)
      for x := 1 to len(aFuncs)
         if aFuncs[x] == upper(aLine[y])
            lRetVal := .t.
            break
         endif
      next
   next
end sequence

return lRetVal



*+ EOF: functrak.prg
*+
