*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/prb_stak.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Procedure PUTSCREEN()
*+               Procedure GETSCREEN()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "common.ch"
static aScr := {}
static n    := 0



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure PUTSCREEN()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure PUTSCREEN(t,l,b,r)



default t to 0
default l to 0
default b to maxrow()
default r to maxcol()

aadd(aScr,{t,l,b,r,savescreen(t,l,b,r),row(),col(),set(_SET_CURSOR),setcolor()})
n ++

return



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure GETSCREEN()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - static procedure exitproc()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure GETSCREEN(lOption)



default lOption to 1

do case
case lOption == 0
   n    := 0
   aScr := {}
case lOption == - 1
   asize(aScr,-- n)
otherwise
   if n > 0
      restscreen(aScr[n,1],aScr[n,2],aScr[n,3],aScr[n,4],aScr[n,5])
      devpos(aScr[n,6],aScr[n,7])
      set(_SET_CURSOR,aScr[n,8])
      setcolor(aScr[n,9])
      asize(aScr,-- n)
   endif
endcase

return



*+ EOF: prb_stak.prg
*+
