*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/obufread.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Function BInit()
*+               Function Bopen()
*+               Function BReadLine()
*+               Function BNextLine()
*+               Static Function BDisk2Buff()
*+               Function BEof()
*+               Function BClose()
*+               Function BPosition()
*+               Function BRelative()
*+               Function BLineNumber()
*+               Function BGetSet()
*+               Function BRestSet()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include 'fileio.ch'
#include 'common.ch'

#define cFileName oBuffObj[ 1 ]
#define nAccMode oBuffObj[ 2 ]
#define cLineBuffer oBuffObj[ 3 ]
#define nHandle oBuffObj[ 4 ]
#define nBytesRead oBuffObj[ 5 ]
#define lFullBuff oBuffObj[ 6 ]
#define nTotBytes oBuffObj[ 7 ]
#define lIsOpen oBuffObj[ 8 ]
#define nFileBytes oBuffObj[ 9 ]
#define nFileLines oBuffObj[ 10 ]
#define cDelimiter oBuffObj[ 11 ]  //the eol character
#define BUFFLEN 2560
/*
function test( filename )

local oBuffObj1 := binit( filename )

if bopen( oBuffObj1 )
   do while !beof( oBuffObj1 )
      ? breadline( oBuffObj1 )
   enddo
   bclose( oBuffObj1 )
else
   ? 'Cannot open ' + filename
endif

return NIL
*/





*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BInit()
*+
*+    Called from ( click.prg    )   3 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+                ( profile.prg  )   1 - static function init_profile()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BInit(xFileName,xAccMode,ceoline)



// Function BInit( <cFileName>, [nAccessMode] )
// Return:  oBuffObj for this file access
// eol character, cdelimiter, needs to be set by bopen()
default ceoline to ''
return {xFileName,xAccMode,'',- 1,0,.t.,0,.t.,0,0,ceoline}



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function Bopen()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+                ( profile.prg  )   1 - static function init_profile()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+       Calls    ( obufread.prg )   1 - static function bdisk2buff()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function Bopen(oBuffObj)



// Return:   .t. if file was opened
// Assumes:  All file access will be done with the B* functions

default nAccMode to FO_READ   // default access mode is Read Only

nHandle := fopen(cFileName,nAccMode)

nFileBytes := fseek(nHandle,0,FS_END)

fseek(nHandle,0,FS_SET)

BDisk2Buff(oBuffObj)  //read first 2500 bytes into buffer
do case   //update the eol character from file if none is set
case len(alltrim(cDelimiter)) > 0   //oBuffObj[11]
   //keep what was set when calling binit
case chr(13)+chr(10) $ cLineBuffer  //dos
   cDelimiter := chr(13)+chr(10)
case chr(13) $ cLineBuffer  //mac
   cDelimiter := chr(13)
case chr(10) $ cLineBuffer
   cDelimiter := chr(10)  //linux
otherwise   //last choice, use OS default newline
   cDelimiter := HB_OSNewLine()
endcase

return (nHandle != - 1)



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BReadLine()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static function breadpart()
*+                                   3 - static procedure thealigner()
*+                ( declbust.prg )   4 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+                ( profile.prg  )   1 - static function init_profile()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+       Calls    ( obufread.prg )   1 - static function bdisk2buff()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BReadLine(oBuffObj)



// Return:   The next line of the file read buffer
// Assumes:  The file pointer will be moved forward

local ThisLine
local nCrLfAt

do while .t.

   nCrLfAt := at(cDelimiter,cLineBuffer)

   if empty(nCrLfAt) .and. lFullBuff
      BDisk2Buff(oBuffObj)
      loop
   endif

   if empty(nCrLfAt)
      ThisLine    := strtran(cLineBuffer,chr(26))
      cLineBuffer := ''
   else
      ThisLine    := left(cLineBuffer,nCrLfAt - 1)
      cLineBuffer := substr(cLineBuffer,nCrLfAt+len(cDelimiter))
   endif

   exit

enddo

nFileLines ++

return ThisLine   //eof BReadLine()



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BNextLine()
*+
*+    Called from ( click.prg    )   4 - static procedure thealigner()
*+
*+       Calls    ( obufread.prg )   1 - static function bdisk2buff()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BNextLine(oBuffObj)



// Return:   The next line of the file read buffer
// Assumes:  The file pointer will be left as last positioned

local NextLine
local nCrLfAt

//default cDelimiter to chr( 13 ) + chr( 10 ) 5/05

do while .t.

   nCrLfAt := at(cDelimiter,cLineBuffer)

   if empty(nCrLfAt) .and. lFullBuff
      BDisk2Buff(oBuffObj)
      loop
   endif

   if empty(nCrLfAt)
      NextLine := strtran(cLineBuffer,chr(26))
   else
      NextLine := left(cLineBuffer,nCrLfAt - 1)
   endif

   exit

enddo

return NextLine



*+--------------------------------------------------------------------
*+
*+
*+
*+    Static Function BDisk2Buff()
*+
*+    Called from ( obufread.prg )   1 - function bopen()
*+                                   1 - function breadline()
*+                                   1 - function bnextline()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
static function BDisk2Buff(oBuffObj)



// Return:   .t. if there was no read error

static cDiskBuffer := ''

if len(cDiskBuffer) != BUFFLEN
   cDiskBuffer := space(BUFFLEN)
endif

nBytesRead := fread(nHandle,@cDiskBuffer,BUFFLEN)

nTotBytes += nBytesRead   //oBuffObj[7]

lFullBuff := (nBytesRead == BUFFLEN)  //oBuffObj[6]

if lFullBuff
   cLineBuffer += cDiskBuffer   //oBuffObj[3]
else
   cLineBuffer += left(cDiskBuffer,nBytesRead)
endif

return ferror()



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BEof()
*+
*+    Called from ( click.prg    )   3 - procedure click()
*+                                   2 - static function breadpart()
*+                                   2 - static procedure thealigner()
*+                ( declbust.prg )   2 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+                ( profile.prg  )   1 - static function init_profile()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BEof(oBuffObj)



// Return:   TRUE  if End of buffered file
//           FALSE if not

return !lFullBuff .and. len(cLineBuffer) == 0



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BClose()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+                ( profile.prg  )   1 - static function init_profile()
*+                ( readlnk.prg  )   2 - function readlnk()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BClose(oBuffObj)



if lIsOpen
   fclose(nHandle)
   lIsOpen := .f.
endif

oBuffObj := nil

return ferror()



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BPosition()
*+
*+    Called from ( obufread.prg )   1 - function brelative()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BPosition(oBuffObj)



// Returns the position of virtual file pointer

return nTotBytes - len(cLineBuffer)



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BRelative()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+                                   1 - static function breadpart()
*+                                   1 - static procedure thealigner()
*+                ( declbust.prg )   1 - procedure declbust()
*+                ( functrak.prg )   1 - procedure func_text()
*+
*+       Calls    ( obufread.prg )   1 - function bposition()
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BRelative(oBuffObj)



// Returns the percentage of file processed

return BPosition(oBuffObj) / nFileBytes



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BLineNumber()
*+
*+    Called from ( click.prg    )   2 - procedure click()
*+                                   1 - static function breadpart()
*+                                   3 - static procedure thealigner()
*+                ( declbust.prg )   4 - procedure declbust()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BLineNumber(oBuffObj)



// Returns the current line number

return nFileLines



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BGetSet()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BGetSet(oBuffObj)



return aclone(oBuffObj)



*+--------------------------------------------------------------------
*+
*+
*+
*+    Function BRestSet()
*+
*+    Called from ( click.prg    )   1 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
function BRestSet(oBuffObj)



fseek(nHandle,nTotBytes,FS_SET)

return oBuffObj



*+ EOF: obufread.prg
*+
