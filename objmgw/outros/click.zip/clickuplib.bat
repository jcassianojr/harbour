set LIB=d:\devprg\hb\lib\win\bcc\
click /UPDATE
