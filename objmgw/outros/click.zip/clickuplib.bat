click /UPDATE
