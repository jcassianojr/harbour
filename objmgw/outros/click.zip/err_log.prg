*+--------------------------------------------------------------------
*+
*+
*+
*+    Source Module => /home/paul/click/err_log.prg
*+
*+
*+
*+    Click! is a Clipper/Xbase++ source code reformatter.
*+
*+    
*+
*+    Note:Phil is no longer actively developing Click!.
*+
*+    Copyright(C) 1996-1999 by Phil Barnett.
*+
*+       
*+
*+    This program is free software; you can redistribute it and/or modify it
*+
*+    under the terms of the GNU General Public License as published by the
*+
*+    Free Software Foundation; either version 2 of the License, or (at your
*+
*+    option) any later version.
*+
*+    
*+
*+    This program is distributed in the hope that it will be useful, but
*+
*+    WITHOUT ANY WARRANTY; without even the implied warranty of
*+
*+    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*+
*+    General Public License for more details.
*+
*+    
*+
*+    You should have received a copy of the GNU General Public License along
*+
*+    with this program; if not, contact the Free Software Foundation, Inc.,
*+
*+    51 Franklin St, Fifth Floor Boston, MA 02110, USA, or www.fsf.org.
*+
*+    
*+
*+    You can contact me at:
*+
*+    
*+
*+    Phil Barnett
*+
*+    Box 944
*+
*+    Plymouth, Florida  32768
*+
*+    
*+
*+    or
*+
*+    
*+
*+    philb@iag.net
*+
*+    
*+
*+    
*+
*+    Ported to Linux and xHarbour compiler, minor feature additions.
*+
*+    Changed version to 3.00xHarbour  Changes
*+
*+    GPL version 3 Copyright (C) 2006-9 by Paul States 
*+
*+    Contact:broadcastmail AT NOSPAM 123mail.org.
*+
*+
*+
*+    Functions: Procedure err_log()
*+
*+    Reformatted by Click! 3.00Harbour on Apr-13-2009 at  2:30 pm
*+
*+
*+--------------------------------------------------------------------
*+



#include "fileio.ch"



*+--------------------------------------------------------------------
*+
*+
*+
*+    Procedure err_log()
*+
*+    Called from ( click.prg    )  22 - procedure click()
*+
*+
*+
*+
*+--------------------------------------------------------------------
*+
*+
*+
procedure err_log(cTheFile,cTheError)



local nHandle
LOCAL CRLF    := HB_OSNewLine()   //10/03

// writes text to the output file and creates the file if it is missing,
// otherwise appends to the existing file.

if file(cTheFile)
   nHandle := fopen(cTheFile,2)
   fseek(nHandle,0,FS_END)
else
   nHandle := fcreate(cTheFile,0)
endif

if nHandle > - 1
   fwrite(nHandle,cTheError+CRLF)
   fclose(nHandle)
endif

return



*+ EOF: err_log.prg
*+
