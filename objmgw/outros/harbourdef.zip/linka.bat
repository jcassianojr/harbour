REM copy c:\devgit\hb32\include\harbour.hbx
REM localizar e copiar todas hbx
REM copy c:\wutil\cudatext\data\autocomplete\Harbour.acp
REM unix2dos harbour.hbx
REM unix2dos harbour.def
REM unix2dos Harbour.acp
call d:\DEVPRG\hb\hb64msys
hbmk2 hbx -b -lhbmisc -lhbct xhb.hbc d:\develop\harbour\objmgw\f_freadl.prg
