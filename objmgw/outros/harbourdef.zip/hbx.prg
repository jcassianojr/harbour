//-lhbct -lhbmisc

REQUEST DBFCDX
REQUEST HB_CODEPAGE_PTISO


function main()

   Set( _SET_CODEPAGE, "PTISO" )
   SetMode( 25, 80 )
   CLS
   HB_IDLESTATE()
   rddsetdefault( "DBFCDX" )
	Set( _SET_OPTIMIZE, .t.)
	Set( _SET_DELETED, .t.)
	Set( _SET_SOFTSEEK, .t.)
	__SetCentury( .t. )
Set( _SET_EPOCH, year( date() ) - 60 )
Set( _SET_DATEFORMAT, "dd/mm/yyyy" )

cARQUIVO:="LIN"
dbusearea( .T., "DBFCDX", cARQUIVO,, .f. )
ordlistadd( cARQUIVO)
dbsetorder(1) //


//use lin excl
//index on comando to temp

//DELETE ALL FOR TIPO<>"F" .AND. ! EMPTY(TIPO)


//ler os hbx
dbselectar("lin")
IF FILE("harbour.hbx")
   FAZ01("harbour.hbx") //padrao
ENDIF   
mDIRETORIO:=''
mArquivo := '*.HBX'
mListaArq := Directory(mDiretorio+mArquivo,"D")
nFIM:=Len(mListaArq)
For i := 1 to nFIM    
     cARQUIVO:= UPPER(mListaArq[i,1])
     faz01(cARQUIVO)     
NEXT i

IF FILE("Harbour.acp")
   faz03("Harbour.acp")
ENDIF   
limpadup()

//gera o harbour.def
nGRV:=FCREATE("harbour.def")  //pspad context diretorio _complementos(copia reserva e instalacao)
nGR2:=FCREATE("harbour.ini")  //pspad syntax diretorio  _complementos(copia reserva e instalacao)
nGR3:=FCREATE("fnc.ini")      //usado no click

//gravando harini
cUSO:=MEMOREAD("harini.ini")
fwrite(nGR2,cUSO)

dbselectar("lin")
dbgotop()
while ! eof()
    @ 24,00 say LIN->comando
	//IF AT(" |F ",LIN->LINHA)>0
	//   aVALOR=HB_ATOKENS(ALLTRIM(LIN->LINHA),"|")
	//   LIN->TIPO:="F"
	//   IF LEN(aVALOR)>=3
	//      LIN->DESCRICAO:=aVALOR[3]
	//   ENDIF
	//   LIN->LINHA:=ALLTRIM(SUBSTR(aVALOR[2],3))
    //ENDIF
    if LIN->TIPO="F" //! empty(LIN->linha) .AND.
	   //[Bin2w |F Bin2w(cIntSemSinal)|Converte um inteiro com sinal de 16 bits para um valor numerico]
	   //[AAdd |F AAdd(<aTarget>, <expValue>) -> Value ] 
       //AAdd(<aTarget>, <expValue>) -> Value
	   cLINHA:="["
	   cLINHA+=ALLTRIM(TOKENUPPER(LOWER(LIN->COMANDO)))
	   cLINHA+=" |F "
	   cLINHA+=ALLTRIM(LIN->RETORNO)
	   IF ! EMPTY(LIN->DESCRICAO)
			cLINHA+="|"
			cLINHA+=ALLTRIM(LIN->DESCRICAO)
	   endif
	   cLINHA+=" ]"
	   cLINHA+=HB_OSNEWLINE()
       fwrite(ngrv,cLINHA)
       fwrite(ngrv,alltrim(LIN->retorno)+hb_osnewline())
       fwrite(ngrv,+hb_osnewline())
    endif   
    fwrite(ngr2,alltrim(comando)+"="+hb_osnewline())
    if ! empty(hbx)
       fwrite(ngr3,lower(alltrim(comando))+"="+strtran(upper(alltrim(hbx)),".HBX",".LIB")+hb_osnewline())
    endif   
    dbskip()
enddo   
dbcloseall()

//gravando harfim
cUSO:=MEMOREAD("harfim.ini")
fwrite(nGR2,cUSO)

//fechando .ini
fclose(nGRV)
fclose(nGR2)
fclose(nGR3)



function faz01(cARQIMP)
@ 24,65 SAY  cARQIMP
nFile := HB_FUse(cARQIMP)
nLASTREC:=hb_flastrec()
hb_fgotop()
DO WHILE .NOT. HB_FEof()    
   cLINHA:=alltrim(HB_FREADLN())
   @ 24,00 SAY left(cLINHA,60)
   if left(cLINHA,7)="DYNAMIC" 
       cLINHA:=ALLTRIM(UPPER(SUBSTR(cLINHA,9)))
       IF LEFT(cLINHA,1)<>"_" 
          dbgotop()
          if ! dbseek(cLINHA)
             dbappend()
             field->comando:=UPPER(cLINHA)
          endif
          IF EMPTY(HBX)
             FIELD->HBX:=lower(cARQIMP)
          ENDIF
         // IF EMPTY(COMPAD) //quando necessario usar ALLTRIM(TOKENUPPER(LOWER(LIN->COMANDO)))
          //   FIELD->COMPAD:=TOKENUPPER(LOWER(cLINHA))
          //ENDIF
      endif    
  ENDIF     
   HB_FSkip(1) 
enddo
HB_FUse()
return .t.


function faz03(cARQIMP)
@ 24,65 SAY  cARQIMP
nFile := HB_FUse(cARQIMP)
nLASTREC:=hb_flastrec()
hb_fgotop()
DO WHILE .NOT. HB_FEof()    
   cLINHA:=alltrim(HB_FREADLN())
   
   @ 24,00 SAY left(cLINHA,60)
   lGRAVA:=.F.
   cTIPO:=""
   cCOMANDO:=""
   cDESCRICAO:=""
   cRETORNO:=""
   aVALOR:=HB_ATOKENS(cLINHA,"|")
   
   DO CASE
      CASE AT("Function",cLINHA)>0 //Function AAdd( <aArray>[, <xValue>] ) --> Value | Dynamically add an element to an array
           cTIPO:="F"
           cRETORNO:=aVALOR[1]                       //Function AAdd( <aArray>[, <xValue>] ) --> Value
           cRETORNO:=STRTRAN(cRETORNO,"Function","") //AAdd( <aArray>[, <xValue>] ) --> Value
           nPOS:=AT("(",cRETORNO)
           IF nPOS>0
             lGRAVA:=.T.
             cCOMANDO:=SUBSTR(cRETORNO,1,nPOS-1)     //AAdd
           ENDIF
           cDESCRICAO:=aVALOR[2]
      CASE AT("Procedure",cLINHA)>0 //Procedure __Run( <cCommand> ) | Run an external program.
           //ALTD()
           cTIPO:="P"
           cRETORNO:=aVALOR[1]                          //Procedure __Run( <cCommand> ) 
           cRETORNO:=STRTRAN(cRETORNO,"Procedure","")  //__Run( <cCommand> )
           lGRAVA:=.T.
           cCOMANDO:=cRETORNO
           nPOS:=AT("(",cRETORNO)
           IF nPOS>0
              cCOMANDO:=SUBSTR(cRETORNO,1,nPOS-1) //__Run
           ENDIF
           cDESCRICAO:=aVALOR[2]
      CASE AT("Command",cLINHA)>0 //Command AVERAGE        | Average numeric expressions in the current work area
           cTIPO:="C"
           lGRAVA:=.T.
           cDESCRICAO:=aVALOR[2]
           cCOMANDO:=aVALOR[1]
           cCOMANDO:=STRTRAN(cCOMANDO,"Command","")
      CASE AT("Keyword",cLINHA)>0 //Keyword static
           cTIPO:="K"
           lGRAVA:=.T.
           cCOMANDO:=aVALOR[1]
           cCOMANDO:=STRTRAN(cCOMANDO,"Keyword","")
      CASE AT("Preprocessor",cLINHA)>0 //Preprocessor #define |define macrodefinition
           cTIPO:="#"
           lGRAVA:=.T.
           cDESCRICAO:=aVALOR[2]
           cCOMANDO:=aVALOR[1]
           cCOMANDO:=STRTRAN(cCOMANDO,"Preprocessor","")
   ENDCASE
   if lGRAVA
      cDESCRICAO:=ALLTRIM(cDESCRICAO)
      cCOMANDO:=UPPER(ALLTRIM(CCOMANDO))
	  cCOMANDO:=STRTRAN(cCOMANDO,"*","")
      dbgotop()
      if ! dbseek(cCOMANDO)
         dbappend()
         field->comando:=cCOMANDO
      endif
      IF empty(LIN->TIPO) .AND. ! EMPTY(cTIPO)
         LIN->TIPO:=cTIPO
      ENDIF
      IF empty(LIN->DESCRICAO) .AND. ! EMPTY(cDESCRICAO)
         LIN->DESCRICAO:=cDESCRICAO
      ENDIF
      IF empty(LIN->RETORNO) .AND. ! EMPTY(cRETORNO)
         LIN->RETORNO:=cRETORNO
      ENDIF
  ENDIF     
   HB_FSkip(1) 
enddo
HB_FUse()
return .t.


function limpadup()
dbgotop()
while ! eof()
    cCOMANDO:=alltrim(LIN->COMANDO)
	DBSKIP()
	IF ! EOF()
	   IF alltrim(cCOMANDO)==alltrim(lIN->COMANDO)
	      dbdelete()
	   ENDIF
	ENDIF
enddo
pack
return .t.

