PROCEDURE Main()
LOCAL cServer, cUser, cPassword

SetMode( 25, 80 )
   cls


// Passa o nome da se��o exatamente como foi gerado no VB6
cServer   := LerDoCofre( "BANCO", "Server" )
cUser     := LerDoCofre( "BANCO", "User" )
cPassword := LerDoCofre( "BANCO", "Password" )

IF Empty( cServer )
    ? "Erro: Banco nao configurado ou arquivo nao encontrado!"
    WAIT
    QUIT
ENDIF

?? "Conectando ao servidor: " + cServer
?? "Usuario recuperado   : " + cUser
?? "Senha recuperado   : " + cPassword

// Aqui voc� faz a chamada de conex�o usando as vari�veis limpas na mem�ria

WAIT

// Passa o nome da se��o exatamente como foi gerado no VB6
cServer   := LerDoCofre( "BANCO2", "Server" )
cUser     := LerDoCofre( "BANCO2", "User" )
cPassword := LerDoCofre( "BANCO2", "Password" )

IF Empty( cServer )
    ? "Erro: Banco nao configurado ou arquivo nao encontrado!"
    WAIT
    QUIT
ENDIF

? "Conectando ao servidor: " + cServer
? "Usuario recuperado   : " + cUser
?? "Senha recuperado   : " + cPassword
// Aqui voc� faz a chamada de conex�o usando as vari�veis limpas na mem�ria

WAIT

RETURN