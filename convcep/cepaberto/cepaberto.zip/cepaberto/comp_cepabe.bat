rem SET PATH=C:\hb32\bin\..\bin;%PATH%
call C:\hb32\setar32
hbmk2 cepabertorua.prg -q -trace -info -lang=pt_BR -width=512  -compr -strip 
