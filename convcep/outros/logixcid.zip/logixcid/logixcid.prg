#include "adordd.ch"
#include "try.ch"

REQUEST HB_LANG_PT
REQUEST DBFCDX

HB_IDLESTATE()  
HB_LANGSELECT('PT')      
rddsetdefault( "DBFCDX" )
SET OPTIMIZE ON
set deleted on
set softseek on
set date BRITI
set epoch to year( date() ) - 60
set century ON


/*
paises
obf_pais_bacen

uni_feder
obf_estado_ibge

cidades
vdp_cidade_cep
vdp_cidade_fiscal
obf_cidade_ibge
bairros
cep


cod_pais=001 brasil

vdp9113 integrado
vdp3180 pais
vdp3220 estados
vdp3080 cidades

*/

if mdg("gerar paises.sql")
   USE paises
   nUSO:=FCREATE("paises.sql")
   dbgotop()
   WHILE ! EOF()   
      if ! empty(ISO3166B).and.!empty(bacen).and. !empty(nome)
          fwriTe(nuso,"INSERT INTO paises (cod_pais, den_pais, cod_siscomex) VALUES ('"+ISO3166B+"', '"+ALLTRIM(NOME)+"', '"+ALLTRIM(str(BACEN,0))+"');"+hb_osnewline())
      endif       
      DBSKIP()
      @ 24,00 say recno()
   ENDDO
   FCLOSE(nUSO)
   dbcloseall()
endif

if mdg("gerar obf_pais_bacen.sql")
   USE paises
   nUSO:=FCREATE("obf_pais_bacen.sql")
   WHILE ! EOF()
      if ! empty(ISO3166B).and.!empty(bacen).and. !empty(nome)
          fwriTe(nuso,"INSERT INTO paises (pais_logix, pais_bacen) VALUES ('"+ISO3166B+"', "+ALLTRIM(str(BACEN,0))+");"+hb_osnewline())
      endif    
      DBSKIP()
   ENDDO
   FCLOSE(nUSO)
   dbcloseall()
endif

if mdg("gerar uni_feder.sql")
   USE paises
   nUSO:=FCREATE("uni_feder.sql")
   WHILE ! EOF()
      if ! empty(ISO3166B).and.!empty(bacen).and. !empty(nome)
          fwriTe(nuso,"INSERT INTO uni_feder (cod_uni_feder, den_uni_feder, cod_pais, dat_ini_hor_verao, dat_fim_hor_verao) VALUES ('"+ISO3166A+"', '"+ALLTRIM(NOME)+"', '"+ISO3166B+"', NULL, NULL);"+hb_osnewline())
      endif    
      DBSKIP()
   ENDDO
   FCLOSE(nUSO)
   dbcloseall()
ENDIF

if mdg("gerar obf_estado_ibge.sql")
   USE paises
   nUSO:=FCREATE("obf_estado_ibge.sql")
   WHILE ! EOF()
      if ! empty(ISO3166B).and.! empty(bacen).and. ! empty(nome)
          fwriTe(nuso,"INSERT INTO obf_estado_ibge (pais_logix, estado_logix, estado_ibge) VALUES ('"+ISO3166B+"', '"+ISO3166A+"', 0);"+hb_osnewline())
      endif    
      DBSKIP()
   ENDDO
   FCLOSE(nUSO)
   dbcloseall()
endif

Nhandle:=fcreate("erro.txt")
dbusearea( .T., "DBFCDX", "cidconv",, .F. )
ordlistadd( "cidconv" )

dbusearea( .T., "DBFCDX", "md10",, .F. )
ordlistadd( "md10" )

dbusearea( .T., "DBFCDX", "paises",, .F. )
ordlistadd( "paises" )

dbusearea( .T., "DBFCDX", "cepbai",, .F. )
ordlistadd( "cepbai" )

dbusearea( .T., "DBFCDX", "cepbailx",, .F. )
ordlistadd( "cepbailx" )


dbusearea( .T., "DBFCDX", "mdtip",, .F. )
ordlistadd( "mdtip" )


cConn:="Provider=MSDASQL.1;Persist Security Info=False;Data Source=ol_logix"

try
   oConn:=CreateObject( "ADODB.Connection" )
   with object oConn
     :ConnectionString:=cConn
     :Open()
   end

   cCOMANDO:="SET ISOLATION TO DIRTY READ"
   oComm:=CreateObject( "ADODB.Command" )
   with object oComm
     :CommandText:=cCOMANDO
     :CommandType:=adCmdText
     :ActiveConnection:=oConn
     :Execute()
   end
catch oErr
     ShowAdoError(oERR,oCon,cCOMANDO) 
end SEQUENCE

oRegistro:= CreateObject('ADODB.RecordSet')
oRegistro:CursorLocation := 3

cCOMANDO:=" select cidades.*,CAST(obf_cidade_ibge.cidade_ibge AS CHAR(7))  AS codibge "
cCOMANDO+=" from cidades "
cCOMANDO+=" LEFT JOIN obf_cidade_ibge ON cidades.cod_cidade=obf_cidade_ibge.cidade_logix "
cCOMANDO+=" order by COD_UNI_FEDER,DEN_CIDADE,COD_CIDADE "

TRY
   oRegistro:Open(cCOMANDO, oConN, adOpenForwardOnly,adLockReadOnly) 
catch oErr
    ShowAdoError(oERR,oConn,cCOMANDO)
END SEQUENCE


aERRO:={}
aCID:={}
aCOD:={}   
aIBGE:={}
WHILE .NOT. oregistro:eof
   mCOD_CIDADE:=oregistro:fields("COD_CIDADE"):value
   mCOD_UNI_FE:=oregistro:fields("COD_UNI_FEDER"):value
   mDEN_CIDADE:=oregistro:fields("DEN_CIDADE"):value 
   mDEN_CIDADE:=TRATANOME(mDEN_CIDADE)   
   mCODIBGE   :=fixstr(oregistro:fields("codibge"):value)
   AADD(aCID,mCOD_UNI_FE+mDEN_CIDADE)
   AADD(aCOD,mCOD_CIDADE) 
   AADD(aIBGE,mCODIBGE)
   dbselectar("cidconv")
   dbgotop()
   if dbseek(mCOD_UNI_FE+mDEN_CIDADE,.f.) //nome errado
      if len(alltrim(mDEN_CIDADE))=len(alltrim(CIDori)) .and. PADR(mDEN_CIDADE,30)<>PADR(CIDDES,30) .and. len(alltrim(mDEN_CIDADE))<>len(alltrim(CIDDES))
         AADD(aERRO,mCOD_UNI_FE+alltrim(CIDDES))
         fwrite(nhandle,"Nome Errado:"+mCOD_CIDADE+" "+mDEN_CIDADE+"-->"+CIDDES+hb_osnewline())         
      ENDIF   
   endif   
   dbselectar("MD10")
   dbsetorder(1)
   dbgotop()
   if ! dbseek(mCOD_UNI_FE+mDEN_CIDADE) //cidade Inexistente
      dbselectar("MD10")
      dbsetorder(3)
      dbgotop()
      if ! dbseek(mCODIBGE) //ibge inexistente
         dbselectar("paises") //verifica se nao e uf exportacao
         dbgotop()
         IF ! dbseek(mCOD_UNI_FE)          
            fwrite(nhandle,"Apagar:"+mCOD_CIDADE+" "+mDEN_CIDADE+hb_osnewline())
         ENDIF   
      endif   
   endif
   
   oRegistro:MoveNext()
   if ! oregistro:eof
       cCOD_CIDADE:=oregistro:fields("COD_CIDADE"):value
       cCOD_UNI_FE:=oregistro:fields("COD_UNI_FEDER"):value
       cDEN_CIDADE:=oregistro:fields("DEN_CIDADE"):value 
       cDEN_CIDADE:=TRATANOME(cDEN_CIDADE)  
       if mCOD_UNI_FE=cCOD_UNI_FE.and.PADR(mDEN_CIDADE,30)=PADR(cDEN_CIDADE,30).and.len(alltrim(mDEN_CIDADE))=len(alltrim(cDEN_CIDADE)) //duplicado
          fwrite(nhandle,"Duplicado:"+mCOD_CIDADE+" "+mCOD_UNI_FE+" "+mDEN_CIDADE+"="+cCOD_CIDADE+" "+cCOD_UNI_FE+" "+cDEN_CIDADE+hb_osnewline())      
      endif 
   endif  	
enddo
oRegistro:CLOSE()
fclose(Nhandle)


aUSO:={}
aUS2:={}
dbselectar("MD10")
//SET FILTER TO CORTIP='M'  .AND. ! EMPTY(CODIBGE) //somente municipios com ibge CORTIP='M' .AND. ! EMPTY(CODIBGE) md10 agora somente municipios com ibge
dbsetorder(1)
dbgotop()
while ! eof()
    mUF     :=UF
    mCIDADE :=ALLTRIM(NOME)
    mINICEP :=INICEP
    mFIMCEP :=FIMCEP
    mCODIBGE:=CODIBGE
    mLOGIX  :=LOGIX
    nPOS:=ASCAN(aCID,mUF+LEFT(mCIDADE,30))
    IF nPOS=0        
       AADD(aUSO,{mUF,mCIDADE,mINICEP,mFIMCEP,mCODIBGE}) //cidade nao cadastrada
    ELSE       
       IF EMPTY(LOGIX) .AND. LEN(ALLTRIM(mUF+mCIDADE))=LEN(ALLTRIM(aCID[nPOS]))
          FIELD->LOGIX:=aCOD[nPOS]
       ENDIF   
    ENDIF 
    IF ! EMPTY(mCODIBGE) .AND. ! EMPTY(mLOGIX)
       nPOS:=ASCAN(aIBGE,mCODIBGE)
       IF nPOS=0
          AADD(aUS2,{mUF,mLOGIX,mCODIBGE})
       ENDIF
    ENDIF
    dbselectar("MD10")
    dbskip()
enddo
dbselectar("MD10")
set filter to


Nhandle:=fcreate("cidades.sql")            
nHANDL2:=fcreate("vdp_cidade_cep.sql")
nHANDL3:=fcreate("obf_cidade_ibge.sql")
nHANDL4:=fcreate("vdp_cidade_fiscal.sql")     //implantar
for x=1 to len(auso)  //inclui cidades nao cadastradas
    @ 24,00 say aUSO[X][1]+"/"+aUSO[X][2]
    nCONTA:=0
    lTEM:=.T.
    cCOD:=""
    WHILE ASCAN(aCOD,aUSO[X][1]+STRZERO(nCONTA,3))>0
        @ 24,30 say strzero(nCONTA,8)
        nCONTA++
        IF nCONTA=999
           lTEM:=.F.
           EXIT
        ENDIF
    enddo
    cCOD:=aUSO[X][1]+STRZERO(nCONTA,3)
    IF ! lTEM
       nCONTA:=1
       WHILE ASCAN(aCOD,aUSO[X][1]+"X"+STRZERO(nCONTA,2))>0
          @ 24,30 say strzero(nCONTA,8)
          nCONTA++
          IF nCONTA=99
              lTEM:=.F.
              EXIT
          ENDIF
       enddo
       cCOD:=aUSO[X][1]+"X"+STRZERO(nCONTA,2)
    ENDIF
    IF ! lTEM
       nCONTA:=1
       WHILE ASCAN(aCOD,aUSO[X][1]+"Y"+STRZERO(nCONTA,2))>0
          @ 24,30 say strzero(nCONTA,8)
          nCONTA++
          IF nCONTA=99
              lTEM:=.F.
              EXIT
          ENDIF
       enddo
       cCOD:=aUSO[X][1]+"Y"+STRZERO(nCONTA,2)
    ENDIF

    
    AADD(aCOD,cCOD)
    cCEPINI:=LEFT(aUSO[X][3],5)+"-000" 
    cCEPFIM:=LEFT(aUSO[X][4],5)+"-999" 
    
    fwrite(nHANDLE,"INSERT INTO cidades (cod_cidade, den_cidade, cod_uni_feder) VALUES ('"+cCOD+"', '"+LEFT(aUSO[X][2],30)+"', '"+aUSO[X][1]+"');"+hb_osnewline())
    fwrite(nhandl2,"INSERT INTO vdp_cidade_cep (cidade, cep_inicial, cep_final) VALUES ('"+cCOD+"', '"+cCEPINI+"', '"+cCEPFIM+"');"+hb_osnewline())
    
    if ! empty(aUSO[X][5])
       fwrite(nhandl3,"INSERT INTO obf_cidade_ibge (estado_logix, cidade_logix, cidade_ibge) VALUES ('"+aUSO[X][1]+"', '"+cCOD+"', "+aUSO[X][5]+");"+hb_osnewline()) 
    endif   
next x
for x=1 to len(aus2)
   fwrite(nhandl3,"INSERT INTO obf_cidade_ibge (estado_logix, cidade_logix, cidade_ibge) VALUES ('"+aUS2[X][1]+"', '"+aUS2[X][2]+"', "+aUS2[X][3]+");"+hb_osnewline()) 
next x


//SELECT * FROM  cidades WHERE cod_cidade NOT IN (SELECT cidaDE_LOGIX FROM obf_cidade_ibge) AND cod_uni_feder='RS' pegar estado  pois tem uf exportacao
fwrite(nhandl2,"delete FROM vdp_cidade_cep WHERE cidade NOT IN (SELECT cod_cidade FROM cidades) ;"+hb_osnewline())
fwrite(nhandl3,"delete FROM obf_cidade_ibge WHERE cidade_logix NOT IN (SELECT cod_cidade FROM cidades)  ;"+hb_osnewline())
fwrite(nhandl4,"delete FROM vdp_cidade_fiscal WHERE cidade NOT IN (SELECT cod_cidade FROM cidades) ;"+hb_osnewline())


fclose(Nhandle)
fclose(nhandl2)
fclose(nHANDL3)
fclose(nHANDL4)


if mdg("gerar bairros.sql")
   @ 24,00 SAY PADR("",80)
   nHANDLE:=FCREATE("bairros.sql")
   dbselectar("cepbai")
   dbsetorder(2) // antigo 3 cep_nu_seq nome bairro agora index 2 nome_bairro
   
   dbselectar("MD10")
   dbgotop()
   while ! eof()   
      if ! empty(logix) 
         //mCEPSEQ:=CODIBGE //CEPNUSEQ //agora usa-se codibge
         mCODIBGE:=CODIBGE
         mCODCID:=LOGIX
         @ 24,00 say mCODCID
         aBAIRRO:={}
         aCOD:={}
         aIBGE:={}
         aCHAVE:={}
         nCONTA:=1
         cCOMANDO:="select * "
         cCOMANDO+=" from bairros,CAST(obf_cidade_ibge.cidade_ibge AS CHAR(7))  AS codibge "
         cCOMANDO+=" LEFT JOIN obf_cidade_ibge ON bairros.cod_cidade=obf_cidade_ibge.cidade_logix "
         cCOMANDO+=" where bairros.cod_cidade='"+mCODCID+"'" 
         TRY
           oRegistro:Open(cCOMANDO, oConN, adOpenForwardOnly,adLockReadOnly) 
         catch oErr
           ShowAdoError(oERR,oConn,cCOMANDO)
         END  SEQUENCE
         WHILE .NOT. oregistro:eof
              mNOMEBAIRRO:=fixstr(oregistro:fields("DEN_BAIRRO"):value)
              cCODBAIRRO:=fixstr(oregistro:fields("COD_BAIRRO"):value)
              cIBGE:=FIXSTR(oregistro:fields("codibge"):value)
              aadd(aCOD,cCODBAIRRO)
              aadd(aBAIRRO,mNOMEBAIRRO)
              aadd(aIBGE,cIBGE)
              aadd(aCHAVE,0)
              oRegistro:MoveNext()
         enddo
         oRegistro:CLOSE()
         
         nFIMBAI:=LEN(aCOD)
         FOR XB:=1 TO nFIMBAI
           nBAI_NU_NEW:=0
           dbselectar("cepbai")
           dbsetorder(2)
           dbgotop()
           if dbseek(aBAIRRO[XB])
              nBAI_NU_NEW:=cepbai->bai_nu_seq
           endif
           
           if nBAI_NU_NEW>0
              eBUSCA:=aIBGE[XB]+STR(nBAI_NU_NEW,7) 
              dbselectar("cepbailx")
              dbgotop()
              if ! dbseek(eBUSCA)
                 dbappend()
                 cepbailx->BAI_NU_NEW :=nBAI_NU_NEW
                 cepbailx->CODIBGE    :=aIBGE[XB]
                 cepbailx->CODBAILX   :=aCOD[XB]
               ELSE
                 IF EMPTY(cepbailx->CODBAILX)
                    netreclock()
                    cepbailx->CODBAILX   :=aCOD[XB]
                 ENDIF  
              endif
              dbunlock()
          endif
         NEXT XB
         
           dbselectar("cepbailx")
           dbgotop()
           dbseek(mCODIBGE)
           WHILE mCODIBGE=cepbailx->CODIBGE .AND.! EOF()
             //  mNOME:=ALLTRIM(BAI_NO_ABR)
             //  IF LEN(ALLTRIM(BAI_NO))<=30
                  mNOME:=ALLTRIM(BAI_NO) //agora so nome base de ceps nao te mais o reduzido
             //  ENDIF
               mNOME:=TRATANOME(mNOME)
               mNOME:=PADR(mNOME,30)           
               @ 24,40 say Mnome
               nPOSBAI:=ASCAN(aBAIRRO,MNOME)
               IF nPOSBAI=0
                  WHILE ASCAN(aCOD,nCONTA)>0
                      nCONTA++
                  ENDDO                          
                  fwrite(nhandle,"INSERT INTO bairros (cod_cidade, cod_bairro, den_bairro) VALUES ('"+mCODCID+"',"+str(nCONTA,4)+" , '"+alltrim(mNOME)+"');"+hb_osnewline())
                  aadd(Acod   ,nCONTA)
                  aadd(aBAIRRO,MnoME)
               ELSE
                  IF EMPTY(field->CODBAILX)
                    netreclock()
                    field->CODBAILX:=aCOD[nPOSBAI]  
                  ENDIF                
                ENDIF
               dbskip()
           enddo
           
           
          
      endif
      dbselectar("MD10")
      dbskip()
   enddo
   fclose(nhandle)
endif

if mdg("Checar ceps")
   //o nome  do bairro ficam com ? pois o logix nao aceita em branco para quando tiver o gravar
   aCEP:={}
   aBAICEP:={}
   aBAIEND:={}
   cCOMANDO:="select to_char(cep) as cep,den_bairro,den_rua  from cep" //to_char(cep) strzero(cep,8) abaixo prg
   TRY
      oRegistro:Open(cCOMANDO, oConN, adOpenForwardOnly,adLockReadOnly) 
   catch oErr
      ShowAdoError(oERR,oConn,cCOMANDO)
   END SEQUENCE

   WHILE .NOT. oregistro:eof      
       cCEP:=oregistro:fields("CEP"):value    
       cCEP:=STRZERO(VAL(cCEP),8,0)
       @ 24,00 SAY cCEP
       aadd(aCEP,cCEP)  
       if oregistro:fields("den_bairro"):value="?"
          aadd(aBAICEP,cCEP) 
       endif  
       if len(fixstr(oregistro:fields("den_rua"):value))=0
          aadd(aBAIEND,cCEP) 
       endif  
       oRegistro:MoveNext()
   enddo
   oRegistro:CLOSE()



   nhandle:=fcreate("cep.sql")
   dbselectar("mdtip")
   dbsetorder(2)
   dbselectar("MD10")
   dbgotop()
   while ! eof() 
      mUF:=UF
      mNOME:=NOME
      @ 24,00 SAY mUF+"-"+mNOME
      cARQRUA := "C" + strzero( CEPNUSEQ, 6 )
      if file( cARQRUA + ".DBF" )
         use &cARQRUA NEW SHARED
         dbgotop()
         while ! eof()
            nBAIRRO:=CHVBAI
            cBAIRRO:=" "
            cTIPO:=TIPO
            dbselectar("cepbai")
            dbgotop()
            if dbseek(nbairro)
               cBAIRRO:=ALLTRIM(BAI_NO_ABR)
               IF LEN(ALLTRIM(BAI_NO))<=30
                  cBAIRRO:=ALLTRIM(BAI_NO)
               ENDIF
            endif
            dbselectar("mdtip")
            dbgotop()
            if dbseek(alltrim(cTIPO))
               cTIPO:=CODIGO
            endif
            if empty(cBAIRRO)
               cBAIRRO:="?"
            endif
            dbselectar(cARQRUA)
            cCEP:=CEP
            @ 24,40 say cCEP         
            cRUA:=ALLTRIM(PADR(tratanome(ALLTRIM(TIPO)+" "+ALLTRIM(RUA)),50))
            cBAIRRO:=ALLTRIM(PADR(tratanome(cBAIRRO),30))
            cNOME:=ALLTRIM(PADR(tratanome(mNOME),50)) 
            cTIPO:=alltrim(PADR(cTIPO,5))
            cLINHA:=cCEP+"|"
            cLINHA+=cRUA+"|"
            cLINHA+=cBAIRRO+"|"
            cLINHA+=cNOME+"|"
            cLINHA+=mUF+"|"
            cLINHA+=cTIPO+"|"
            cLINHA+="0|"
            cLINHA+="0|"
            cLINHA+="999999|"
            cLINHA+="999999|"
            cLINHA+=PARID
            IF ASCAN(ACEP,CEP)=0         
               fwrite(nhandle,"INSERT INTO cep (cep, den_rua, den_bairro, den_cidade, cod_uni_feder, tipo_rua, inicio_impar, inicio_par, final_impar, final_par, lado_rua)  VALUES ("+cCEP+", '"+cRUA+"', '"+cBAIRRO+"', '"+cNOME+"', '"+mUF+"', '"+cTIPO+"', 0, 0, 999999, 999999, '');"+hb_osnewline())                  
            endif
            IF ! EMPTY(cRUA)
               nPOS:=ASCAN(ABAIEND,cCEP)
               IF npOS>0         
                  fwrite(nhandle," update cep set den_rua='"+cRUA+"' where cep="+cCEP+" ;"+HB_OSNEWLINE())
                  adel(aBAIEND,nPOS)
               endif   
            ENDIF			
            IF cBAIRRO<>"?" //o nome  do bairro ficam com ? pois o logix nao aceita em branco para quando tiver o gravar
               nPOS:=ASCAN(ABAICEP,cCEP)
               IF npOS>0         
                  fwrite(nhandle," update cep set den_bairro='"+cBAIRRO+"' where cep="+cCEP+" ;"+HB_OSNEWLINE())
                  adel(aBAICEP,nPOS)
               endif   
            ENDIF                  
            dbskip()
         enddo   
         dbclosearea()
      endif
      dbselectar("MD10")
      DBSKIP()
   ENDDO
endif   
dbcloseall()

aTABELA:={"paises","obf_pais_bacen","uni_feder","obf_estado_ibge","cidades","vdp_cidade_cep","vdp_cidade_fiscal","obf_cidade_ibge","cep","bairros"}
FOR X=1 TO 10
   with object oComm
     :CommandText:="UPDATE statistics FOR TABLE "+aTABELA[X]
     :CommandType:=adCmdText
     :ActiveConnection:=oConn
     :Execute()
   end
NEXT X   



funcTION tratanome(mNOME)
mNOME     := strtran( alltrim( mNOME ), "'", " " )     //tirar como d'agua d'olho
mNOME     := strtran( mNOME, "  ", " " )               //tirar os duplos espacos
mNOME     := strtran( mNOME, "-", " " )               //tirar os tracos
mNOME     := strtran( mNOME, "  ", " " )               //tirar os duplos espacos
mNOME     := strtran( mNOME, ".", " " )               //tirar os .
mNOME     := strtran( mNOME, ",", " " )               //tirar os ,
mNOME     := strtran( mNOME, "�", "C" )               //tirar os �
mNOME     := strtran( mNOME, "�", "c" )               //tirar os �
mNOME     := strtran( mNOME, "  ", " " )               //tirar os duplos espacos
mNOME:=RANGEREPL(chr(0)  ,chr(31) ,mNOME," ")
mNOME:=RANGEREPL(chr(127),chr(255),mNOME," ")   
mNOME     := ALLTRIM(UPPER(mNOME))
RETURN mNOME


FUNCTION ShowAdoError(oERR,oCon,cMESSAGE)
LOCAL   nAdoErrors   := 0
LOCAL   oAdoErr
LOCAL   cERRO

      nAdoErrors   :=  oCon:Errors:Count()
      IF nAdoErrors > 0
         oAdoErr      := oCon:Errors(nAdoErrors-1)
         cERRO:= oAdoErr:Description + HB_OsNewLine() + oAdoErr:Source 
         cERRO+= oCon:ConnectionString   + HB_OsNewLine()
         cERRO+= HB_VALTOEXP(oCon:Provider)   + HB_OsNewLine()
         cERRO+= HB_VALTOEXP(oCon:State)   + HB_OsNewLine()
      ELSE
         cERRO:= 'Outros Erros'
      ENDIF
      IF VALTYPE(cMESSAGE)="C"
         cERRO+=HB_OsNewLine()+ cMESSAGE
      ENDIF
      cERRO+=HB_OsNewLine()+oErr:Operation + " " + oErr:Description
      hb_memowrit("showadoerror"+ArqLogDataHora("log"),cERRO)
      alert(cERRO)
RETURN nil


//function TIRAOUT( TEXTO )
//texto := strtran( texto, ".", "" )
//texto := strtran( texto, ":", "" )
//texto := strtran( texto, "-", "" )
//texto := strtran( texto, "/", "" )
//return texto    
