rem SET PATH=C:\hb32\bin\..\bin;%PATH%
call C:\devprg\hb64mgw10\hb64mgw10
hbmk2 LOGIXCID.hbp
rem -q -trace -info -lang=pt_BR -width=512  -compr -strip 
