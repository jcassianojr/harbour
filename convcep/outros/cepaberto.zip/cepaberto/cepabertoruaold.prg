//REQUEST HB_LANG_PT
REQUEST HB_CODEPAGE_PTISO

//REQUEST HB_CODEPAGE_PT850
REQUEST DBFCDX

function main()

HB_IDLESTATE()
Set( _SET_CODEPAGE, "PTISO")    
//HB_LANGSELECT('PT') 
//HB_SETCODEPAGE('PT850')
//hb_cdpSelect( "PT850" )
    
rddsetdefault( "DBFCDX" )
Set( _SET_OPTIMIZE, .t.)
Set( _SET_DELETED, .t.)
Set( _SET_SOFTSEEK, .t.)
__SetCentury( .t. )
Set( _SET_EPOCH, year( date() ) - 60 )
Set( _SET_DATEFORMAT, "dd/mm/yyyy" )


setmode(25,80)

use cepruaimp new
zap
dbclosearea()

altd()
nUSO:=FCREATE("erro.txt")
aESTADOS:={"AC","AL","SP","AM","BA","ES","MG","MS","MT","PA","RS","SC","SE","RO","PI","PE","PB","GO","DF","CE","AP","PR"}
nFIMEST:=LEN(aESTADOS)
FOR ZEST=1 TO  nFIMEST
   FOR ZARQ=1 TO 1
       caRQUIVO:=aESTADOS[ZEST]+"_cepaberto_parte_"+str(zarq,1)
	   IF FILE(cARQUIVO+".DBF")
	      FAZER(carquivo)
		  caRQUIVO:=aESTADOS[ZEST]+"_cepaberto_parte_"+str(zarq,1)+".DBF"
		  FERASE(cARQUIVO)
		  caRQUIVO:=aESTADOS[ZEST]+"_cepaberto_parte_"+str(zarq,1)+".CDX"
		  FERASE(cARQUIVO)
	   ENDIF
   NEXT ZARQ
NEXT ZEST   
IF FILE("cepaberto.dbf") //arquivo unico com append file pspad //incluir cabecario n1,n2 no oppenoffice n5,n4,n1 formatar colunha numero inteiro
   FAZER("cepaberto")
endif

FCLOSE(nUSO)

function fazer(carq)
use &carq. new shared
//index on str(n6,2)+str(n5,4)+str(n1,7) tag ufcidade
nLASTREC:=LASTREC()

use cities new
INDEX ON ID TO CITIES

use states new
INDEX ON ID TO STATES

use cepruaimp new

cARQUIVO:="MD10"
dbusearea( .T., "DBFCDX", cARQUIVO,, .T. )
ordlistadd( cARQUIVO)
dbsetorder(1) //

cARQUIVO:="MD05"
dbusearea( .T., "DBFCDX", cARQUIVO,, .T. )
ordlistadd( cARQUIVO)
dbsetorder(1) //

cARQUIVO:="CIDCONV"
dbusearea( .T., "DBFCDX", cARQUIVO,, .T. )
ordlistadd( cARQUIVO)
dbsetorder(1) //


cARQUIVO:="CEPBAI"
dbusearea( .T., "DBFCDX", cARQUIVO,, .T. )
ordlistadd( cARQUIVO)
dbsetorder(4) // localcep + nome


dbselectar(cARQ)
dbgotop()
while ! eof() 


	//69900001,Beco Estado do Acre, ,Base,7735,1
   // 1           2               3 4     5  6 
	//1           2                   3                                4   5   6   
	//30110005,Avenida do Contorno,- de 1193 a 1825 - lado �mpar,Floresta,1126,11
	


  // cCEP:=strzero(n1,8)
  // cNOME:=upper(TRATANOME(n2))
  // cOBS:=upper(TRATANOME(n3))   
  // cBAIRRO:=upper(TRATANOME(n4))      
   nidcid:=n5
   if valtype(nidcid)="C"
       nidcid:=val(nidcid)
   endif
   niduf :=n6
   if valtype(niduf)="C"
       niduf:=val(niduf)
   endif


   
   cUF      :=""
   dbselectar("states")
   dbgotop()
   if dbseek(niduf)
      Cuf:=states->uf
   endif
   
   cCIDADE:=""
   dbselectar("cities")
   dbgotop()
   if dbseek(nidcid)
      cCIDADE:=upper(TRATANOME(cities->nome))
   endif   
   
   
   //eBUSCA   :=cUF+cCIDADE
   //eLOCALCEP:=0
   //eLOCALBAI:=0
   
   
   //dbselectar(cARQ)
  // @ 24,00 say  cUF+ cCIDADE + STR(RECNO()) + "/" + STR(nLASTREC)   
   dbselectar("MD10")
   dbgotop()
   if dbseek(eBUSCA)
      eLOCALCEP:=CODIBGE //CEPNUSEQ     agora ibge
   endif
   if eLOCALCEP=0
      dbselectar("cidconv")
      dbgotop()
      if dbseek(eBUSCA)
         eBUSCA:=ESTDES+CIDDES
      ENDIF
      dbselectar("MD10")
      dbgotop()
      if dbseek(eBUSCA)
         eLOCALCEP:=CODIBGE //CEPNUSEQ     agora ibge
      endif      
   endif
   if val(eLOCALCEP)=0
      dbselectar("md05")
      dbgotop()
      if dbseek(cUF)
         IF LEN(eBUSCA)>10
            fwrite(nUSO,eBUSCA+HB_OSNEWLINE())   
         endif   
      endif   
   ENDIF
   dbselectar(cARQ)
   
   lCEPRUA:=.F.
   //cepruaimp fara a importacao nao mas gravara diretos na cep
   ////cARQRUA := "C"+eLOCALCEP //+ strzero( eLOCALCEP, 6 ) agoraibge
   ////if file( cARQRUA + ".cdx" ) .and. file( cARQRUA + ".cdx" )
   //   lCEPRUA:=.T.
   //   dbusearea( .T., "DBFCDX", cARQRUA,, .T. )
   //   ordlistadd( cARQRUA)
   //   dbsetorder(2) //      cep
   //endif   
   dbselectar(cARQ)
   while IF(valytpe,niduF=n6 .AND. nidcid=n5,niduF=VAL(n6) .AND. nidcid=val(n5) .AND. ! EOF()
       if valtype(n1)="N"
          cCEP:=strzero(n1,8)
       ELSE
          cCEP:=n1
       endif
       cNOME:=upper(TRATANOME(n2))
       cOBS:=upper(TRATANOME(n3))   
       cBAIRRO:=upper(TRATANOME(n4))      
	   nCHVBAI:=0

      @ 24,00 say  cUF+ cCIDADE + cCEP + STR(RECNO()) + "/" + STR(nLASTREC)
      IF eLOCAlCEP>0 .AND. lCEPRUA                     
         dbselectar(cARQRUA)
         dbgotop()
         IF ! dbseek(cCEP)            
            dbappend()
            FIELD->CEP:=cCEP            
			fwrite(nUSO,"Incluido: "+cARQRUA+" "+cCep+HB_OSNEWLINE())   
         ELSE
            dbrlock()
         ENDIF
         if empty(field->rua)
            field->rua:=cNOME
         endif
	
         if empty(field->chvbai) .AND. ! EMPTY(cBAIRRO)            
            nCHVBAI:=0
            eBUSCA:=STR(eLOCALCEP,7)+TRATANOME(cBAIRRO)
            dbselectar("cepbai")
            dbsetorder(2)  //dbsetorder(4) // nome bairro //cepbai simpilicado somente o nome
            dbgotop()
            if dbseek(eBUSCA)               
               nCHVBAI:=bai_nu_seq
            endif
            dbselectar(cARQRUA)
            IF nCHVBAI>0
               field->chvbai:=nCHVBAI 
            ENDIF
         endif
         /* as bases de ceps nao tem mais o abreviado
         if empty(field->chvbai) .AND. ! EMPTY(cBAIRRO)            
            nCHVBAI:=0
            eBUSCA:=STR(eLOCALCEP,7)+TRATANOME(cBAIRRO)
            dbselectar("cepbai")
            dbsetorder(5) // nome bairro abreviado
            dbgotop()
            if dbseek(eBUSCA)               
               nCHVBAI:=bai_nu_seq
            endif
            dbselectar(cARQRUA)
            IF nCHVBAI>0
               field->chvbai:=nCHVBAI 
            ENDIF
         endif
         */
      ENDIF   
         
         
         DBUNLOCK()
		  dbselectar("cepruaimp")
		  dbappend()
          FIELD->CEP:=cCEP
	      FIELD->RUA:=cNOME
	      FIELD->OBS:=cOBS
	      FIELD->BAIRRO:=cBAIRRO
          FIELD->UF:=cUF
	      FIELD->CIDADE:=cCIDADE
          FIELD->CHVBAI:=nCHVBAI 
	  
	  dbselectar(cARQ)
      dbskip()
   enddo
   //grava somente na cepruaimp para importacao posterior   
//   if lCEPRUA
 //     dbselectar(cARQRUA)
 //     dbclosearea()
 //  ENDIF
   dbselectar(cARQ)
enddo
dbcloseall()


function TIRAOUT( TEXTO )
texto := strtran( texto, ".", "" )
texto := strtran( texto, ":", "" )
texto := strtran( texto, "-", "" )
texto := strtran( texto, "/", "" )
return texto    


function tratanome(cNOME)
LOCAL npOS
cNOME:=ALLTRIM(cNOME)
npOS:=AT("(",cNOME)
IF npOS>0   
   cNOME:=SUBSTR(cNOME,1,nPOS-1)
   cNOME:=ALLTRIM(cNOME)
ENDIF
cNOME:=STRTRAN(cNOME,"&39;"," ")
cNOME:=STRTRAN(cNOME,"-"," ")
cNOME:=STRTRAN(cNOME,"'"," ")
RETURN cNOME