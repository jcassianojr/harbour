REQUEST HB_LANG_PT
REQUEST HB_CODEPAGE_PTISO
REQUEST DBFCDX

function main()

HB_IDLESTATE()
Set( _SET_CODEPAGE, "PTISO")    
HB_LANGSELECT('PT') 
    
rddsetdefault( "DBFCDX" )
Set( _SET_OPTIMIZE, .t.)
Set( _SET_DELETED, .t.)
Set( _SET_SOFTSEEK, .t.)
__SetCentury( .t. )
Set( _SET_EPOCH, year( date() ) - 60 )
Set( _SET_DATEFORMAT, "dd/mm/yyyy" )


setmode(25,80)

use cepruaimp new
zap

use cities new
INDEX ON ID TO CITIES

use states new
INDEX ON ID TO STATES

aESTADOS:={"AC","AL","SP","AM","BA","ES","MG","MS","MT","PA","RS","SC","SE","RO","PI","PE","PB","GO","DF","CE","AP","PR"}
nFIMEST:=LEN(aESTADOS)
FOR ZEST=1 TO  nFIMEST
       caRQUIVO:=aESTADOS[ZEST]+"_cepaberto"
	   IF FILE(cARQUIVO+".DBF")
	      FAZER(carquivo)
	   ENDIF
NEXT ZEST   
IF FILE("cepaberto.dbf") 
   FAZER("cepaberto")
endif
dbcloseall()

function fazer(carq)
use &carq. new shared
nLASTREC:=LASTREC()

dbselectar(cARQ)
dbgotop()
while ! eof() 
	//69900001,Beco Estado do Acre, ,Base,7735,1
   // 1           2               3 4     5  6 
	//1           2                   3                                4   5   6   
	//30110005,Avenida do Contorno,- de 1193 a 1825 - lado �mpar,Floresta,1126,11

   nidcid:=field->n5
   if valtype(nidcid)="C"
       nidcid:=val(nidcid)
   endif
   niduf :=field->n6
   if valtype(niduf)="C"
       niduf:=val(niduf)
   endif

   cUF      :=""
   dbselectar("states")
   dbgotop()
   if dbseek(niduf)
      Cuf:=states->uf
   endif
   
   cCIDADE:=""
   dbselectar("cities")
   dbgotop()
   if dbseek(nidcid)
      cCIDADE:=upper(TRATANOME(cities->nome))
   endif   
   
   
   dbselectar(cARQ)
   if valtype(field->n1)="N"
      cCEP:=strzero(field->n1,8)
   ELSE
      cCEP:=field->n1
   endif
   cNOME:=upper(TRATANOME(field->n2))
   cOBS:=upper(TRATANOME(field->n3))   
   cBAIRRO:=upper(TRATANOME(field->n4))      
     
     
   dbselectar("cepruaimp")
   dbappend()
   cepruaimp->CEP:=cCEP
   cepruaimp->RUA:=cNOME
   cepruaimp->OBS:=cOBS
   cepruaimp->BAIRRO:=cBAIRRO
   cepruaimp->UF:=cUF
   cepruaimp->CIDADE:=cCIDADE
 	  
   dbselectar(cARQ)
   dbskip()
enddo
dbselectar(cARQ)
dbclosearea()


function TIRAOUT( TEXTO )
texto := strtran( texto, ".", "" )
texto := strtran( texto, ":", "" )
texto := strtran( texto, "-", "" )
texto := strtran( texto, "/", "" )
return texto    


function tratanome(cNOME)
LOCAL npOS
cNOME:=ALLTRIM(cNOME)
npOS:=AT("(",cNOME)
IF npOS>0   
   cNOME:=SUBSTR(cNOME,1,nPOS-1)
   cNOME:=ALLTRIM(cNOME)
ENDIF
cNOME:=STRTRAN(cNOME,"&39;"," ")
cNOME:=STRTRAN(cNOME,"-"," ")
cNOME:=STRTRAN(cNOME,"'"," ")
RETURN cNOME