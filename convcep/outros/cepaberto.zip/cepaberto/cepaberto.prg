REQUEST HB_LANG_PT
REQUEST HB_CODEPAGE_PTISO
REQUEST DBFCDX

function main()

HB_IDLESTATE()
Set( _SET_CODEPAGE, "PTISO")    
HB_LANGSELECT('PT') 
    
rddsetdefault( "DBFCDX" )
Set( _SET_OPTIMIZE, .t.)
Set( _SET_DELETED, .t.)
Set( _SET_SOFTSEEK, .t.)
__SetCentury( .t. )
Set( _SET_EPOCH, year( date() ) - 60 )
Set( _SET_DATEFORMAT, "dd/mm/yyyy" )

setmode(25,80)

use cepruaimp new
zap

use cities new
INDEX ON ID TO CITIES

use states new
INDEX ON ID TO STATES

nERROUSO:=FCREATE("cepruaerro.txt")

aESTADOS:={"AC","AL","SP","AM","BA","ES","MG","MS","MT","PA","RS","SC","SE","RO","PI","PE","PB","GO","DF","CE","AP","PR","RJ","TO","RR"}
nFIMEST:=LEN(aESTADOS)
FOR ZEST=1 TO  nFIMEST
    FOR K=1 TO 5
       caRQUIVO:=aESTADOS[ZEST]+"_cepaberto_parte_"+STRZERO(K,1)+".CSV"
	   IF FILE(cARQUIVO)
          @ MAXROW()-1,0 SAY cARQUIVO
	      FAZER(carquivo)
       ELSE
   //       ALERT(cARQUIVO)   
	   ENDIF
    NEXT K  
NEXT ZEST   
dbcloseall()
fclose(nERROUSO)

function fazer(carqIMP)

nLASTREC:=FLINECOUNT(cARQIMP)
cDELIM:=FDELIM (cARQIMP,1024) //acha o delimitador chr(13)+chr(10) dos ou chr(10) linux usado abaixo no freadline

//ALTD()


//nTESTE:=FOPEN("to_cepaberto_parte_2.CSV")

nFILEUSO:=FOPEN(cARQIMP) //abre o arquivo


//IF cDELIM=""
//   cDELIM=CHR(10)
//ENDIF



while .T.
	//69900001,Beco Estado do Acre, ,Base,7735,1
   // 1           2               3 4     5  6 
	//1           2                   3                                4   5   6   
	//30110005,Avenida do Contorno,- de 1193 a 1825 - lado �mpar,Floresta,1126,11
    //77828300,Avenida Buenos Aires, ,Morada do Sol,550,27
    //   1          2               3   4            5   6
// 1   CEP
// 2   Logradouro: nome da rua, avenida, etc
//3	cobs 
//4    Nome do bairro
//5    ID da cidade: referente ao ID contido arquivo "Cidades"    idcid
//6    ID do estado: referente ao ID contido no arquivo "Estados"   iduf   
   
   
        cLINHA:=FREADLINE (nFILEUSO, 1024 ,.T. ,cDELIM) //FREADLINE (handle, line_len,lremchrexp,cDELI)
        
        //operacoes da rotina
        
        IF cLINHA='__FINAL__' //freadline retorna __FINAL__   quando nao e mais linhas
           EXIT
        ENDIF
        
   @ MAXROW(),0 SAY cLINHA    
   
   
   // 20010905,"Rua Dom Manuel, s/n",,Centro,7764,1920010975 
   nPOSFIM:=RAT('"',cLINHA)
   nPOSINI:=AT('"',cLINHA)
   IF nPOSINI>0 .AND. nPOSFIM>0
  //    ALTD()
      cUSO:=SUBSTR(cLINHA,1,nPOSINI-1)
      cUSO+=STRTRAN(SUBSTR(cLINHA,nPOSINI+1,nPOSFIM-nPOSINI-1),",","")
      cUSO+=SUBSTR(cLINHA,nPOSFIM+1)
      cLINHA:=cUSO
   ENDIF
    
   aCAMPOS:=HB_ATokens(cLINHA,",") 

   cCEP:=aCAMPOS[1]
   cNOME:=upper(TRATANOME(acAMPOS[2]))
   cOBS:=upper(TRATANOME(aCAMPOS[3]))   
   cBAIRRO:=upper(TRATANOME(aCAMPOS[4]))      

   nidcid:=aCAMPOS[5]
   if valtype(nidcid)="C"
       nidcid:=val(nidcid)
   endif
   niduf :=ACAMPOS[6]
   if valtype(niduf)="C"
       niduf:=val(niduf)
   endif

   cUF      :=""
   dbselectar("states")
   dbgotop()
   if dbseek(niduf)
      Cuf:=states->uf
   endif
   
   cCIDADE:=""
   dbselectar("cities")
   dbgotop()
   if dbseek(nidcid)
      cCIDADE:=upper(TRATANOME(cities->nome))
   endif   
 
 
   IF ! EMPTY(cUF) .AND. ! EMPTY(cCIDADE)
       dbselectar("cepruaimp")
       dbappend()
       cepruaimp->CEP:=cCEP
       cepruaimp->RUA:=cNOME
       cepruaimp->OBS:=cOBS
       cepruaimp->BAIRRO:=cBAIRRO
       cepruaimp->UF:=cUF
       cepruaimp->CIDADE:=cCIDADE
   ELSE
       FWRITE(nERROUSO,cLINHA)
   ENDIF    
 
enddo
fclose(nFILEUSO)   //fecha o arquivo
ferase(Carqimp)
RETURN .T.



function tratanome(cNOME,lANSI,lACEN)
LOCAL npOS
IF VALTYPE(lANSI)<>"L"
   lANSI:=.F.
ENDIF
IF VALTYPE(lACEN)<>"L"
   lACEN:=.T.
ENDIF
cNOME:=ALLTRIM(cNOME)
npOS:=AT("(",cNOME)
IF npOS>0   
   cNOME:=SUBSTR(cNOME,1,nPOS-1)
   cNOME:=ALLTRIM(cNOME)
ENDIF
IF lACEN
   cNOME     := TIRACE(cNOME)
ENDIF
IF lANSI
   cNOME     :=win_ANSIToOEM(cNOME) 
ENDIF
cNOME:=STRTRAN(cNOME,"&39;"," ")
cNOME:=STRTRAN(cNOME,"-"," ")
cNOME:= strtran( alltrim( cNOME ), "'", " " )
RETURN cNOME

FUNCTION VERTXT()
RETURN .T.