Test_ViaCEP.prg
hbmk2 Test_ViaCEP hbtip.hbc -gtwvt