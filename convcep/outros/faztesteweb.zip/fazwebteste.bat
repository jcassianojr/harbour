call C:\devprg\hb64MGW12\HB64MGW12
hbmk2 cepwebteste -b hbct.hbc hbwin.hbc xhb.hbc
