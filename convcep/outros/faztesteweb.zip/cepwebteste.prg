#include "try.ch"
REQUEST HB_CODEPAGE_PTISO

/*  Msxml2.XMLHTTP.6.0 Msxml2.XMLHTTP.3.0
1. Microsoft XML, v 3.0.
2. Microsoft XML, v 4.0 (if you have installed MSXML 4.0 separately).
3. Microsoft XML, v 5.0 (if you have installed Office 2003 � 2007 which provides MSXML 5.0 for Microsoft Office Applications).
4. Microsoft XML, v 6.0 for latest versions of MS Office.
*/

Set( _SET_CODEPAGE, "PTISO" )
   SetMode( 25, 80 )
   CLS
   HB_IDLESTATE()
	Set( _SET_OPTIMIZE, .t.)
	Set( _SET_DELETED, .t.)
	Set( _SET_SOFTSEEK, .t.)
	__SetCentury( .t. )
    Set( _SET_EPOCH, year( date() ) - 60 )
    Set( _SET_DATEFORMAT, "dd/mm/yyyy" )

//https://cep.awesomeapi.com.br/json/05424020
//https://cep.awesomeapi.com.br/xml/05424020
//https://cep.awesomeapi.com.br/05424020

//cURL:="https://cdn.apicep.com/file/apicep/06233-030.json"

cURL:="https://cep.awesomeapi.com.br/json/05424020"

testetip(cURL)    //TIpClientHttp():new
testexml6(cURL)   //Msxml2.XMLHTTP.6.0
//testexml3(cURL)   //Msxml2.XMLHTTP.3.0
//testexml2(cURL)  //MSXML2.XMLHTTP


function testexml6(cURL)
 LOCAL opg, cXML
	oPg  := CreateObject("Msxml2.XMLHTTP.6.0")
	oPg:Open("GET",cUrl,.F.)
	oPg:Send()
	cXMl := oPg:ResponseBody
    hb_memowrit("testexml6.txt",cXMl )
return .t.    

function testexml3(cURL)
 LOCAL opg, cXML
	oPg  := CreateObject("Msxml2.XMLHTTP.3.0")
	oPg:Open("GET",cUrl,.F.)
	oPg:Send()
	cXMl := oPg:ResponseBody
    hb_memowrit("testexml3.txt",cXMl )
return .t.    
    
function testetip(cURL)
  LOCAL oHttp, cXML
   
   TRY
    oHttp:= TIpClientHttp():new( cURL )
   Catch
     return .f.
   end
   
   IF !oHttp:open()
	  return .F.
   ENDIF
   inkey(.5)
   cXML := oHttp:readAll()
   oHttp:close()
   
   hb_memowrit("testetip.txt",cXMl )
   
return .t. 

FUNCTION testexml2(cURL)
  Local oOle, aRet
  //
  @ 5, 1 + 1 SAY "A"
    
    TRY
       oOle:=win_OleCreateObject("MSXML2.XMLHTTP")  
    Catch
       oOle:=CreateObject("Microsoft.XMLHTTP")
    End
    //
    @ 5, 1 + 1 SAY "B"
    
     oOle:Open( 'POST', cURL , .f. )  // ESSE � UM EXEMPLO DE REQUISICAO Q ESTOU USANDO NO TESTE 
    
    
    @ 5, 1 + 1 SAY "C"
    
    //oOle:setRequestHeader("Content-Type", "application/json" )
    //
    @ 5, 1 + 1 SAY "D"   // aqui a fun�ao que esta rodando em segundo plano para at� o send() ser executado
    //
    TRY 
       oOle:Send( )      
    CATCH
       RETURN ""
    End   
    //
    @ 5, 1 + 1 SAY "E"
    aRet:=oOle:Responsetext
    Do While oOle:readyState <> 4
       millisec(500)
    ENDDO
    //
    @ 5, 1 + 1 SAY "F"
    if ! empty(aRET)
       hb_memowrit("testexml2.txt",str(aRET))
    ENDIF   
    //
    
RETURN ""  

