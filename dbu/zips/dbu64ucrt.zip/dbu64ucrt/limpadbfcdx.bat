del *.dbf
del *.cdx
del *.dbe
del *.fpt
del *.sql
del *.dbml
del *.xlsx
del *.xml
del *.md
del *.sqlite

