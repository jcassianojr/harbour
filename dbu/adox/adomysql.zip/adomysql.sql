# MySQL-Front Dump 2.1
#
# Host: mysql4.shoppmarketing.com   Database: adomysql
#--------------------------------------------------------
# Server version 4.1.15

USE adomysql;


#
# Table structure for table 'clientes'
#

DROP TABLE IF EXISTS clientes;
CREATE TABLE IF NOT EXISTS clientes (
  nome char(45) ,
  email char(45) ,
  UNIQUE KEY nome (nome)
);



#
# Dumping data for table 'clientes'
#
INSERT INTO clientes VALUES("NOME DO ROCHINHA","FIVOLUTION@HOTMAIL.COM");
INSERT INTO clientes VALUES("JOSE CARLOS DA ROCHA","IROCHINHA@ITELEFONICA.COM.BR");
INSERT INTO clientes VALUES("SHOPPMARKETING","SUPORTE@SHOPPMARKETING.COM");
INSERT INTO clientes VALUES("KONECTIVA AUTOMACAO","COMERCIAL@SHOPPMARKETING.COM");
INSERT INTO clientes VALUES("TESTE COM DUAS JANELAS","ATUALIZOU NA HORA");
INSERT INTO clientes VALUES("TESTES ALTERADO","TESTES");
INSERT INTO clientes VALUES("TESTE","TESTE S");
INSERT INTO clientes VALUES("BE","BE");


#
# Table structure for table 'siglas'
#

DROP TABLE IF EXISTS siglas;
CREATE TABLE IF NOT EXISTS siglas (
  uf char(2) ,
  estado char(20) 
);



#
# Dumping data for table 'siglas'
#
INSERT INTO siglas VALUES("RJ","RIO DE JANEIRO");
INSERT INTO siglas VALUES("SP","SAO PAULO");
