/* *********************************
Tables of database 'adosql'
*/
CREATE DATABASE adosql;
USE adosql;

/* *********************************
Table structure for table 'clientes'
*/
CREATE TABLE clientes ( 
  nome char(45) ,
  email char(45) );

INSERT INTO clientes (nome,email) VALUES('NOME DO ROCHINHA','FIVOLUTION@HOTMAIL.COM');
INSERT INTO clientes (nome,email) VALUES('JOSE CARLOS DA ROCHA','IROCHINHA@ITELEFONICA.COM.BR');
INSERT INTO clientes (nome,email) VALUES('SHOPPMARKETING','SUPORTE@SHOPPMARKETING.COM');
INSERT INTO clientes (nome,email) VALUES('KONECTIVA AUTOMACAO','COMERCIAL@SHOPPMARKETING.COM');
INSERT INTO clientes (nome,email) VALUES('TESTE COM DUAS JANELAS','ATUALIZOU NA HORA');
INSERT INTO clientes (nome,email) VALUES('TESTES ALTERADO','TESTES');
INSERT INTO clientes (nome,email) VALUES('TESTE','TESTE S');
INSERT INTO clientes (nome,email) VALUES('BE','BE');

/* *********************************
Table structure for table 'clientes'
*/
CREATE TABLE siglas (
  uf char(2) ,
  estado char(20) 
);

INSERT INTO siglas (uf,estado) VALUES('RJ','RIO DE JANEIRO');
INSERT INTO siglas (uf,estado) VALUES('SP','SAO PAULO');

