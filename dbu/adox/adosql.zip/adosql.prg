/*
 *
 * Mais informacoes sobre ADO em 
 * http://www.microsoft.com/brasil/technet/Colunas/scriptcenter/resources/officetips/nov05/tips1103.mspx
 *
 */
#include "Fivewin.ch" 
#include "..\hbado\adoxb.ch" 

FUNCTION MAIN() 
    PUBLIC oRs

    ADOSetRDD( "SQL" )

    cPath := cFilePath( GetModuleFileName( GetInstance() ) )
    //StrConnection := "Data Source=SQLExpress;integrated security=true;attachdbfilename=.\adosql.mdf;User ID=Administrador;Password=konectiva;"
    //StrConnection := "Provider=sqloledb;Data Source=192.168.10.25,1433;Initial Catalog=Nothwind;User ID=sql_user;Password=sql_password;" 
    //StrConnection := "Provider=MSDASQL;Data Source=SQLExpress;attachdbfilename=.\adosql.mdf;User ID=Administrador;Password=konectiva;"
    StrConnection := "Driver={SQL Server};Server=127.0.0.1;AttachDbFilename="+cPath+"adosql.mdf;"
    MsgRun( "Conectando..." )

    ADO CONNECT StrConnection

    oRs := oRecordSet

    // Cria tabelas se nao existirem
    if ADOFile( "clientes" )
    else  
       MsgRun( "Criando tabela CLIENTES..." )
       ADO EXECUTE "DROP TABLE clientes"
       ADO EXECUTE "CREATE TABLE clientes (nome char(45), email char(45), unique(nome))"
    endif
    if ADOFile( "siglas" )
    else
       MsgRun( "Criando tabela SIGLAS..." )
       ADO EXECUTE "DROP TABLE siglas"
       ADO EXECUTE "CREATE TABLE siglas (uf char(2), estado char(20), unique(uf))"
    endif

    // Abre as tabelas
    ADO USE clientes

    //ADOIndex( "clientes", "nome", "CliNome", .t. )
    //ADOSetOrder( 1 )
    ADO SORT ON nome

    ADO USE siglas

    // Verifica se ja possuem dados
    ADO SELECT clientes
    //ADO GOTOP
    nRegistros := ADORecCount()
    // ? ADOAlias(), nRegistros 
    if nRegistros = 0
       ADO APPEND BLANK
       ADO REPLACE nome        WITH "JOSE CARLOS DA ROCHA"
       ADO REPLACE email       WITH "IROCHINHA@ITELEFONICA.COM.BR"
       ADO COMMIT 
    endif
    ADO SELECT siglas
    //ADO GOTOP
    nRegistros := ADORecCount()
    // ? ADOAlias(), nRegistros 
    if nRegistros = 0
       ADO APPEND BLANK
       ADO REPLACE uf          WITH "SP"
       ADO REPLACE estado      WITH "SAO PAULO"
       ADO COMMIT 
       ADO APPEND BLANK
       ADO REPLACE uf          WITH "RJ"
       ADO REPLACE estado      WITH "RIO DE JANEIRO"
       ADO COMMIT 
    endif

    MsgRun( "Executando..." )
    ADO SELECT clientes
    ADO GOTOP

    MsgRun( "Executando SET FILTER TO nome like '*teste*'..." )
    ADO SET FILTER TO "nome like '*tete*'"
    if ADOEof()
       ? 'Nada foi filtrado'
       ADO SET FILTER TO
       ADO GOTOP
    endif
    Browse( oRs )
    ADO SET FILTER TO

    MsgRun( "Executando LOCATE nome like 'TESTES'..." )
    ADO LOCATE "nome like 'TESTES*'"
    if ADOEof()
       ? 'Nada foi encontrado'
       ADO GOTOP
    endif
    Browse( oRs )

    //MsgRun( "Executando SORT ON nome..." )
    //ADO SORT ON clientes.nome
    //Browse( oRs )

    //WBrowseRecordSet( oRs, StrField2 )
    //Browse( oRs )

    ADO CLOSE
    RETURN NIL

function WBrowseRecordSet( oRs, cStrField ) 
    LOCAL oDlg, oBrw, nRec 
    DEFINE DIALOG oDlg SIZE 300, 300 
    @ 0, 0 LISTBOX oBrw FIELDS oRs:Fields( "nome" ):Value ; 
           HEADERS "Nome do Cliente" ;
           FIELDSIZES 300 ;
           ON RIGHT CLICK ( nRec := oRs:AbsolutePosition,; 
                            oBrw:Report( "TWBrowse report", .T. ),; 
                            oRs:MoveFirst(),; 
                            oRs:Move( nRec - 1 ) ) 
    oBrw:bLDblClick:= { |nRow,nCol| MsgStop( oRs:Fields( "email" ):Value ) }
    oBrw:nHeaderStyle  := 2
    oBrw:nHeaderHeight := 20
    oBrw:nLineHeight   := 15
    oBrw:bLogicLen := { || oRs:RecordCount }
    oBrw:bGoTop    := { || oRs:MoveFirst() } 
    oBrw:bGoBottom := { || oRs:MoveLast() } 
    oBrw:bSkip     := { | nSkip | ADOSkipper( oRs, nSkip ) } 
    oBrw:cAlias    := "ARRAY" 
    ACTIVATE DIALOG oDlg; 
             ON INIT oDlg:SetControl( oBrw ); 
             CENTER 
    RETURN NIL

function browse(oRs, bPrc, bAdc, bAlt, bExc, bImp, bSai)
    LOCAL oDlg, oBrw, nRec 
    LOCAL aData := {}
    LOCAL nFor
    LOCAL oLbx, cItem
    LOCAL btnPrc, btnAdc, btnAlt, btnExc, btnImp, btnsai

    DEFAULT bPrc    := { || RecPrc( oLbx ) },;
            bAdc    := { || RecInc( oLbx ) },;
            bAlt    := { || RecAlt( oLbx ) },;
            bExc    := { || RecExc( oLbx ) },;
            bImp    := { || RecImp( oLbx ) },;
            bSai    := { || oDlg2:End() }

    DEFINE DIALOG oDlg2 From 0,0 To 800,1020 Pixel TITLE " ListBox da Tabela "
    @ 05,15 listbox oBrw Fields ADOField( "nome" ), ADOField( "email" ) ;
             headers "Nome","email" ;
             fieldsizes 250,100 ;
             pixel size 400,300 of odlg2

    //oBrw:bLDblClick:= { |nRow,nCol| MsgStop( oRs:Fields( "apelido" ):Value ) }
    oBrw:nHeaderStyle  := 2
    oBrw:nHeaderHeight := 20
    oBrw:nLineHeight   := 15
    oBrw:bLogicLen := { || ADORecCount() }
    oBrw:bGoTop    := { || ADOGotop() } 
    oBrw:bGoBottom := { || ADOGoBottom() } 
    oBrw:bSkip     := { | nSkip | ADOSkip( nSkip ) } 
    oBrw:cAlias    := "ARRAY" 

    @ 18.7 , 05 button btnprc prompt "&Procurar"  of oDlg2 size 40,12 Action RecPrc(oBrw)
    @ 18.7 , 15 button btnadc prompt "&Adicionar" of oDlg2 size 40,12 Action RecInc(oBrw)
    @ 18.7 , 25 button btnalt prompt "A&lterar"   of oDlg2 size 40,12 Action RecAlt(oBrw)
    @ 18.7 , 35 button btnexc prompt "&Excluir"   of oDlg2 size 40,12 Action RecExc(oBrw)
    @ 18.7 , 45 button btnimp prompt "&Imprimir"  of oDlg2 size 40,12 
    @ 18.7 , 55 button btnsai prompt "&Sair"      of oDlg2 size 40,12 Action oDlg2:End()

    ACTIVATE DIALOG oDlg2 //; 
             //ON INIT oDlg2:SetControl( oBrw ); 
             //CENTER 
    RETURN NIL

function ADOSkipper( oRs, nSkip ) 
    LOCAL nRec := oRs:AbsolutePosition 
    oRs:Move( nSkip ) 
    IF oRs:EOF; oRs:MoveLast(); ENDIF 
    IF oRs:BOF; oRs:MoveFirst(); ENDIF 
    RETURN oRs:AbsolutePosition - nRec

//-----------------------------------------------------------
static function  RecPrc(oLbx)
    Local odlg1
    Local cCodigo:=0
    Local cSair:=" "
    Local sql
    DEFINE DIALOG oDlg1 From 0,0 To 160,250  PIXEL;
           TITLE " Procura na Tabela em Access " 
    DEFINE FONT oFont NAME "FIXEDSYS" SIZE 10, -10    && Use a Nonproportional font
    SET FONT OF oDlg1 TO oFont                         && so characters line up in Says
    @ 02,05 say "Codigo : " OF oDlg1 
    @ 02.2,10 get cCodigo   OF oDlg1 picture "9999" size 20,10 
    @ 02.7 , 10 button "Procurar"  of oDlg1 size 40,12 action (cSair:="*",oDlg1:End())
    ACTIVATE DIALOG oDlg1 centered 
    if cSair="*"
       //locate for (odbf:cAlias)->field_0001 = cCodigo
       criterio = "idpessoa Like '" + cCodigo + "%'"
       //oRs:MoveFirst()
       //oRs:Find criterio, 0, adSearchFoward
       if eof()
          msgAlert("N�o encontrado !!!")
          go top
       endif
       oLbx:Refresh()
    endif
    return nil

//-----------------------------------------------------------
static function  RecInc(oLbx)
    LOCAL odlg3
    LOCAL cNome     := space(40)
    LOCAL cTelefone := space(14)
    LOCAL cEmail    := space(40)
    LOCAL cSair     := " "
    DEFINE DIALOG oDlg3 From 0,0 To 230,500 PIXEL TITLE " Inclusao na Tabela em Access " 
           DEFINE FONT oFont NAME "FIXEDSYS" SIZE 10, -10    && Use a Nonproportional font
           SET FONT OF oDlg3 TO oFont                         && so characters line up in Says
           @ 02,05 say "Nome_____: " OF oDlg3 
           @ 04,05 say "Email____: " OF oDlg3
           //
           @ 02.2,10 get cNome     OF oDlg3 picture "@!" size 150,10
           @ 04.4,10 get cEmail    OF oDlg3 picture "@!" size 150,10
           //
           @ 04.7 , 15 button "Salvar"   of oDlg3 size 40,12 action (cSair:="*",oDlg3:End())
    ACTIVATE DIALOG oDlg3 centered 
    if cSair="*"
       ADO APPEND BLANK
       ADO REPLACE nome        WITH alltrim( cNome )
       ADO REPLACE email       WITH alltrim( cEmail )
       ADO COMMIT 
       oLbx:Refresh()
    endif
    return nil

//-----------------------------------------------------------
static function  RecExc(oLbx)
    if MsgYesNo( "Excluir este Registro ?", "Por Favor, confirme" )
       ADO DELETE
       //ADO SKIP
       oLbx:Refresh()
    endif
    return nil

//-----------------------------------------------------------
static function  RecAlt(oLbx)
    LOCAL odlg3
    LOCAL cNome     := PadR( ADOField( "nome" ), 40 )
    LOCAL cEmail    := PadR( ADOField( "email" ), 40 )
    LOCAL cSair     := " "
    DEFINE DIALOG oDlg3 From 0,0 To 230,500 PIXEL TITLE " Inclusao na Tabela em Access " 
           DEFINE FONT oFont NAME "FIXEDSYS" SIZE 10, -10    && Use a Nonproportional font
           SET FONT OF oDlg3 TO oFont                        && so characters line up in Says
           //
           @ 02,05 say "Nome_____: " OF oDlg3 
           @ 04,05 say "Email____: " OF oDlg3 
           //
           @ 02.2,10 get cNome     OF oDlg3 picture "@!" size 150,10
           @ 04.4,10 get cEmail    OF oDlg3 picture "@!" size 150,10
           //
           @ 04.7 , 15 button "Salvar"   of oDlg3 size 40,12 action (cSair:="*",oDlg3:End())
    ACTIVATE DIALOG oDlg3 centered 
    if cSair="*"
       //ADO APPEND BLANK
       ADO REPLACE nome        WITH alltrim( cNome )
       ADO REPLACE email       WITH alltrim( cEmail )
       ADO COMMIT 
       oLbx:Refresh()
    endif
    return nil

//-----------------------------------------------------------
static function RecImp( oLbx )
/*
    local oRpt
    local n
    local cAlias := If( oLbx != nil, oLbx:cAlias, Alias() )
    REPORT oRpt TITLE "Relatorio: " + cAlias ;
           HEADER "Data: " + DToC( Date() ) + ", Hora: " + Time() ;
           FOOTER "Pagina: " + Str( oRpt:nPage, 3 ) ;
           PREVIEW
           if Empty( oRpt ) .or. oRpt:oDevice:hDC == 0
              return nil
           endif
           for n = 1 to FCount()
               oRpt:AddColumn( TrColumn():New( { FInfo1( cAlias, n ) },,;
                     { FInfo2( cAlias, n ) },,,,,,,,,, oRpt ) )
           next
    ENDREPORT
    ACTIVATE REPORT oRpt
    GO TOP
*/
    return nil

//--------------------------------------------
static function FInfo1( cAlias, n )
return { || ( cAlias )->( FieldName( n ) ) }

//-----------------------------------------------------------
static function FInfo2( cAlias, n )
return { || ( cAlias )->( FieldGet( n ) ) }

Function DbfDbt()
Return Nil

#include "..\hbado\adoxb.prg" 
