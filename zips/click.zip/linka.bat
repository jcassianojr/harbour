rem copy c:\devgit\hb32\include\harbour.hbx
rem call call C:\DEVPRG\hb64mgw10\hb64mgw10
rem hbmk2 click.hbp
call d:\devprg\hb\hb32msys.bat
call c:\devprg\hb\hb32msys_c.bat
hbmk2.exe click.hbp
