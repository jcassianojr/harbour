rem SET HB_INSTALL_PREFIX=d:\hbcomp\
call d:\DEVPRG\hb\hb64msys
call c:\DEVPRG\hb64\hb64msys_c.bat
hbmk2.exe sqlrddpp.hbp 

