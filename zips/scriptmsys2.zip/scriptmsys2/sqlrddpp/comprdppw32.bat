rem SET HB_INSTALL_PREFIX=d:\hbcomp\
call d:\devprg\hb\hb32msys
call c:\DEVPRG\hb\hb32msys_C.BAT
rem hbmk2.exe sqlrddpp.hbp 
hbmk2.exe sqlrddpp-alllibs.hbp