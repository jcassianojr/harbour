call \devprg\hb\hb32msys.bat
call \devprg\hb\hb32msys_c.bat
SET HB_INSTALL_PREFIX=c:\harbour\LetoDBf\hb32\
hbmk2 apileto.hbp
rem hbmk2 letodb.hbp
rem hbmk2 letodbaddon.hbp
hbmk2 letodbsvc.hbp
hbmk2 rddleto.hbp
rem hbmk2 rddletoaddon.hbp

