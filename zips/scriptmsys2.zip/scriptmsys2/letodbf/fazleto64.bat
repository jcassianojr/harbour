call d:\devprg\hb64\hb64msys.bat
call c:\devprg\hb64\hb64msys_C.bat
SET HB_INSTALL_PREFIX=c:\harbour\LetoDBf\hb64\
hbmk2 apileto.hbp
rem hbmk2 letodb.hbp
rem hbmk2 letodbaddon.hbp
hbmk2 letodbsvc.hbp
hbmk2 rddleto.hbp
rem hbmk2 rddletoaddon.hbp

