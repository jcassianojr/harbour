rem SET HB_INSTALL_PREFIX=d:\hbcomp\
del *.a
call d:\DEVPRG\hb\hb64msys
call c:\DEVPRG\hb64\hb64msys_c.bat
SET HB_WITH_ADS=c:\harbour\hb3rd\aceopenads-x64\
hbmk2.exe rddads.hbp 

