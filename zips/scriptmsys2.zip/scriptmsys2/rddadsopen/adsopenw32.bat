del *.a
rem SET HB_INSTALL_PREFIX=d:\hbcomp\
call d:\devprg\hb\hb32msys
call c:\DEVPRG\hb\hb32msys_C.BAT
SET HB_WITH_ADS=c:\harbour\hb3rd\aceopenads\
hbmk2.exe rddads.hbp 
