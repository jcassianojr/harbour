// Mapeamento de compatibilidade Firebird 5
// Baseado nas fun��es da firebird.c[cite: 5] e sr_firebird5_bind.c

FUNCTION FBCREATEDB( cDb, cUser, cPass, nPage, cCharset, nDialect )
RETURN SR_FBCREATEDB5( cDb, cUser, cPass, nPage, cCharset, nDialect ) //

FUNCTION FBCONNECT( cDb, cUser, cPass, cCharset, hEnv )
   LOCAL hNewEnv := nil
   IF SR_FBCONNECT5( cDb, cUser, cPass, cCharset, @hNewEnv ) == 0
      hEnv := hNewEnv
      RETURN hNewEnv
   ENDIF
RETURN nil

FUNCTION FBCLOSE( hEnv )
RETURN SR_FBCLOSE5( hEnv ) //

FUNCTION FBERROR( hEnv )
   LOCAL nCode := 0
   LOCAL cMsg := ""
   // SR_FBERROR5 retorna erro no cMsg e armazena c�digo em nCode
   cMsg := SR_FBERROR5( hEnv, @nCode ) 
RETURN cMsg

FUNCTION FBSTARTTRANSACTION( hEnv )
RETURN SR_FBBEGINTRANSACTION5( hEnv ) //

FUNCTION FBCOMMIT( hTrans )
RETURN SR_FBCOMMITTRANSACTION5( hTrans ) //[cite: 6]

FUNCTION FBROLLBACK( hTrans )
RETURN SR_FBROLLBACKTRANSACTION5( hTrans ) //[cite: 6]

FUNCTION FBEXECUTE( hEnv, cSql, nDialect )
RETURN IIF( SR_FBEXECUTE5( hEnv, cSql, nDialect ) == 0, .T., .F. ) //[cite: 6]

FUNCTION FBQUERY( hEnv, cSql, nDialect, hTrans )
   // SR_FBEXECUTE5 gerencia a execu��o e prepara��o[cite: 6]
   // Note: O bind sr_firebird5_bind.c usa SR_FBEXECUTE5 para queries
RETURN SR_FBEXECUTE5( hEnv, cSql, nDialect ) 

FUNCTION FBFETCH( hEnv )
RETURN SR_FBFETCH5( hEnv ) //[cite: 6]

FUNCTION FBFREE( hEnv )
   // O bind moderno gerencia o fechamento via SR_FBCLOSE5 ou finaliza��o de statement
RETURN SR_FBCLOSE5( hEnv ) 

FUNCTION FBGETDATA( hEnv, nCol, uData )
   // O SQLRDD/SR usa SR_FBGETDATA5 ou SR_FBLINEPROCESSED5[cite: 6]
   SR_FBLINEPROCESSED5( hEnv, nil, nil, .F., 0, .F., @uData )
RETURN nil

FUNCTION FBGETBLOB( hEnv, blob_id, hTrans )
   // O bind 5 trata blobs dentro da estrutura de fetch/getdata
RETURN nil