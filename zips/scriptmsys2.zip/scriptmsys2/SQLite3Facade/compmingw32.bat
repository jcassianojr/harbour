call d:\DEVPRG\hb\hb32msys.bat
call c:\DEVPRG\hb\hb32msys_c.bat
hbmk2.exe sqlite3facade.hbp
