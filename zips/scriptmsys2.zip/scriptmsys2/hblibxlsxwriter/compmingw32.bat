rem set HB_WITH_OCIlib=d:\harbour\hb3rd\oci-x64\include\
call d:\DEVPRG\hb\hb32msys
hbmk2.exe hblibxlsxwriter.hbp
