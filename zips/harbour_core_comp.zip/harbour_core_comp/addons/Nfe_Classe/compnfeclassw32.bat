call c:\devprg\hb\hb32msys_C.bat
call D:\devprg\hb\hb32msys.bat
hbmk2.exe Nfe_Classe.hbp 
