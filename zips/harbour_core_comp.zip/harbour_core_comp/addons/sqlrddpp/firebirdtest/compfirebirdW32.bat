call d:\devprg\hb\hb32msys.bat
call c:\devprg\hb\hb32msys_c.bat
for %%f in (*.prg) do hbmk2.exe %%f sqlrddpp.hbc -Lc:\harbour\hb3rd\firebird\lib\ -lfbclient
