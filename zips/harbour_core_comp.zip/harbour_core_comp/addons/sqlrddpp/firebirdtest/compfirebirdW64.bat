call d:\devprg\hb64\hb64msys.bat
call c:\devprg\hb64\hb64msys_c.bat
for %%f in (*.prg) do hbmk2.exe %%f sqlrddpp.hbc -Lc:\harbour\hb3rd\firebird\lib\ -lfbclient
