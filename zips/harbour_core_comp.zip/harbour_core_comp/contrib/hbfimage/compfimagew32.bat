rem SET HB_INSTALL_PREFIX=d:\hbcomp\
SET HB_WITH_FREEIMAGE=\harbour\hb3rd\freeimage\include\
call d:\devprg\hb\hb32msys
call c:\DEVPRG\hb\hb32msys_C.BAT
hbmk2.exe hbfimage.hbp 
