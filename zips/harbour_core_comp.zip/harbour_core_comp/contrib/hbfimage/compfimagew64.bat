rem set HB_WITH_OCIlib=d:\harbour\hb3rd\oci-x64\include\
call \DEVPRG\hb64\hb64msys.bat
call \DEVPRG\hb64\hb64msys_c.bat
SET HB_WITH_FREEIMAGE=c:\harbour\hb3rd\FreeImage-x64\include\
hbmk2.exe hbfimage.hbp 
