curl -L -O https://sourceforge.net/projects/pxlib/files/pxlib/0.6.8/pxlib-0.6.8.tar.gz
tar -zxvf pxlib-0.6.8.tar.gz
cd pxlib-0.6.8