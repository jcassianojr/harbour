@echo off
TITLE Compilando pxlib para 32-bits (MSVC)
color 0B

:: Configura o ambiente do MSVC para 32-bits (x86)
CALL "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat"

:: Define a pasta de destino final
SET DEST_DIR=C:\devprg\pxlib32

IF NOT EXIST "%DEST_DIR%\include" MKDIR "%DEST_DIR%\include"
IF NOT EXIST "%DEST_DIR%\lib" MKDIR "%DEST_DIR%\lib"
IF NOT EXIST "%DEST_DIR%\bin" MKDIR "%DEST_DIR%\bin"

echo.
echo [1/3] Entrando na pasta src e compilando os fontes para DLL (32-bits)...
CD src

:: Limpa resquícios anteriores na pasta src
DEL /Q *.obj *.ilk *.pdb *.exp *.idb *.manifest 2>nul

:: Compila os fontes apontando os includes para a pasta pai (..)
cl /LD /O2 *.c /I. /I..\include /Fe:pxlib.dll /link /DEF:pxlib.def

echo.
echo [2/3] Organizando os arquivos para a pasta de destino (%DEST_DIR%)...
MOVE /Y pxlib.dll "%DEST_DIR%\bin\"
MOVE /Y pxlib.lib "%DEST_DIR%\lib\"
MOVE /Y pxlib.exp "%DEST_DIR%\lib\"
COPY /Y ..\include\*.h "%DEST_DIR%\include\"

:: Volta para a pasta raiz
CD ..

echo.
echo ==========================================
echo  Compilacao 32-bits concluida com sucesso!
echo  Destino: %DEST_DIR%
echo ==========================================
pause