
64bits
./configure --host=x86_64-w64-mingw32
make clean
make

32bits
./configure --host=i686-w64-mingw32
make clean
make


mkdir build64 && cd build64
../configure --host=x86_64-w64-mingw32 --prefix=/c/devprg/pxlib64
make && make install
cd ..


mkdir build32 && cd build32
../configure --host=i686-w64-mingw32 --prefix=/c/devprg/pxlib32
make && make install
cd ..