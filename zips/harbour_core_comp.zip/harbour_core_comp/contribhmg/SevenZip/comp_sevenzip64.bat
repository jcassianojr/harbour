call d:\devprg\hb64\hb64msys.bat
call c:\devprg\hb64\hb64msys_C.bat
hbmk2.exe sevenzip.hbp
