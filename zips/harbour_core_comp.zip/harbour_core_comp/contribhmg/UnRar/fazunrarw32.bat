del *.a
rem SET HB_INSTALL_PREFIX=d:\hbcomp\
call d:\devprg\hb\hb32msys
call c:\DEVPRG\hb\hb32msys_C.BAT
SET WHIT_UNRAR_DLL=c:\harbour\hb3rd\unrar\
hbmk2.exe hbunrar.hbp 
